#!/usr/bin/env python3
"""계획서·회의록 파일(.hwpx/.txt/.pdf/.docx)에서 텍스트를 뽑아 표준출력으로 낸다.
표는 '| 셀 | 셀 |' 줄로 펼친다. 사용: python3 extract_text.py 파일 [파일 ...]"""
import sys, zipfile, re, subprocess
import xml.etree.ElementTree as ET

HP = '{http://www.hancom.co.kr/hwpml/2011/paragraph}'


def cell_text(tc):
    paras = []
    for p in tc.iter(HP + 'p'):
        t = ''.join(x.text or '' for x in p.iter(HP + 't'))
        if t.strip():
            paras.append(t.strip())
    return ' / '.join(paras)


def walk(el, out):
    tag = el.tag
    if tag == HP + 'tbl':
        out.append('')
        for tr in el.findall(HP + 'tr'):
            out.append('| ' + ' | '.join(cell_text(tc) for tc in tr.findall(HP + 'tc')) + ' |')
        out.append('')
        return
    if tag == HP + 'p':
        buf = []
        for run in el.findall(HP + 'run'):
            for ch in run:
                if ch.tag == HP + 't':
                    buf.append(''.join(ch.itertext()))
        line = ''.join(buf).strip()
        if line:
            out.append(line)
        # 표·글상자 등 문단 안 개체
        for run in el.findall(HP + 'run'):
            for ch in run:
                if ch.tag != HP + 't':
                    walk(ch, out)
        return
    for ch in el:
        walk(ch, out)


def read_hwpx(path):
    z = zipfile.ZipFile(path)
    secs = sorted(n for n in z.namelist() if re.match(r'Contents/section\d+\.xml$', n))
    out = []
    for n in secs:
        walk(ET.fromstring(z.read(n)), out)
    return '\n'.join(out)


def read_txt(path):
    raw = open(path, 'rb').read()
    for enc in ('utf-8-sig', 'cp949', 'euc-kr', 'utf-16'):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    return raw.decode('utf-8', 'replace')


def read_docx(path):
    z = zipfile.ZipFile(path)
    x = z.read('word/document.xml').decode('utf-8')
    x = re.sub(r'</w:p>', '\n', x)
    x = re.sub(r'</w:tc>', ' | ', x)
    return re.sub(r'<[^>]+>', '', x)


def main():
    for path in sys.argv[1:]:
        low = path.lower()
        print(f'===== {path} =====')
        if low.endswith('.hwpx'):
            print(read_hwpx(path))
        elif low.endswith('.txt') or low.endswith('.md'):
            print(read_txt(path))
        elif low.endswith('.docx'):
            print(read_docx(path))
        elif low.endswith('.pdf'):
            print(subprocess.run(['pdftotext', '-layout', path, '-'], capture_output=True, text=True).stdout)
        elif low.endswith('.hwp'):
            print('[지원 안 함] .hwp 는 한글에서 "다른 이름으로 저장 → .hwpx" 후 다시 첨부해 주세요.')
        else:
            print('[지원 안 함] 형식:', path)


if __name__ == '__main__':
    main()
