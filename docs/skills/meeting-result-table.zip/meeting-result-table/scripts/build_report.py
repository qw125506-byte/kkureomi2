#!/usr/bin/env python3
"""rows.json → 결과보고 표(.hwpx). 사용: python3 build_report.py template.hwpx rows.json 출력폴더
rows.json = {"title","date","time","place","count","composition","seated","content",
             "rows":[{"org","title","name","statement","summary","answer","depts":[..],"flags":[..]}]}"""
import sys, json, math, os, zipfile, unicodedata
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

COLS = [  # (json 키, 셀 너비 HWPUNIT, paraPrIDRef)
    ('org', 4000, 26), ('title', 3000, 26), ('name', 5000, 26),
    ('statement', 13500, 23), ('summary', 5000, 32), ('answer', 13000, 23), ('depts', 7524, 26)]
CHECK = '(확인 필요)'
_pid = [600000]


def pid():
    _pid[0] += 1
    return _pid[0]


def text_units(t):
    return sum(1.0 if unicodedata.east_asian_width(c) in 'WF' else 0.55 for c in t)


def lines_for(paras, width):
    cpl = max(1.0, (width - 600) / 790.0)
    return sum(max(1, math.ceil(text_units(p) / cpl)) for p in paras)


def para(text, ppr):
    return (f'<hp:p id="{pid()}" paraPrIDRef="{ppr}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">'
            f'<hp:run charPrIDRef="12"><hp:t>{escape(text)}</hp:t></hp:run></hp:p>')


def cell(paras, col, row, width, ppr, height):
    body = ''.join(para(p, ppr) for p in paras)
    return ('<hp:tc name="" header="0" hasMargin="1" protect="0" editable="0" dirty="0" borderFillIDRef="5">'
            '<hp:subList id="" textDirection="HORIZONTAL" lineWrap="BREAK" vertAlign="CENTER" linkListIDRef="0" '
            'linkListNextIDRef="0" textWidth="0" textHeight="0" hasTextRef="0" hasNumRef="0">'
            f'{body}</hp:subList><hp:cellAddr colAddr="{col}" rowAddr="{row}"/><hp:cellSpan colSpan="1" rowSpan="1"/>'
            f'<hp:cellSz width="{width}" height="{height}"/><hp:cellMargin left="300" right="300" top="300" bottom="300"/></hp:tc>')


def val(r, key):
    v = r.get(key)
    if key == 'depts':
        v = [d.strip() for d in (v or []) if d and d.strip()] or [CHECK]
        return v
    v = (v or '').strip()
    if not v:
        v = '-' if key == 'answer' else CHECK
    return [v]


def main():
    tpl, data_path, outdir = sys.argv[1], sys.argv[2], sys.argv[3]
    d = json.load(open(data_path, encoding='utf-8'))
    rows = list(d['rows'])
    if not d.get('keep_order'):
        rows.sort(key=lambda r: r.get('org', ''))  # 기관 가나다순, 같은 기관은 입력(발언) 순서 유지
    z = zipfile.ZipFile(tpl)
    files = {n: z.read(n) for n in z.namelist()}
    s = files['Contents/section0.xml'].decode('utf-8')

    xml_rows, total_h = [], 2300
    for i, r in enumerate(rows, start=1):
        cells_vals = [val(r, k) for k, _, _ in COLS]
        if len(cells_vals[6]) > 4:
            print(f'경고: {i}행 관련부서 {len(cells_vals[6])}개 (최대 4 권장)')
        n = max(lines_for(v, w) for v, (_, w, _) in zip(cells_vals, COLS))
        h = n * 1360 + 900
        total_h += h
        xml_rows.append('<hp:tr>' + ''.join(cell(v, c, i, w, p, h) for c, (v, (_, w, p)) in
                                            enumerate(zip(cells_vals, COLS))) + '</hp:tr>')

    def f(key, default=CHECK):
        v = (d.get(key) or '').strip()
        return escape(v or default)

    s = (s.replace('{{TITLE}}', f('title')).replace('{{DATE}}', f('date')).replace('{{TIME}}', f('time', ''))
          .replace('{{PLACE}}', f('place')).replace('{{COUNT}}', f('count'))
          .replace('{{COMP}}', f('composition', '')).replace('{{CONTENT}}', f('content'))
          .replace('{{ROWS}}', ''.join(xml_rows)).replace('{{ROWCNT}}', str(len(rows) + 1))
          .replace('{{TBLH}}', str(total_h)))
    seated = (d.get('seated') or '').strip()
    if seated:
        if not seated.startswith('※'):
            seated = '※ ' + seated
        s = s.replace('{{SEATED}}', escape(seated))
    else:  # 배석 줄 통째 삭제
        k = s.find('{{SEATED}}')
        a = s.rfind('<hp:p ', 0, k)
        b = s.find('</hp:p>', k) + len('</hp:p>')
        s = s[:a] + s[b:]
    assert '{{' not in s, '치환 안 된 자리표시자 남음'
    ET.fromstring(s.encode('utf-8'))  # XML 유효성 확인
    files['Contents/section0.xml'] = s.encode('utf-8')

    prv = [d.get('title', ''), f"일시 {d.get('date','')} {d.get('time','')}", f"장소 {d.get('place','')}", '']
    prv += [' / '.join([r.get('org', ''), r.get('name', ''), r.get('summary', '')]) for r in rows]
    files['Preview/PrvText.txt'] = '\n'.join(prv)[:1000].encode('utf-8')

    os.makedirs(outdir, exist_ok=True)
    name = (d.get('title') or '회의').strip()
    for ch in '\\/:*?"<>|':
        name = name.replace(ch, ' ')
    out = os.path.join(outdir, f'{name} 결과.hwpx')
    with zipfile.ZipFile(out, 'w') as o:
        for n in z.namelist():  # mimetype 은 무압축 첫 항목
            info = zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED if n == 'mimetype' else zipfile.ZIP_DEFLATED
            o.writestr(info, files[n])

    orgs = list(dict.fromkeys(r.get('org', '') for r in rows))
    need = [r for r in rows if r.get('flags') or any(
        ('확인 필요' in t or '교차됨' in t) for k, _, _ in COLS for t in val(r, k))]
    print(out)
    print(f'기관 {len(orgs)}곳 · 건의 {len(rows)}건 · 확인 필요 {len(need)}건')
    for r in need:
        print(f"  - {r.get('org')} {r.get('name')}: {r.get('summary')} {r.get('flags') or ''}")
    for note in d.get('notes', []):
        print('  ※', note)


if __name__ == '__main__':
    main()
