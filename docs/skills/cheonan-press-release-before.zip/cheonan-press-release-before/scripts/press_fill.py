"""press_fill.py — 천안시 보도자료 양식(.hwpx) 채우기 도우미

사용:
    from press_fill import *
    files, order, root = load('assets/template.hwpx')
    set_contact(root, dept='청년정책과', team='청년창업팀', leader_tel='521-1234', staff_tel='521-5678')
    set_title(root, '천안시, 청년 창업가와 창업생태계 활성화 방안 모색')
    set_subtitle(root, '22일 시청서 30명 내외 간담회… 공간·판로·자금 애로 청취')
    set_body(root, ['천안시는 …개최한다.', '이번 간담회는 …마련됐다.'])
    check(root, 'assets/template.hwpx')
    save(files, order, root, '보도자료.hwpx')
"""
import copy, sys, zipfile
from lxml import etree

HP = '{http://www.hancom.co.kr/hwpml/2011/paragraph}'


# ---------- 파일 ----------
def load(path):
    z = zipfile.ZipFile(path)
    files = {n: z.read(n) for n in z.namelist()}
    order = z.namelist()
    root = etree.fromstring(files['Contents/section0.xml'])
    return files, order, root


def save(files, order, root, out):
    for e in list(root.iter(HP + 'linesegarray')):  # 한글이 줄 배치를 다시 계산하도록
        e.getparent().remove(e)
    files['Contents/section0.xml'] = etree.tostring(
        root, xml_declaration=True, encoding='UTF-8', standalone=True)
    with zipfile.ZipFile(out, 'w') as z:
        z.writestr(zipfile.ZipInfo('mimetype'), files['mimetype'], compress_type=zipfile.ZIP_STORED)
        for n in order:
            if n != 'mimetype':
                z.writestr(n, files[n], compress_type=zipfile.ZIP_DEFLATED)


# ---------- 기본 ----------
def text(el):
    return ''.join(t.text or '' for t in el.iter(HP + 't'))


def set_line(p, s):
    """문단 전체를 s 한 줄로: 첫 run에 넣고 나머지 run 글자는 비움(서식은 첫 run 것)."""
    runs = p.findall(HP + 'run')
    for r in runs[1:]:
        for t in r.findall(HP + 't'):
            r.remove(t)
    r = runs[0]
    ts = r.findall(HP + 't')
    if not ts:
        ts = [etree.SubElement(r, HP + 't')]
    ts[0].text = s
    for t in ts[1:]:
        r.remove(t)


def top_paras(root):
    return root.findall(HP + 'p')


def header_table(root):
    return next(t for t in root.iter(HP + 'tbl') if '보 도 자 료' in text(t))


def cell(tbl, r, c):
    for tc in tbl.iter(HP + 'tc'):
        a = tc.find(HP + 'cellAddr')
        if int(a.get('rowAddr')) == r and int(a.get('colAddr')) == c:
            return tc
    raise KeyError((r, c))


def cell_paras(tc):
    return tc.find(HP + 'subList').findall(HP + 'p')


# ---------- 양식 위치 (문단 순서 고정) ----------
# 0 머리 표(슬로건·보 도 자 료·담당 정보) / 1 빈 줄 / 2 제목 / 3 부제 / 4 겹선 / 5 빈 줄 / 6~ 본문
I_TITLE, I_SUB, I_LINE, I_BODY = 2, 3, 4, 6


def set_contact(root, dept=None, team=None, leader_tel=None, staff_tel=None, photo=None, docs=None):
    """담당 정보 칸(3행)만 채움. 값이 None이면 양식 자리표시(O O 과 / 521-OOOO) 그대로."""
    t = header_table(root)
    ps = cell_paras(cell(t, 2, 0))
    if dept:
        set_line(ps[0], dept)
    if team:
        set_line(ps[1], team)
    if leader_tel:
        set_line(cell_paras(cell(t, 2, 1))[0], f'({leader_tel})')
    if staff_tel:
        set_line(cell_paras(cell(t, 2, 2))[0], f'({staff_tel})')
    if photo:
        set_line(cell_paras(cell(t, 2, 3))[0], photo)
    if docs:
        set_line(cell_paras(cell(t, 2, 4))[0], docs)


def set_title(root, s):
    set_line(top_paras(root)[I_TITLE], s)


def set_subtitle(root, s):
    """부제는 앞뒤 '- … -'를 자동으로 붙임."""
    s = s.strip().strip('-').strip()
    set_line(top_paras(root)[I_SUB], f'- {s} -')


def set_body(root, paragraphs, blank_between=True):
    """본문을 paragraphs(문장 덩어리 목록)로 교체. 각 문단 앞 공백 2칸 자동, 문단 사이 빈 줄."""
    ps = top_paras(root)
    body = ps[I_BODY:]
    first_proto, other_proto, blank_proto = body[0], body[2], body[1]
    anchor = ps[I_BODY - 1]
    protos = (copy.deepcopy(first_proto), copy.deepcopy(other_proto), copy.deepcopy(blank_proto))
    for p in body:
        p.getparent().remove(p)
    cur = anchor
    for i, s in enumerate(paragraphs):
        q = copy.deepcopy(protos[0] if i == 0 else protos[1])
        set_line(q, '  ' + s.strip())
        cur.addnext(q)
        cur = q
        if blank_between or i == len(paragraphs) - 1:
            b = copy.deepcopy(protos[2])
            set_line(b, '')
            cur.addnext(b)
            cur = b


# ---------- 검사 ----------
def _fixed_xml(root):
    """고정 영역: 머리 표 1~2행(슬로건·'보 도 자 료'·칸 이름)과 겹선 문단."""
    t = header_table(root)
    out = []
    for tc in t.iter(HP + 'tc'):
        if int(tc.find(HP + 'cellAddr').get('rowAddr')) <= 1:
            c = copy.deepcopy(tc)
            for e in list(c.iter(HP + 'linesegarray')):
                e.getparent().remove(e)
            out.append(etree.tostring(c))
    ln = copy.deepcopy(top_paras(root)[I_LINE])
    for e in list(ln.iter(HP + 'linesegarray')):
        e.getparent().remove(e)
    out.append(etree.tostring(ln))
    return out


def check(root, template_path):
    _, _, troot = load(template_path)
    assert _fixed_xml(root) == _fixed_xml(troot), '머리 표(슬로건·보 도 자 료·칸 이름) 또는 겹선이 양식과 다릅니다'
    body = text(root)
    for ph in ('[제목]', '[부제]', '[본문]'):
        assert ph not in body, f'양식 자리표시 {ph}가 남아 있습니다'
    return True


if __name__ == '__main__':
    files, order, root = load(sys.argv[1])
    for i, p in enumerate(top_paras(root)):
        print(i, repr(text(p)[:90]))
