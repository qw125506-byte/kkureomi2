"""hwpx_fill.py — 천안시 결과보고 붙임 양식(.hwpx) 채우기 도우미"""
import copy, sys, zipfile
from lxml import etree

HP = '{http://www.hancom.co.kr/hwpml/2011/paragraph}'


def load(path):
    z = zipfile.ZipFile(path)
    files = {n: z.read(n) for n in z.namelist()}
    order = z.namelist()
    root = etree.fromstring(files['Contents/section0.xml'])
    return files, order, root


def save(files, order, root, out):
    for e in list(root.iter(HP + 'linesegarray')):  # 한글이 줄 배치를 다시 계산하도록
        e.getparent().remove(e)
    files['Contents/section0.xml'] = etree.tostring(
        root, xml_declaration=True, encoding='UTF-8', standalone=True)
    with zipfile.ZipFile(out, 'w') as z:
        z.writestr(zipfile.ZipInfo('mimetype'), files['mimetype'], compress_type=zipfile.ZIP_STORED)
        for n in order:
            if n != 'mimetype':
                z.writestr(n, files[n], compress_type=zipfile.ZIP_DEFLATED)


def text(el):
    return ''.join(t.text or '' for t in el.iter(HP + 't'))


def paras(el):
    return list(el.iter(HP + 'p'))


# ---------- 문단 ----------
def set_para(p, s, run_idx=-1):
    """문단의 run 하나(기본: 마지막)에 글자를 넣고 같은 문단의 다른 run 글자는 유지."""
    runs = p.findall(HP + 'run')
    r = runs[run_idx]
    ts = r.findall(HP + 't')
    if not ts:
        ts = [etree.SubElement(r, HP + 't')]
    ts[0].text = s
    for t in ts[1:]:
        r.remove(t)


def set_line(p, s):
    """문단 전체를 s 한 줄로: 첫 run에 넣고 나머지 run의 글자는 비움(글자 모양은 첫 run 것)."""
    runs = p.findall(HP + 'run')
    for r in runs[1:]:
        for t in r.findall(HP + 't'):
            r.remove(t)
    set_para(p, s, 0)


def append_para(p, s):
    """라벨 뒤에 값 붙이기: 마지막 run의 글자 끝에 s 추가."""
    r = p.findall(HP + 'run')[-1]
    ts = r.findall(HP + 't')
    if not ts:
        etree.SubElement(r, HP + 't').text = s
    else:
        ts[-1].text = (ts[-1].text or '') + s


def clone_para_after(p, s=None):
    q = copy.deepcopy(p)
    p.addnext(q)
    if s is not None:
        set_para(q, s)
    return q


def remove(el):
    el.getparent().remove(el)


# ---------- 표 ----------
def find_table(root, *needles, nth=0):
    """첫 행(또는 표 전체) 글자에 needles가 모두 들어 있는 표 중 nth번째."""
    hits = [t for t in root.iter(HP + 'tbl') if all(n in text(t) for n in needles)]
    return hits[nth]


def rows(tbl):
    return tbl.findall(HP + 'tr')


def cell(tbl, r, c):
    for tc in tbl.iter(HP + 'tc'):
        a = tc.find(HP + 'cellAddr')
        if int(a.get('rowAddr')) == r and int(a.get('colAddr')) == c:
            return tc
    raise KeyError((r, c))


def set_cell(tc, lines):
    """셀 글자를 lines(문자열 또는 리스트)로. 첫 문단을 원형으로 복제해 줄 수를 맞춤."""
    if isinstance(lines, str):
        lines = [lines]
    sub = tc.find(HP + 'subList')
    ps = sub.findall(HP + 'p')
    proto = ps[0]
    for p in ps[1:]:
        sub.remove(p)
    set_para(proto, lines[0], 0)
    for r in proto.findall(HP + 'run')[1:]:
        for t in r.findall(HP + 't'):
            r.remove(t)
    last = proto
    for s in lines[1:]:
        last = clone_para_after(last, None)
        set_para(last, s, 0)


def _renumber(tbl):
    trs = rows(tbl)
    for i, tr in enumerate(trs):
        for tc in tr.findall(HP + 'tc'):
            tc.find(HP + 'cellAddr').set('rowAddr', str(i))
    tbl.set('rowCnt', str(len(trs)))
    h = sum(max(int(tc.find(HP + 'cellSz').get('height')) for tc in tr.findall(HP + 'tc')) for tr in trs)
    tbl.find(HP + 'sz').set('height', str(h))


def resize_rows(tbl, n_body, proto=1, header=1):
    """머리행 header개를 두고 본문 행을 n_body개로 맞춤(proto번째 행 복제/뒤에서 삭제)."""
    trs = rows(tbl)
    body = trs[header:]
    while len(body) < n_body:
        nr = copy.deepcopy(trs[proto])
        body[-1].addnext(nr)
        body.append(nr)
    for tr in body[n_body:]:
        tbl.remove(tr)
    _renumber(tbl)


def merge_down(tbl, r, c, n):
    """(r,c) 셀을 아래로 n행 병합하고 가려지는 셀 삭제."""
    top = cell(tbl, r, c)
    top.find(HP + 'cellSpan').set('rowSpan', str(n))
    h = 0
    for i in range(r, r + n):
        tc = cell(tbl, i, c)
        h += int(tc.find(HP + 'cellSz').get('height'))
        if i > r:
            tc.getparent().remove(tc)
    top.find(HP + 'cellSz').set('height', str(h))


def table_para(tbl):
    """표를 담은 바깥 문단(쪽 나눔·복제 단위)."""
    p = tbl.getparent()
    while p.tag != HP + 'p':
        p = p.getparent()
    return p


def rects(root):
    """글상자(점선 상자) 목록 — 순서: 0 표지 핵심의견, 1 Ⅰ총평, 2 Ⅱ개요."""
    return list(root.iter(HP + 'rect'))


def drop_minutes(root):
    """기본 구성: 붙임 1 회의록(띠+표) 삭제, 붙임 번호 당김, 참석자 명단 앞 쪽 나눔, 붙임 목록 2줄로."""
    b1 = find_table(root, '붙임 1', '회의록')
    mt = find_table(root, '세부내용')
    b2 = find_table(root, '붙임 2', '참석자 명단')
    b3 = find_table(root, '붙임 3', '간담회 사진')
    for t in (b1, mt):
        remove(table_para(t))
    for b, n in ((b2, '붙임 1'), (b3, '붙임 2')):
        for t in b.iter(HP + 't'):
            if t.text and t.text.startswith('붙임'):
                t.text = n
    table_para(b2).set('pageBreak', '1')
    lst = [p for p in root.findall(HP + 'p')
           if text(p).startswith(('붙임 1.', '     2.', '     3.'))]
    set_line(lst[0], '붙임 1. 참석자 명단 1부.')
    set_line(lst[1], '     2. 간담회 사진 1부. 끝. ')
    remove(lst[2])


# ---------- 결재란 (고정) ----------
def approval_table(root):
    return find_table(root, '문서번호', '담당자')


def _approval_cells(root):
    """결재 칸(담당자~시장·결재·협조 = 열 2 이상) 셀들의 XML. 줄배치 정보는 비교에서 제외."""
    out = []
    for tc in approval_table(root).iter(HP + 'tc'):
        if int(tc.find(HP + 'cellAddr').get('colAddr')) >= 2:
            c = copy.deepcopy(tc)
            for e in list(c.iter(HP + 'linesegarray')):
                e.getparent().remove(e)
            out.append(etree.tostring(c))
    return out


def set_doc_dept(root, dept):
    """결재란 왼쪽 '문서번호' 값 칸의 ○○○만 부서명으로 (예: '청년정책'). 결재 칸은 건드리지 않음."""
    tc = cell(approval_table(root), 0, 1)
    for t in tc.iter(HP + 't'):
        if t.text and '○○○' in t.text:
            t.text = t.text.replace('○○○', dept)


def check_approval(root, template_path):
    """결재 칸이 양식과 한 글자도 다르지 않은지 확인. 다르면 AssertionError."""
    _, _, troot = load(template_path)
    assert _approval_cells(root) == _approval_cells(troot), '결재란이 양식과 다릅니다 - 수정 금지 영역'
    return True


if __name__ == '__main__':
    files, order, root = load(sys.argv[1])
    for i, t in enumerate(root.iter(HP + 'tbl')):
        print(i, t.get('rowCnt'), 'x', t.get('colCnt'), repr(text(t)[:60]))
