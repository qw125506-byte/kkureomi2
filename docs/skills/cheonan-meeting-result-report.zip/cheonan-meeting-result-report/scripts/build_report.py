"""build_report.py — 천안시 간담회 결과보고서(.hwpx)를 양식에 데이터(JSON)로 채워 만든다.

usage:  python3 build_report.py data.json out.hwpx [--template assets/template.hwpx]

data.json 예시는 SKILL.md 참고. 결재란(담당자~시장·결재·협조)은 양식 그대로 고정된다.
"""
import copy, json, os, re, sys, zipfile
from lxml import etree

HP = '{http://www.hancom.co.kr/hwpml/2011/paragraph}'
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_TEMPLATE = os.path.join(HERE, '..', 'assets', 'template.hwpx')


# ---------------- io ----------------
def load(path):
    z = zipfile.ZipFile(path)
    files = {n: z.read(n) for n in z.namelist()}
    return files, z.namelist(), etree.fromstring(files['Contents/section0.xml'])


def save(files, order, root, out):
    _oid = 1000000000
    for _z, _o in enumerate(x for x in (root).iter() if x.tag in (HP + 'tbl', HP + 'rect', HP + 'pic', HP + 'line')):
        _o.set('id', str(_oid + _z))
        _o.set('zOrder', str(_z))
    for e in list(root.iter(HP + 'linesegarray')):
        e.getparent().remove(e)
    files['Contents/section0.xml'] = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
    with zipfile.ZipFile(out, 'w') as z:
        z.writestr(zipfile.ZipInfo('mimetype'), files['mimetype'], compress_type=zipfile.ZIP_STORED)
        for n in order:
            if n != 'mimetype':
                z.writestr(n, files[n], compress_type=zipfile.ZIP_DEFLATED)


def text(e):
    return ''.join(t.text or '' for t in e.iter(HP + 't'))


# ---------------- 표기 규칙 ----------------
def spaced_name(n):
    """'김경수' -> '김 경 수' (이미 띄어 있으면 정규화)"""
    n = (n or '').replace(' ', '')
    return ' '.join(n) if n else ''


def spaced_title(t):
    """2글자 직위는 가운데 공백 2칸: '총장' -> '총  장'"""
    t = (t or '').replace(' ', '')
    return f'{t[0]}  {t[1]}' if len(t) == 2 else t


# ---------------- 자리표시 치환 ----------------
def fill_markers(el, mapping):
    """el 안 <hp:t>의 {{키}}를 mapping 값으로 치환. 값이 None이면 그대로."""
    for t in el.iter(HP + 't'):
        if t.text and '{{' in t.text:
            def rep(m):
                v = mapping.get(m.group(1))
                return m.group(0) if v is None else str(v)
            t.text = re.sub(r'\{\{([^}]+)\}\}', rep, t.text)


def find_para_with(root, marker):
    for p in root.iter(HP + 'p'):
        own = ''.join(t.text or '' for r in p.findall(HP + 'run') for t in r.findall(HP + 't'))
        if marker in own:
            return p
    raise KeyError(marker)


def repeat_para(root, marker, values, mapper):
    """marker가 든 문단을 values 개수만큼 복제해 채움. values가 비면 문단 삭제."""
    proto = find_para_with(root, marker)
    parent = proto.getparent()
    cur = proto
    for v in values:
        q = copy.deepcopy(proto)
        fill_markers(q, mapper(v))
        cur.addnext(q)
        cur = q
    parent.remove(proto)


def table_with(root, marker):
    for t in root.iter(HP + 'tbl'):
        if marker in text(t):
            return t
    raise KeyError(marker)


def holder_of(el):
    p = el.getparent()
    while p is not None and not (p.tag == HP + 'p' and p.getparent().tag.endswith('sec')):
        p = p.getparent()
    return p


def renumber(tbl):
    trs = tbl.findall(HP + 'tr')
    for i, tr in enumerate(trs):
        for tc in tr.findall(HP + 'tc'):
            tc.find(HP + 'cellAddr').set('rowAddr', str(i))
    tbl.set('rowCnt', str(len(trs)))
    h = sum(max(int(tc.find(HP + 'cellSz').get('height')) for tc in tr.findall(HP + 'tc')) for tr in trs)
    tbl.find(HP + 'sz').set('height', str(h))


def fill_rows(tbl, items, mapper, proto_idx=1, last_proto_idx=None):
    """머리행 다음 원형 행을 items 수만큼 복제. last_proto_idx가 있으면 마지막 행은 그 원형(굵은 아래 테두리)."""
    trs = tbl.findall(HP + 'tr')
    proto = trs[proto_idx]
    last_proto = trs[last_proto_idx] if last_proto_idx is not None else proto
    for tr in trs[1:]:
        tbl.remove(tr)
    for i, it in enumerate(items):
        src = last_proto if (i == len(items) - 1) else proto
        tr = copy.deepcopy(src)
        for tc in tr.findall(HP + 'tc'):
            mp = mapper(it, i)
            # 여러 줄 값(list)은 해당 셀의 원형 문단을 복제
            for key, val in list(mp.items()):
                if isinstance(val, list):
                    try:
                        p = next(p for p in tc.iter(HP + 'p') if '{{%s}}' % key in text(p))
                    except StopIteration:
                        continue
                    cur = p
                    for v in val:
                        q = copy.deepcopy(p)
                        fill_markers(q, {key: v})
                        cur.addnext(q)
                        cur = q
                    p.getparent().remove(p)
            fill_markers(tc, {k: v for k, v in mp.items() if not isinstance(v, list)})
        tbl.append(tr)
    renumber(tbl)


def merge_down(tbl, r, c, n):
    if n <= 1:
        return
    cells = {(int(tc.find(HP + 'cellAddr').get('rowAddr')), int(tc.find(HP + 'cellAddr').get('colAddr'))): tc
             for tc in tbl.iter(HP + 'tc')}
    top = cells[(r, c)]
    top.find(HP + 'cellSpan').set('rowSpan', str(n))
    h = 0
    for i in range(r, r + n):
        tc = cells[(i, c)]
        h += int(tc.find(HP + 'cellSz').get('height'))
        if i > r:
            tc.getparent().remove(tc)
    top.find(HP + 'cellSz').set('height', str(h))


# ---------------- 결재란 고정 ----------------
def approval_cells(root):
    t = next(t for t in root.iter(HP + 'tbl') if '문서번호' in text(t) and '담당자' in text(t))
    out = []
    for tc in t.iter(HP + 'tc'):
        if int(tc.find(HP + 'cellAddr').get('colAddr')) >= 2:
            c = copy.deepcopy(tc)
            for e in list(c.iter(HP + 'linesegarray')):
                e.getparent().remove(e)
            out.append(etree.tostring(c))
    return t, out


# ---------------- main ----------------
REQUIRED = {
    '부서': str, '제목': str, '도입문': str, '총평': list, '의견': list,
    '표지': {'일시': str, '장소': str, '참석': str, '주요내용': str, '핵심의견': list},
    '개요': {'일시': str, '장소': str, '참석대상': str},
}


def validate(data, spec=REQUIRED, path=''):
    errs = []
    for k, typ in spec.items():
        if k not in data or data[k] in (None, '', []):
            errs.append(f'{path}{k}')
        elif isinstance(typ, dict):
            errs += validate(data[k], typ, f'{path}{k}.')
        elif not isinstance(data[k], typ):
            errs.append(f'{path}{k}(형식: {typ.__name__})')
    return errs


def build(data, out, template=DEFAULT_TEMPLATE):
    errs = validate(data)
    if errs:
        raise SystemExit('data.json에 필요한 항목이 없습니다: ' + ', '.join(errs))
    files, order, root = load(template)
    _, appr_before = approval_cells(root)
    warn = []

    dept = data['부서']                       # 예: 청년정책과
    title = data['제목']
    ops = data.get('의견', [])
    n_ops = len(ops)

    # 결재란: 문서번호의 ○○○과만
    appr, _ = approval_cells(root)
    for tc in appr.iter(HP + 'tc'):
        a = tc.find(HP + 'cellAddr')
        if a.get('rowAddr') == '0' and a.get('colAddr') == '1':
            for t in tc.iter(HP + 't'):
                if t.text and '○○○과' in t.text:
                    t.text = t.text.replace('○○○과', dept)

    # 표지
    cv = data['표지']
    cover_map = {
        '제목': title, '부서': dept,
        '일시': cv['일시'], '장소': cv['장소'],
        '참석': cv['참석'], '참석_주': (' ' + cv['참석_주']) if cv.get('참석_주') else '',
        '주요내용': cv['주요내용'], '주요내용_주': (' ' + cv['주요내용_주']) if cv.get('주요내용_주') else '',
        '의견수렴': cv.get('의견수렴') or f'주요의견 [총 {n_ops}건]',
        '향후계획요약': cv.get('향후계획', '관련부서 검토 후 처리 예정'),
        '도입문': data['도입문'],
        '의견제목': f"{data.get('의견_구분', '참석자')}별 의견수렴 내용 [총{n_ops}건]",
    }
    ov = data['개요']
    cover_map.update({'개요_일시': ov['일시'], '개요_장소': ov['장소'], '개요_참석대상': ov['참석대상']})
    repeat_para(root, '{{핵심의견}}', cv['핵심의견'], lambda v: {'핵심의견': v})
    repeat_para(root, '{{총평}}', data['총평'], lambda v: {'총평': v})
    repeat_para(root, '{{회의내용}}', ov.get('회의내용', []), lambda v: {'회의내용': v})

    # 의견 표
    op_tbl = table_with(root, '{{건의사항}}')
    def op_map(o, i):
        det = o['세부내용'] if isinstance(o['세부내용'], list) else [o['세부내용']]
        det = [d.strip().lstrip('-').strip() for d in det if d and d.strip()]
        one, many = (det, []) if len(det) == 1 else ([], ['- ' + d for d in det])
        return {'연번': i + 1, '기관': o['기관'], '직위': spaced_title(o['직위']),
                '성명': f"({spaced_name(o['성명'])})", '건의사항': o['건의사항'],
                '세부1': one, '세부내용': many, '관련부서': o.get('관련부서') or '확인필요'}
    fill_rows(op_tbl, ops, op_map)

    # 향후계획
    plan = data.get('향후계획') or [{'내용': '소관 부서 검토 확인', '비고': '확인필요'},
                                    {'내용': '소관 부서 검토사항 대장 정리', '비고': '확인필요'},
                                    {'내용': '추진 가능사업 사후 관리', '비고': '확인필요'}]
    plan_tbl = table_with(root, '{{내용}}')
    fill_rows(plan_tbl, plan, lambda p, i: {'연번': i + 1, '내용': p['내용'], '비고': p.get('비고', '')},
              proto_idx=1, last_proto_idx=2)

    # 붙임 구성
    minutes = data.get('회의록') or []
    attachments = (['회의록'] if minutes else []) + ['참석자 명단', '간담회 사진']
    lst = [p for p in root.findall(HP + 'p') if text(p).startswith(('붙임 1.', '     2.', '     3.'))]
    for i, p in enumerate(lst):
        if i < len(attachments):
            s = ('붙임 ' if i == 0 else '     ') + f'{i + 1}. {attachments[i]} 1부.'
            if i == len(attachments) - 1:
                s += '  끝.'
            r = p.findall(HP + 'run')[0]
            r.findall(HP + 't')[0].text = s
        else:
            p.getparent().remove(p)

    min_tbl = table_with(root, '{{요지}}')
    min_bar = next(t for t in root.iter(HP + 'tbl') if '회의록' in text(t) and '붙임' in text(t))
    if minutes:
        fill_rows(min_tbl, minutes, lambda m, i: {'발언자': spaced_title(m['발언자']) if len(m['발언자'].replace(' ', '')) == 2 else m['발언자'],
                                                  '성명': f"({spaced_name(m['성명'])})" if m.get('성명') else '',
                                                  '요지': [s.lstrip('- ') for s in m['요지']]})
    else:
        sec = root
        hp_bar = holder_of(min_bar)
        hp_tbl = holder_of(min_tbl)
        # 띠와 표 사이의 간격 문단까지 삭제
        sibs = list(sec)
        a, b = sibs.index(hp_bar), sibs.index(hp_tbl)
        for p in sibs[a:b + 1]:
            sec.remove(p)

    # 붙임 번호
    n = 1
    for name in attachments:
        bar = next(t for t in root.iter(HP + 'tbl') if '붙임 {{n}}' in text(t) and name in text(t))
        fill_markers(bar, {'n': n})
        n += 1

    # 참석자
    ppl = data.get('참석자', [])
    att_tbl = table_with(root, '{{기관}}')  # 의견 표는 이미 채워졌으므로 참석자 표만 남음
    fill_rows(att_tbl, ppl, lambda p, i: {'연번': i + 1, '기관': p['기관'], '직위': p['직위'],
                                         '성명': spaced_name(p['성명']), '비고': p.get('비고', '')})
    # 같은 기관 연속이면 세로 병합 (아래에서 위로)
    runs, start = [], 0
    for i in range(1, len(ppl) + 1):
        if i == len(ppl) or ppl[i]['기관'] != ppl[start]['기관']:
            runs.append((start, i - start))
            start = i
    for s, cnt in reversed(runs):
        merge_down(att_tbl, s + 1, 1, cnt)

    # 나머지 자리표시 일괄
    fill_markers(root, cover_map)

    # ---------- 검사 ----------
    _, appr_after = approval_cells(root)
    assert appr_after == appr_before, '결재란이 양식과 다릅니다'
    left = re.findall(r'\{\{[^}]+\}\}', text(root))
    assert not left, f'채우지 않은 자리표시: {sorted(set(left))}'
    m = re.search(r'총\s*(\d+)\s*건', cover_map['의견수렴'])
    if m and int(m.group(1)) != n_ops:
        warn.append(f"표지 의견수렴 건수({m.group(1)}건)와 의견 표 행 수({n_ops}건)가 다릅니다")
    if cv['일시'].replace(' ', '') != ov['일시'].replace(' ', ''):
        warn.append(f"표지 일시({cv['일시']})와 개요 일시({ov['일시']})가 다릅니다")

    save(files, order, root, out)
    return warn


if __name__ == '__main__':
    args = sys.argv[1:]
    tpl = DEFAULT_TEMPLATE
    if '--template' in args:
        i = args.index('--template')
        tpl = args[i + 1]
        del args[i:i + 2]
    data = json.load(open(args[0], encoding='utf-8'))
    w = build(data, args[1], tpl)
    print('완료:', args[1])
    for x in w:
        print('확인필요:', x)
