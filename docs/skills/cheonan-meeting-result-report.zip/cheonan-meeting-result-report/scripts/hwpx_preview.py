"""hwpx_preview.py — 결과물 배치를 대략 확인하는 미리보기 (HWPX -> HTML -> PNG). 한글 화면과 100% 같지는 않음.
usage: python3 hwpx_preview.py in.hwpx out_prefix
Produces out_prefix.html and out_prefix-N.png per page. Overflowing text boxes/cells are outlined red.
"""
import sys, zipfile, base64, html, re
from lxml import etree

HP = '{http://www.hancom.co.kr/hwpml/2011/paragraph}'
HH = '{http://www.hancom.co.kr/hwpml/2011/head}'
HC = '{http://www.hancom.co.kr/hwpml/2011/core}'
MM = 283.465  # HWPUNIT per mm

PUA = {'': '❍', '': '❖', '': '▪', '': '■', '': '✔'}


def mm(v):
    return f'{int(v) / MM:.2f}mm'


def font_family(face):
    f = face or ''
    serif = any(k in f for k in ('명조', '바탕', '신명조', 'Batang', 'Myeong'))
    return "'Noto Serif CJK KR', serif" if serif else "'Noto Sans CJK KR', sans-serif"


class Doc:
    def __init__(self, path):
        z = zipfile.ZipFile(path)
        self.z = z
        self.head = etree.fromstring(z.read('Contents/header.xml'))
        self.sec = etree.fromstring(z.read('Contents/section0.xml'))
        self.fonts = {}
        for ff in self.head.iter(HH + 'fontface'):
            if ff.get('lang') == 'HANGUL':
                for f in ff.findall(HH + 'font'):
                    self.fonts[f.get('id')] = f.get('face')
        self.chars = {}
        for cp in self.head.iter(HH + 'charPr'):
            fr = cp.find(HH + 'fontRef')
            sp = cp.find(HH + 'spacing')
            ra = cp.find(HH + 'ratio')
            ul = cp.find(HH + 'underline')
            self.chars[cp.get('id')] = dict(
                size=int(cp.get('height')) / 100.0,
                color=cp.get('textColor', '#000000'),
                bold=cp.find(HH + 'bold') is not None,
                face=self.fonts.get(fr.get('hangul')) if fr is not None else None,
                spacing=int(sp.get('hangul')) if sp is not None else 0,
                ratio=int(ra.get('hangul')) if ra is not None else 100,
                underline=(ul is not None and ul.get('type') not in (None, 'NONE')),
                shade=cp.get('shadeColor'))
        self.paras = {}
        for pp in self.head.iter(HH + 'paraPr'):
            al = pp.find(HH + 'align')
            ls = pp.find('.//' + HH + 'lineSpacing')
            mg = pp.find('.//' + HH + 'margin')
            m = {}
            if mg is not None:
                for x in mg:
                    m[etree.QName(x).localname] = int(x.get('value', 0))
            self.paras[pp.get('id')] = dict(
                align=al.get('horizontal') if al is not None else 'LEFT',
                ls_type=ls.get('type') if ls is not None else 'PERCENT',
                ls=int(ls.get('value')) if ls is not None else 160,
                **{k: m.get(k, 0) for k in ('intent', 'left', 'right', 'prev', 'next')})
        self.bfs = {}
        for bf in self.head.iter(HH + 'borderFill'):
            d = {}
            for side in ('left', 'right', 'top', 'bottom'):
                b = bf.find(HH + side + 'Border')
                if b is not None:
                    d[side] = (b.get('type'), b.get('width'), b.get('color'))
            wb = bf.find('.//' + HC + 'winBrush')
            gr = bf.find('.//' + HC + 'gradation')
            d['fill'] = wb.get('faceColor') if wb is not None and wb.get('faceColor') not in (None, 'none') else None
            d['grad'] = [c.get('value') for c in gr] if gr is not None else None
            self.bfs[bf.get('id')] = d
        self.bins = {}
        for n in z.namelist():
            if n.startswith('BinData/'):
                stem = n.split('/')[-1].rsplit('.', 1)[0]
                ext = n.rsplit('.', 1)[-1].lower()
                mime = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif', 'bmp': 'image/bmp'}.get(ext, 'image/png')
                self.bins[stem] = f'data:{mime};base64,' + base64.b64encode(z.read(n)).decode()

    # ---------- css helpers ----------
    def border_css(self, bfid):
        d = self.bfs.get(bfid, {})
        out = []
        for side in ('left', 'right', 'top', 'bottom'):
            t = d.get(side)
            if not t or t[0] in (None, 'NONE'):
                out.append(f'border-{side}:none')
                continue
            w = float(re.sub('[^0-9.]', '', t[1] or '0.12') or 0.12)
            style = {'SOLID': 'solid', 'DASH': 'dashed', 'DOT': 'dotted', 'DOUBLE_SLIM': 'double',
                     'SLIM_THICK': 'double', 'THICK_SLIM': 'double'}.get(t[0], 'solid')
            if style == 'double':
                w = max(w, 0.6)
            out.append(f'border-{side}:{max(w, 0.1):.2f}mm {style} {t[2]}')
        if d.get('grad'):
            out.append(f'background:linear-gradient(90deg,{d["grad"][0]},{d["grad"][-1]})')
        elif d.get('fill'):
            out.append(f'background:{d["fill"]}')
        return ';'.join(out)

    def run_html(self, r):
        c = self.chars.get(r.get('charPrIDRef'), self.chars.get('0'))
        parts = []
        for ch in r:
            ln = etree.QName(ch).localname
            if ln == 't':
                s = ch.text or ''
                for k, v in PUA.items():
                    s = s.replace(k, v)
                s = html.escape(s).replace(' ', '&nbsp;') if s.strip() == '' else html.escape(s)
                # keep runs of spaces
                s = re.sub(r'  ', ' &nbsp;', s)
                parts.append(s)
                for sub in ch:  # tabs / line breaks inside t
                    if etree.QName(sub).localname == 'lineBreak':
                        parts.append('<br>')
                    if sub.tail:
                        parts.append(html.escape(sub.tail))
            elif ln in ('tbl', 'pic', 'rect', 'line', 'container'):
                parts.append(self.obj_html(ch))
        txt = ''.join(parts)
        if not txt:
            return ''
        style = (f"font-size:{c['size']}pt;color:{c['color']};font-family:{font_family(c['face'])};"
                 f"letter-spacing:{c['spacing'] / 100.0 * c['size']:.2f}pt;"
                 f"font-weight:{'700' if c['bold'] else '400'};")
        if c['underline']:
            style += 'text-decoration:underline;'
        if c['ratio'] != 100:
            style += f"display:inline-block;transform:scaleX({c['ratio'] / 100});transform-origin:left;"
            # inline-block with scaleX breaks wrapping; only for short runs
            if len(re.sub('<[^>]+>', '', txt)) > 12:
                style = style.replace(f"display:inline-block;transform:scaleX({c['ratio'] / 100});transform-origin:left;", '')
        return f'<span style="{style}">{txt}</span>'

    def para_html(self, p, extra=''):
        pp = self.paras.get(p.get('paraPrIDRef'), self.paras.get('0'))
        runs = p.findall(HP + 'run')
        # paragraph font size = largest run size
        sizes = [self.chars.get(r.get('charPrIDRef'), {}).get('size', 10) for r in runs] or [10]
        fs = max(sizes)
        inner = ''.join(self.run_html(r) for r in runs)
        blocks = re.findall(r'<(?:table|div class="obj)', inner)
        al = {'LEFT': 'left', 'RIGHT': 'right', 'CENTER': 'center', 'JUSTIFY': 'justify', 'DISTRIBUTE': 'justify'}.get(pp['align'], 'left')
        lh = (pp['ls'] / 100.0) if pp['ls_type'] == 'PERCENT' else 1.6
        intent = pp['intent']
        left = pp['left']
        if intent < 0:  # 내어쓰기
            pad = left + (-intent)
            ti = intent
        else:
            pad = left
            ti = intent
        style = (f"text-align:{al};{'text-align-last:justify;' if pp['align']=='DISTRIBUTE' else ''}"
                 f"line-height:{lh:.2f};font-size:{fs}pt;padding-left:{mm(pad)};text-indent:{mm(ti)};"
                 f"padding-right:{mm(pp['right'])};margin-top:{mm(pp['prev'])};margin-bottom:{mm(pp['next'])};"
                 f"min-height:{fs * lh:.1f}pt;white-space:pre-wrap;word-break:keep-all;")
        if not inner:
            inner = '&nbsp;'
        pb = ' data-pb="1"' if p.get('pageBreak') == '1' else ''
        return f'<div class="p"{pb} style="{style}{extra}">{inner}</div>'

    def obj_html(self, o):
        ln = etree.QName(o).localname
        sz = o.find(HP + 'sz')
        pos = o.find(HP + 'pos')
        w = int(sz.get('width')) if sz is not None else 0
        h = int(sz.get('height')) if sz is not None else 0
        absolute = pos is not None and pos.get('treatAsChar') == '0' and pos.get('vertRelTo') in ('PAPER', 'PAGE')
        posstyle = ''
        if absolute:
            posstyle = f"position:absolute;left:{mm(pos.get('horzOffset'))};top:{mm(pos.get('vertOffset'))};z-index:2;"
        if ln == 'tbl':
            center = pos is not None and pos.get('horzAlign') == 'CENTER' and pos.get('treatAsChar') != '1'
            inline_tbl = pos is not None and pos.get('treatAsChar') == '1'
            rows = []
            for tr in o.findall(HP + 'tr'):
                cells = []
                for tc in tr.findall(HP + 'tc'):
                    cs = tc.find(HP + 'cellSpan')
                    csz = tc.find(HP + 'cellSz')
                    sub = tc.find(HP + 'subList')
                    va = {'TOP': 'top', 'CENTER': 'middle', 'BOTTOM': 'bottom'}.get(sub.get('vertAlign'), 'middle')
                    cm = tc.find(HP + 'cellMargin')
                    pad = ''
                    if cm is not None:
                        pad = f"padding:{mm(cm.get('top'))} {mm(cm.get('right'))} {mm(cm.get('bottom'))} {mm(cm.get('left'))};"
                    inner = ''.join(self.para_html(p) for p in sub.findall(HP + 'p'))
                    cells.append(
                        f'<td class="cell" rowspan="{cs.get("rowSpan")}" colspan="{cs.get("colSpan")}" '
                        f'style="width:{mm(csz.get("width"))};height:{mm(csz.get("height"))};vertical-align:{va};{pad}'
                        f'{self.border_css(tc.get("borderFillIDRef"))}">{inner}</td>')
                rows.append('<tr>' + ''.join(cells) + '</tr>')
            margin = 'margin:0 auto;' if center else ''
            disp = 'display:inline-table;vertical-align:top;text-indent:0;text-align:left;' if inline_tbl else ''
            return (f'<table class="obj" style="{posstyle}{margin}{disp}width:{mm(w)};border-collapse:collapse;table-layout:fixed;">'
                    + ''.join(rows) + '</table>')
        if ln == 'pic':
            img = o.find('.//' + HC + 'img')
            src = self.bins.get(img.get('binaryItemIDRef'), '') if img is not None else ''
            return f'<img class="obj" src="{src}" style="{posstyle}width:{mm(w)};height:{mm(h)};vertical-align:middle">'
        if ln == 'rect':
            ls = o.find(HP + 'lineShape')
            style = {'DASH': 'dashed', 'DOT': 'dotted', 'SOLID': 'solid'}.get(ls.get('style') if ls is not None else 'SOLID', 'solid')
            lw = int(ls.get('width', 33)) / MM if ls is not None else 0.12
            dt = o.find(HP + 'drawText')
            inner = ''
            pad = ''
            if dt is not None:
                tm = dt.find(HP + 'textMargin')
                if tm is not None:
                    pad = f"padding:{mm(tm.get('top'))} {mm(tm.get('right'))} {mm(tm.get('bottom'))} {mm(tm.get('left'))};"
                sub = dt.find(HP + 'subList')
                inner = ''.join(self.para_html(p) for p in sub.findall(HP + 'p'))
            return (f'<div class="obj box" style="{posstyle}box-sizing:border-box;width:{mm(w)};height:{mm(h)};{pad}'
                    f'border:{max(lw, 0.15):.2f}mm {style} #000;overflow:hidden;background:transparent">{inner}</div>')
        if ln == 'line':
            ls = o.find(HP + 'lineShape')
            st = ls.get('style') if ls is not None else 'SOLID'
            wid = int(ls.get('width', 33)) / MM if ls is not None else 0.12
            css = f'border-top:{max(wid, 0.6):.2f}mm double #000' if 'THICK' in st or 'DOUBLE' in st else f'border-top:{max(wid, 0.12):.2f}mm solid #000'
            return f'<div class="obj" style="{posstyle}width:{mm(w)};{css};height:0"></div>'
        return ''

    def render(self):
        pagepr = self.sec.find('.//' + HP + 'pagePr')
        mg = pagepr.find(HP + 'margin')
        W, H = int(pagepr.get('width')), int(pagepr.get('height'))
        pad = (f"padding:{mm(int(mg.get('top')) + int(mg.get('header')) * 0)} {mm(mg.get('right'))} "
               f"{mm(mg.get('bottom'))} {mm(mg.get('left'))};")
        pages = [[]]
        for p in self.sec.findall(HP + 'p'):
            if p.get('pageBreak') == '1' and pages[-1]:
                pages.append([])
            pages[-1].append(self.para_html(p))
        body = ''
        for i, pg in enumerate(pages):
            body += (f'<div class="page" style="width:{mm(W)};min-height:{mm(H)};{pad}">'
                     f'<div class="limit" style="top:{mm(H - int(mg.get("bottom")))}"></div>' + ''.join(pg) + '</div>')
        css = """
        body{margin:0;background:#888}
        .page{position:relative;background:#fff;box-sizing:border-box;margin:0 auto 8mm auto;overflow:visible}
        .limit{position:absolute;left:0;right:0;border-top:1px dashed #f0f;pointer-events:none}
        .p{margin:0}
        td.cell{overflow:hidden;box-sizing:border-box;padding:0.5mm 1.8mm}
        .ovf{outline:2px solid red !important}
        """
        js = """
        for (const el of document.querySelectorAll('.box,td.cell')) {
          if (el.scrollHeight > el.clientHeight + 2) el.classList.add('ovf');
        }
        """
        return f'<html><head><meta charset="utf-8"><style>{css}</style></head><body>{body}<script>{js}</script></body></html>'


def shoot(html_path, prefix):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 900, 'height': 1200}, device_scale_factor=1)
        pg.goto('file://' + html_path)
        pg.wait_for_timeout(300)
        pages = pg.query_selector_all('.page')
        outs = []
        for i, el in enumerate(pages):
            out = f'{prefix}-{i + 1}.png'
            el.screenshot(path=out)
            outs.append(out)
        ovf = pg.evaluate("document.querySelectorAll('.ovf').length")
        b.close()
        return outs, ovf


if __name__ == '__main__':
    d = Doc(sys.argv[1])
    out = sys.argv[2]
    open(out + '.html', 'w', encoding='utf-8').write(d.render())
    import os
    try:
        pngs, ovf = shoot(os.path.abspath(out + '.html'), out)
    except Exception as e:  # 브라우저가 없으면 HTML만
        print('PNG 생략(브라우저 없음):', type(e).__name__, '-', out + '.html 을 확인')
        sys.exit(0)
    print('pages', len(pngs), 'overflow-elements', ovf)
    for x in pngs:
        print(x)
