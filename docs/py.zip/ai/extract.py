# -*- coding: utf-8 -*-
"""AI 작업 3가지 — 자료→행사데이터 초안, 회의록→건의사항, 취지·보도자료 문장.

결과는 바로 문서로 가지 않고 초안(draft) JSON으로 저장해 사람이 확인한다.
숫자·날짜·이름은 공통 데이터에서 넣으므로, AI가 틀려도 문서의 사실관계는 데이터가 기준이다.
"""
import json
from pathlib import Path

from ai.client import ask_json, prompt

S = {"type": "string"}


def _field():
    return {"type": "object", "additionalProperties": False, "required": ["value", "source", "confidence"],
            "properties": {"value": S, "source": S, "confidence": {"type": "string", "enum": ["확실", "추정", "없음"]}}}


EXTRACT_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["title", "slogan", "date", "start", "end", "venue", "dept", "purpose", "agenda", "program", "attendees"],
    "properties": {
        "title": _field(), "slogan": _field(), "date": _field(), "start": _field(), "end": _field(),
        "venue": _field(), "dept": _field(),
        "purpose": {"type": "array", "items": S},
        "agenda": {"type": "array", "items": S},
        "program": {"type": "array", "items": {"type": "object", "additionalProperties": False,
                                               "required": ["minutes", "item", "lead"],
                                               "properties": {"minutes": {"type": "integer"}, "item": S, "lead": S}}},
        "attendees": {"type": "array", "items": {"type": "object", "additionalProperties": False,
                                                 "required": ["org", "position", "name"],
                                                 "properties": {"org": S, "position": S, "name": S}}},
    },
}

MINUTES_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["suggestions", "mayor_summary"],
    "properties": {
        "suggestions": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["org", "title", "detail", "depts"],
            "properties": {"org": S, "title": S, "detail": {"type": "array", "items": S},
                           "depts": {"type": "array", "items": S}}}},
        "mayor_summary": {"type": "array", "items": S},
    },
}

PRESS_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["title", "subtitle", "body", "quote"],
    "properties": {"title": S, "subtitle": S, "body": {"type": "array", "items": S}, "quote": S},
}

INTENT_SCHEMA = {"type": "object", "additionalProperties": False, "required": ["intent", "summary"],
                 "properties": {"intent": S, "summary": S}}


# ---------- 자료 읽기 ----------
def read_source(path):
    p = Path(path)
    suf = p.suffix.lower()
    if suf == ".hwpx":
        from core.hwpx import read_text
        return "\n".join(read_text(p))
    if suf == ".pdf":
        import pymupdf
        with pymupdf.open(p) as d:
            return "\n".join(page.get_text() for page in d)
    return p.read_text(encoding="utf-8", errors="replace")


# ---------- 1. 자료 → 행사데이터 초안 ----------
def extract_event(paths, client=None, use_ai=None):
    """자료 → 행사데이터 초안. AI를 쓸 수 있으면 AI, 아니면(또는 실패하면) 규칙(ai/local_extract.py)."""
    from ai import client as aic
    from ai.local_extract import extract as local
    text = "\n\n".join(f"[자료 {i + 1}: {Path(p).name}]\n{read_source(p)}" for i, p in enumerate(paths))
    use_ai = (client is not None or aic.available()) if use_ai is None else use_ai
    how, r = "규칙", None
    if use_ai:
        try:
            r = ask_json("extract", prompt("extract"), text, EXTRACT_SCHEMA, data=None, client=client)
            how = "AI"
        except (aic.AIUnavailable, aic.AIRefused):
            r = None
    r = r or local(text)
    v = {k: r[k]["value"] for k in ("title", "slogan", "date", "start", "end", "venue", "dept")}
    draft = {
        "_meta": {
            "출처": f"자료에서 추출한 초안({how}) — 문서로 만들기 전에 확인",
            "방식": how,
            "근거": {k: {"값": r[k]["value"], "근거": r[k]["source"], "확신": r[k]["confidence"]}
                   for k in ("title", "slogan", "date", "start", "end", "venue", "dept")},
            "확인필요": [f"{k}: {r[k]['confidence']}" for k in ("title", "date", "start", "venue", "dept")
                     if r[k]["confidence"] != "확실"],
        },
        "event": {k: v[k] for k in ("title", "slogan", "date", "start", "end", "venue") if v[k]},
        "org": {"city": "", "dept": v["dept"]},
        "host": {"position": "", "name": ""},
        "attendees": [dict(a) for a in r["attendees"]],
        "program": [dict(p) for p in r["program"]],
    }
    if r["purpose"]:
        draft["event"]["purpose"] = r["purpose"]
    if r["agenda"]:
        draft["event"]["agenda"] = r["agenda"]
    # 계획서 꼴(참석대상·배석·주재·취지·▶안건)은 규칙으로도 읽어 빈 곳을 채운다
    from ai.local_extract import extras_from_text
    ex = extras_from_text(text)
    for k, val in ex["event"].items():
        draft["event"].setdefault(k, val)
    if not draft["attendees"] and ex["attendees"]:
        draft["attendees"] = ex["attendees"]
    for k, val in ex.get("org", {}).items():
        draft["org"].setdefault(k, val)
    if ex["approval_line"]:
        draft["org"]["approval_line"] = ex["approval_line"]
    if ex["follow_up"]:
        draft["follow_up"] = ex["follow_up"]
    return draft


# ---------- 2. 회의록 → 건의사항·총평 ----------
def summarize_minutes(minutes_text, data, client=None):
    orgs = []
    for a in data["attendees"]:
        o = a.get("org_short") or a["org"]
        if o not in orgs:
            orgs.append(o)
    user = (f"기관 목록(이 순서로 모두): {', '.join(orgs) or '(없음)'}\n"
            f"주빈: {data['host']['position']}\n\n[회의록]\n{minutes_text}")
    r = ask_json("minutes", prompt("minutes"), user, MINUTES_SCHEMA, data=data, client=client)
    got = r["suggestions"]
    sugg = []
    for o in orgs:                         # 기관 순서 지키고, 빠진 기관은 「건의 없음」으로
        mine = [s for s in got if s["org"] == o and s["title"]]
        sugg += [{k: s[k] for k in ("org", "title", "detail", "depts")} for s in mine] or [{"org": o}]
    sugg += [{k: s[k] for k in ("org", "title", "detail", "depts")} for s in got
             if s["org"] not in orgs and s["title"]]
    return {"suggestions": sugg, "mayor_summary": r["mayor_summary"]}


# ---------- 3. 문장 초안 ----------
def facts(data):
    ev, d = data["event"], data["derived"]
    lines = [f"행사명: {ev['title']}", f"머리문구: {ev.get('slogan', '')}", f"일시: {d['when_text']}",
             f"장소: {ev['venue']}", f"주관: {data['org']['city']} {data['org']['dept']}",
             f"주빈: {data['host']['position']} {data['host']['name']}", f"참석: {d['attendee_text']}",
             "목적: " + " / ".join(ev.get("purpose") or []), "안건: " + " / ".join(ev.get("agenda") or []),
             "식순: " + " → ".join(p["item"] for p in data["program"])]
    res = data.get("result") or {}
    if res:
        lines.append(f"실제 종료: {res.get('actual_end', d['end'])}")
        lines += ["건의사항: " + "; ".join(f"{s['org']} {s['title']}" for s in res.get("suggestions") or [] if s.get("title"))]
        lines += ["시장 총평: " + " ".join(res.get("mayor_summary") or [])]
    return "\n".join(lines)


def write_intent(data, client=None):
    return ask_json("intent", prompt("intent"), facts(data), INTENT_SCHEMA, data=data, client=client)


def write_press(data, client=None):
    stage = "행사 후(결과)" if data.get("result") else "행사 전(예고)"
    r = ask_json("press", prompt("press"), f"[{stage}]\n{facts(data)}", PRESS_SCHEMA, data=data, client=client)
    return {k: r[k] for k in ("title", "subtitle", "body", "quote") if r[k]}


def save_draft(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return Path(path)
