# -*- coding: utf-8 -*-
"""회의록 「기관별 정리」 표 — 결과보고 붙임 1(대학명·직위·성명·발언내용·핵심요약·시장님답변·관련부서).

- 한 사람의 건의 하나가 한 행. 이름·직위·기관은 참석자 명단(계획서·화면) 표기로 맞춘다.
- 정리 규칙(사람이 정한 것): 발언·답변 시각, 「추정」·「확인 필요」 같은 작성 메모, 「개별 확정 답변은 없음」을 빼고,
  「공통 답변」은 「(공통답변)」으로, 「…하겠다고 설명함」은 「…하겠음」으로, 발언내용은 「제안함」 뒤를 자른다.
- 이미 이 꼴로 정리한 한글 파일(hwpx)을 회의록으로 올리면 그 표를 그대로 읽어 결과보고를 만든다(read_table).
"""
import re
import zipfile

CHECK = "[확인 필요]"

# 표 머리 글자(띄어쓰기 없이) → 칸
HEAD_KEYS = [("org", ("대학명", "기관명", "기관", "대학", "소속")), ("position", ("직위",)), ("name", ("성명", "발언자", "이름")),
             ("say", ("발언내용", "발언", "내용")), ("key", ("핵심요약", "요약", "건의사항")),
             ("answer", ("시장님답변", "시장답변", "답변", "시답변")), ("depts", ("관련부서", "비고", "처리부서", "담당부서"))]

DROP_PHRASES = [r"발언\s*대학\s*추정", r"소개\s*기준\s*발언자\s*확인\s*필요", r"소관\s*기능\s*기준\s*검토\s*\(안\)",
                r"담당\s*부서\s*확정\s*필요", r"이\s*제안에\s*대한\s*개별\s*확정\s*답변은\s*없음\.?", r"\(?\s*추정\s*\)?",
                r"〔\s*확인\s*필요[^〕]*〕"]
TIME = re.compile(r"[\(\[]?\s*\b\d{1,2}:\d{2}(?::\d{2})?\b\s*(?:[~∼-]\s*\d{1,2}:\d{2}(?::\d{2})?)?\s*[\)\]]?")


def _tidy(s):
    s = re.sub(r"\s+", " ", s or "").strip()
    s = re.sub(r"\s+([.,·)])", r"\1", s)
    s = re.sub(r"\(\s*\)", "", s)
    return s.strip(" ,·-").strip()


NOTE = re.compile(r"전사상|교차됨|참석자\s*\d+\s*[·,]\s*\d+|녹음상|받아쓰기|미확인|확인\s*필요")
NOTE_PAREN = re.compile(r"\([^()]*(?:확인\s*필요|추정|미확인)[^()]*\)")


def clean(text, kind):
    """칸 하나의 글 정리. kind: org/position/name/say/key/answer/depts"""
    s = text or ""
    s = NOTE_PAREN.sub("", s)                                     # 「(정확한 부서명 확인 필요)」 같은 괄호 메모
    s = " ".join(x for x in re.split(r"(?<=[.다음함임])\s+", s) if not NOTE.search(x))   # 「전사상 … 교차됨.」 같은 작성 메모 문장
    s = TIME.sub("", s)
    for pat in DROP_PHRASES:
        s = re.sub(pat, "", s)
    s = re.sub(r"\(?\s*공통\s*답변\s*\)?\s*[:：]?\s*", "(공통답변): ", s)      # 「공통 답변」「(공통답변):」 → 「(공통답변): 」
    s = re.sub(r"(겠)다고\s*(설명|답변|언급|밝|약속|말)함", r"\1음", s)          # 마련하겠다고 설명함 → 마련하겠음
    s = re.sub(r"(겠)다는\s*(입장|뜻)을\s*(밝|설명|전)함", r"\1음", s)
    if kind == "say":
        k = s.rfind("제안함")
        if k >= 0:
            s = s[:k + len("제안함")] + "."
    return _tidy(s)


def clean_row(r):
    out = {}
    for k in ("org", "position", "name"):
        out[k] = clean(r.get(k, ""), k)
    for k in ("say", "key", "answer"):
        out[k] = [x for x in (clean(v, k) for v in r.get(k) or []) if x and x not in ("(공통답변):",)]
    depts = []
    for v in r.get("depts") or []:
        for d in re.split(r"\s*[,，/]\s*|\n", clean(v, "depts")):
            d = d.strip()
            if d and d not in depts:
                depts.append(d)
    out["depts"] = depts
    return out


def is_dropped(r):
    say = " ".join(r.get("say") or [])
    return not say.strip() or "발언 미확인" in say or "미확인" in (r.get("name") or "")


# ---------- 참석자 명단과 맞추기 ----------
def _norm(s):
    return re.sub(r"[\s()㈜]|주식회사|\(주\)", "", s or "")


def _like(a, b):
    """두 이름이 같은 사람으로 보이는지(받아쓰기 오류 한 글자까지)"""
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return False
    if a == b:
        return True
    return len(a) == len(b) and sum(x != y for x, y in zip(a, b)) <= 1


def match_roster(r, attendees):
    """기관·이름이 명단과 맞으면 명단 표기(기관명·직위·성명)로 바꾼다"""
    org, name = _norm(r["org"]), _norm(r["name"])
    cand = [a for a in attendees if a.get("name")]
    hit = next((a for a in cand if _norm(a.get("org")) == org and org), None)
    if hit is None:
        hit = next((a for a in cand if _norm(a["name"]) == name and name), None)
    if hit is None:
        hit = next((a for a in cand if _like(a["name"], r["name"]) and (not org or _like(a.get("org"), r["org"]) or org in _norm(a.get("org")))), None)
    if hit is None and org:
        hit = next((a for a in cand if org in _norm(a.get("org")) or _norm(a.get("org")) in org), None)
    if hit:
        r = {**r, "org": hit.get("org") or r["org"], "position": hit.get("position") or r["position"], "name": hit["name"]}
    return r


# ---------- 한글 표 읽기 ----------
def _cells(tr):
    return [c for c in tr if c.tag.endswith("}tc")]


def _lines(tc):
    out = []
    for p in tc.iter():
        if p.tag.endswith("}p"):
            t = "".join(x.text or "" for x in p.iter() if x.tag.endswith("}t"))
            if t.strip():
                out.append(t.strip())
    return out


def read_table(path):
    """기관별 정리 표가 든 hwpx → 행 목록(못 찾으면 None)"""
    from lxml import etree
    try:
        z = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError):
        return None
    names = sorted(n for n in z.namelist() if re.match(r"Contents/section\d+\.xml$", n))
    for n in names:
        root = etree.fromstring(z.read(n))
        for tbl in root.iter():
            if not tbl.tag.endswith("}tbl"):
                continue
            trs = [x for x in tbl if x.tag.endswith("}tr")]
            if len(trs) < 2:
                continue
            head = [re.sub(r"\s+", "", " ".join(_lines(c))) for c in _cells(trs[0])]
            col = {}
            for key, words in HEAD_KEYS:
                for i, h in enumerate(head):
                    if i not in col.values() and any(h.startswith(w) or h == w for w in words):
                        col[key] = i
                        break
            if not {"name", "say", "key", "answer"} <= col.keys():
                continue
            rows = []
            for tr in trs[1:]:
                cs = _cells(tr)
                get = lambda k: _lines(cs[col[k]]) if k in col and col[k] < len(cs) else []   # noqa: E731
                rows.append({"org": " ".join(get("org")), "position": " ".join(get("position")), "name": " ".join(get("name")),
                             "say": get("say"), "key": get("key"), "answer": get("answer"), "depts": get("depts")})
            return rows
    return None


# ---------- 결과보고 데이터 ----------
def finish(rows, data):
    """정리 규칙 → 명단 맞추기 → 빈·미확인 행 빼기"""
    out = []
    for r in rows:
        r = clean_row(r)
        if is_dropped(r):
            continue
        out.append(match_roster(r, data.get("attendees") or []))
    return out


def rows_from_result(res, data):
    """규칙(속기록)으로 뽑은 건의(suggestions) → 기관별 정리 행"""
    people = {a["name"]: a for a in data.get("attendees") or [] if a.get("name")}
    by_org = {}
    for a in data.get("attendees") or []:
        by_org.setdefault((a.get("org_short") or a.get("org") or "").replace("㈜", ""), a)
    rows = []
    sugg = [s for s in res.get("suggestions") or [] if s.get("title")]
    lead = {(s.get("names") or [""])[0] for s in sugg}
    for s in sugg:
        names = s.get("names") or [""]
        # 함께 건의한 사람(「한서준·강태오」)은 자기 이름의 다른 건의가 없을 때만 행을 하나 더 만든다
        for name in [names[0]] + [n for n in names[1:] if n not in lead]:
            rows.append(_row(s, name, people, by_org))
    return finish(rows, data)


def _row(s, name, people, by_org):
    a = people.get(name) or by_org.get((s.get("org") or "").replace("㈜", "")) or {}
    det = s.get("detail") or []
    return {"org": a.get("org") or s.get("org", ""), "position": a.get("position", ""), "name": a.get("name") or name,
            "say": [d for d in det if not d.startswith("(시 답변)")],
            "key": [s["title"]],
            "answer": [d[len("(시 답변) "):] for d in det if d.startswith("(시 답변) ")] or list(s.get("answer_fb") or []),
            "depts": list(s.get("depts") or [])}


def result_from_rows(rows, data):
    """이미 정리한 기관별 표 → 결과보고 데이터(result)와 메모"""
    ev = data["event"]
    rows = finish(rows, data)
    sugg = []
    for k, r in enumerate(rows, 1):
        title = (r["key"] or [r["say"][0][:30] if r["say"] else ""])[0]
        ans = [x for x in r["answer"] if x]
        sugg.append({"org": r["org"].replace("㈜", ""), "title": title, "names": [r["name"]], "no": k,
                     "detail": list(r["say"]) + [f"(시 답변) {ans[0]}"] if ans else list(r["say"]), "depts": r["depts"]})
    covered = {r["name"] for r in rows}
    for a in data.get("attendees") or []:
        if a.get("name") and a["name"] not in covered:
            sugg.append({"org": (a.get("org") or "").replace("㈜", ""), "names": [a["name"]]})       # 별도 건의사항 없음
    n = sum(1 for s in sugg if s.get("title"))
    common = []
    for r in rows:                                                # 총평: 표의 시장님 답변 중 (공통답변)·여러 건에 같은 답
        for x in r["answer"]:
            t = re.sub(r"^\(공통답변\)\s*[:：]?\s*", "", x).strip()
            if t and t not in common and (x.startswith("(공통답변)") or sum(t in " ".join(q["answer"]) for q in rows) > 1):
                common.append(t)
    review = [f"현장의 생생한 말씀을 잘 들었으며, 건의된 {n}건은 소관 부서와 검토하겠음."] + [c.rstrip(".") + "." for c in common[:3]]
    orgs = [r["org"] for r in rows]
    subj = "대학" if orgs and all(re.search(r"대학(교)?$", o) for o in orgs) else "기관"
    res = {
        "actual_end": data["derived"]["end"],
        "contents": list(ev.get("agenda") or [p["item"] for p in data["program"]]),
        "opinion_subject": subj,
        "summary": ev.get("summary") or ", ".join(ev.get("agenda") or [])[:40],
        "next_steps": "관련부서 검토 후 처리 예정",
        "plan_lines": [f["task"] for f in data.get("follow_up") or []],
        "suggestions": sugg,
        "mayor_summary": review,
        "highlights": list(dict.fromkeys(s["title"] for s in sugg if s.get("title")))[:4],
        "minutes": [],
        "org_rows": rows,
        "photos": [],
    }
    return res, [f"기관별 정리 표에서 건의 {n}건을 읽음(참석자 명단 표기로 맞춤) — 회의록과 대조 필요"]
