# -*- coding: utf-8 -*-
"""회의록 「기관별 정리」 표 — 결과보고 붙임 1(대학명·직위·성명·발언내용·핵심요약·시장님답변·관련부서).

- 한 사람의 건의 하나가 한 행. 이름·직위·기관은 참석자 명단(계획서·화면) 표기로 맞춘다.
- 정리 규칙(사람이 정한 것): 발언·답변 시각, 「추정」·「확인 필요」 같은 작성 메모, 「개별 확정 답변은 없음」을 빼고,
  「공통 답변」은 「(공통답변)」으로, 「…하겠다고 설명함」은 「…하겠음」으로, 발언내용은 「제안함」 뒤를 자른다.
- 이미 이 꼴로 정리한 한글 파일(hwpx)을 회의록으로 올리면 그 표를 그대로 읽어 결과보고를 만든다(read_table).
"""
import re
import zipfile

CHECK = "[확인 필요]"

# 표 머리 글자(띄어쓰기 없이) → 칸
HEAD_KEYS = [("org", ("대학명", "기관명", "기관", "대학", "소속")), ("position", ("직위",)), ("name", ("성명", "발언자", "이름")),
             ("say", ("발언내용", "발언", "내용")), ("key", ("핵심요약", "요약", "건의사항")),
             ("answer", ("시장님답변", "시장답변", "답변", "시답변")), ("depts", ("관련부서", "비고", "처리부서", "담당부서"))]

DROP_PHRASES = [r"발언\s*대학\s*추정", r"소개\s*기준\s*발언자\s*확인\s*필요", r"소관\s*기능\s*기준\s*검토\s*\(안\)",
                r"담당\s*부서\s*확정\s*필요", r"이\s*제안에\s*대한\s*개별\s*확정\s*답변은\s*없음\.?", r"\(?\s*추정\s*\)?",
                r"〔\s*확인\s*필요[^〕]*〕"]
TIME = re.compile(r"[\(\[]?\s*\b\d{1,2}:\d{2}(?::\d{2})?\b\s*(?:[~∼-]\s*\d{1,2}:\d{2}(?::\d{2})?)?\s*[\)\]]?")


def _tidy(s):
    s = re.sub(r"\s+", " ", s or "").strip()
    s = re.sub(r"\s+([.,·)])", r"\1", s)
    s = re.sub(r"\(\s*\)", "", s)
    return s.strip(" ,·-").strip()


NOTE = re.compile(r"전사상|교차됨|참석자\s*\d+\s*[·,]\s*\d+|녹음상|받아쓰기|미확인|확인\s*필요")
NOTE_PAREN = re.compile(r"\([^()]*(?:확인\s*필요|추정|미확인)[^()]*\)")


def clean(text, kind):
    """칸 하나의 글 정리. kind: org/position/name/say/key/answer/depts"""
    s = text or ""
    s = NOTE_PAREN.sub("", s)                                     # 「(정확한 부서명 확인 필요)」 같은 괄호 메모
    s = " ".join(x for x in re.split(r"(?<=[.다음함임])\s+", s) if not NOTE.search(x))   # 「전사상 … 교차됨.」 같은 작성 메모 문장
    s = TIME.sub("", s)
    for pat in DROP_PHRASES:
        s = re.sub(pat, "", s)
    s = re.sub(r"\(?\s*공통\s*답변\s*\)?\s*[:：]?\s*", "(공통답변): ", s)      # 「공통 답변」「(공통답변):」 → 「(공통답변): 」
    s = re.sub(r"(겠)다고\s*(설명|답변|언급|밝|약속|말)함", r"\1음", s)          # 마련하겠다고 설명함 → 마련하겠음
    s = re.sub(r"(겠)다는\s*(입장|뜻)을\s*(밝|설명|전)함", r"\1음", s)
    if kind == "say":
        k = s.rfind("제안함")
        if k >= 0:
            s = s[:k + len("제안함")] + "."
    return _tidy(s)


def clean_row(r):
    out = {}
    for k in ("org", "position", "name"):
        out[k] = clean(r.get(k, ""), k)
    for k in ("say", "key", "answer"):
        out[k] = [x for x in (clean(v, k) for v in r.get(k) or []) if x and x not in ("(공통답변):",)]
    depts = []
    for v in r.get("depts") or []:
        for d in re.split(r"\s*[,，/]\s*|\n", clean(v, "depts")):
            d = d.strip()
            if d and d not in depts:
                depts.append(d)
    out["depts"] = depts
    return out


def is_dropped(r):
    say = " ".join(r.get("say") or [])
    return not say.strip() or "발언 미확인" in say or "미확인" in (r.get("name") or "")


# ---------- 참석자 명단과 맞추기 ----------
def _norm(s):
    return re.sub(r"[\s()㈜]|주식회사|\(주\)", "", s or "")


def _like(a, b):
    """두 이름이 같은 사람으로 보이는지(받아쓰기 오류 한 글자까지)"""
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return False
    if a == b:
        return True
    return len(a) == len(b) and sum(x != y for x, y in zip(a, b)) <= 1


def match_roster(r, attendees):
    """명단과 같은 사람이면 명단 표기(기관명·직위·성명)로 바꾼다.
    같은 사람 = 이름이 같거나 한 글자만 다름(받아쓰기 오류). 같은 대학이라도 이름이 다르면(대리 참석) 바꾸지 않는다."""
    org = _norm(r["org"])
    cand = [a for a in attendees if a.get("name")]
    same_org = lambda a: not org or _like(a.get("org"), r["org"]) or org in _norm(a.get("org")) or _norm(a.get("org")) in org   # noqa: E731
    hit = next((a for a in cand if _norm(a["name"]) == _norm(r["name"]) and r["name"]), None)
    if hit is None:
        hit = next((a for a in cand if _like(a["name"], r["name"]) and same_org(a)), None)
    if hit is None and not _norm(r["name"]) and org:                  # 이름이 비었으면 같은 기관의 명단 사람
        hit = next((a for a in cand if same_org(a)), None)
    if hit:
        return {**r, "org": hit.get("org") or r["org"], "position": hit.get("position") or r["position"], "name": hit["name"]}
    m = next((a for a in cand if same_org(a) and a.get("org")), None)  # 사람은 달라도 기관명 표기는 명단대로
    return {**r, "org": m["org"]} if m and org else r


# ---------- 한글 표 읽기 ----------
def _cells(tr):
    return [c for c in tr if c.tag.endswith("}tc")]


def _lines(tc):
    out = []
    for p in tc.iter():
        if p.tag.endswith("}p"):
            t = "".join(x.text or "" for x in p.iter() if x.tag.endswith("}t"))
            if t.strip():
                out.append(t.strip())
    return out


def read_table(path):
    """기관별 정리 표가 든 hwpx → 행 목록(못 찾으면 None)"""
    from lxml import etree
    try:
        z = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError):
        return None
    names = sorted(n for n in z.namelist() if re.match(r"Contents/section\d+\.xml$", n))
    for n in names:
        root = etree.fromstring(z.read(n))
        for tbl in root.iter():
            if not tbl.tag.endswith("}tbl"):
                continue
            trs = [x for x in tbl if x.tag.endswith("}tr")]
            if len(trs) < 2:
                continue
            head = [re.sub(r"\s+", "", " ".join(_lines(c))) for c in _cells(trs[0])]
            col = {}
            for key, words in HEAD_KEYS:
                for i, h in enumerate(head):
                    if i not in col.values() and any(h.startswith(w) or h == w for w in words):
                        col[key] = i
                        break
            if not {"name", "say", "key", "answer"} <= col.keys():
                continue
            rows = []
            for tr in trs[1:]:
                cs = _cells(tr)
                get = lambda k: _lines(cs[col[k]]) if k in col and col[k] < len(cs) else []   # noqa: E731
                rows.append({"org": " ".join(get("org")), "position": " ".join(get("position")), "name": " ".join(get("name")),
                             "say": get("say"), "key": get("key"), "answer": get("answer"), "depts": get("depts")})
            return rows
    return None


# ---------- 결과보고 데이터 ----------
def finish(rows, data):
    """정리 규칙 → 명단 맞추기 → 빈·미확인 행 빼기(「참석자 N」만 있고 기관이 빈 행은 사회자·영상 등이라 다른 행이 정리돼 있으면 뺀다)"""
    out = []
    named = unnamed_share(rows) < 0.5
    for r in rows:
        r = clean_row(r)
        if is_dropped(r) or (named and UNNAMED.match(r["name"]) and not r["org"]):
            continue
        out.append(match_roster(r, data.get("attendees") or []))
    return out


def rows_from_result(res, data):
    """규칙(속기록)으로 뽑은 건의(suggestions) → 기관별 정리 행"""
    people = {a["name"]: a for a in data.get("attendees") or [] if a.get("name")}
    by_org = {}
    for a in data.get("attendees") or []:
        by_org.setdefault((a.get("org_short") or a.get("org") or "").replace("㈜", ""), a)
    rows = []
    sugg = [s for s in res.get("suggestions") or [] if s.get("title")]
    lead = {(s.get("names") or [""])[0] for s in sugg}
    for s in sugg:
        names = s.get("names") or [""]
        # 함께 건의한 사람(「한서준·강태오」)은 자기 이름의 다른 건의가 없을 때만 행을 하나 더 만든다
        for name in [names[0]] + [n for n in names[1:] if n not in lead]:
            rows.append(_row(s, name, people, by_org))
    return finish(rows, data)


def _row(s, name, people, by_org):
    a = people.get(name) or by_org.get((s.get("org") or "").replace("㈜", "")) or {}
    det = s.get("detail") or []
    say = [d for d in det if not d.startswith("(시 답변)")]
    title = s["title"]
    if re.search(r"(니다|요)\.?$|주시면|해 주시|드립니다", title) and say:      # 말투 그대로 잘린 제목 → 다듬은 요청 문장
        req = next((d for d in reversed(say) if re.search(r"요청함|의견임|바람", d)), say[-1])
        title = req if len(req) <= 50 else req[:50].rsplit(" ", 1)[0]
    s = {**s, "title": title}
    return {"org": a.get("org") or s.get("org", ""), "position": a.get("position", ""), "name": a.get("name") or name,
            "say": [d for d in det if not d.startswith("(시 답변)")],
            "key": [s["title"]],
            "answer": [d[len("(시 답변) "):] for d in det if d.startswith("(시 답변) ")] or list(s.get("answer_fb") or []),
            "depts": list(s.get("depts") or [])}


def result_from_rows(rows, data):
    """이미 정리한 기관별 표 → 결과보고 데이터(result)와 메모"""
    ev = data["event"]
    rows = finish(rows, data)
    sugg = []
    for k, r in enumerate(rows, 1):
        title = (r["key"] or [r["say"][0][:30] if r["say"] else ""])[0]
        ans = [x for x in r["answer"] if x]
        sugg.append({"org": r["org"].replace("㈜", ""), "title": title, "names": [r["name"]], "no": k,
                     "detail": list(r["say"]) + [f"(시 답변) {ans[0]}"] if ans else list(r["say"]), "depts": r["depts"]})
    covered = {r["name"] for r in rows}
    for a in data.get("attendees") or []:
        if a.get("name") and a["name"] not in covered:
            sugg.append({"org": (a.get("org") or "").replace("㈜", ""), "names": [a["name"]]})       # 별도 건의사항 없음
    n = sum(1 for s in sugg if s.get("title"))
    common = []
    for r in rows:                                                # 총평: 표의 시장님 답변 중 (공통답변)·여러 건에 같은 답
        for x in r["answer"]:
            t = re.sub(r"^\(공통답변\)\s*[:：]?\s*", "", x).strip()
            if t and t not in common and (x.startswith("(공통답변)") or sum(t in " ".join(q["answer"]) for q in rows) > 1):
                common.append(t)
    review = [f"현장의 생생한 말씀을 잘 들었으며, 건의된 {n}건은 소관 부서와 검토하겠음."] + [c.rstrip(".") + "." for c in common[:3]]
    orgs = [r["org"] for r in rows]
    subj = "대학" if orgs and all(re.search(r"대학(교)?$", o) for o in orgs) else "기관"
    res = {
        "actual_end": ev.get("end") or data["derived"]["end"],     # 회의록 정리 파일 개요의 끝난 시각이 있으면 그것
        "contents": list(ev.get("agenda") or [p["item"] for p in data["program"]]),
        "opinion_subject": subj,
        "summary": ev.get("summary") or ", ".join(ev.get("agenda") or [])[:40],
        "next_steps": "관련부서 검토 후 처리 예정",
        "plan_lines": [f["task"] for f in data.get("follow_up") or []],
        "suggestions": sugg,
        "mayor_summary": review,
        "highlights": list(dict.fromkeys(s["title"] for s in sugg if s.get("title")))[:4],
        "minutes": [],
        "org_rows": rows,
        "photos": [],
    }
    return res, [f"기관별 정리 표에서 건의 {n}건을 읽음(참석자 명단 표기로 맞춤) — 회의록과 대조 필요"]


# ---------- 회의록 정리 파일의 제목 상자·행사 개요 → 행사 정보 ----------
UNNAMED = re.compile(r"^(참석자|화자|발언자)\s*\d+$")


def read_overview(path):
    """회의록 정리 파일 맨 앞(제목 상자·「❍ (일 시) …」 개요) → 행사 정보 사전(찾은 값만). 계획서가 없을 때 결과보고에 쓴다."""
    from core.hwpx import read_text
    try:
        lines = [x.strip() for x in read_text(path)]
    except Exception:  # noqa: BLE001
        return {}
    head = next((i for i, x in enumerate(lines) if re.sub(r"\s", "", x) in ("기관", "기관명", "대학명")), len(lines))
    top = [x for x in lines[:head] if x]
    ev = {}
    title = next((x for x in top if not x.startswith(("❍", "○", "※", "-"))), "")
    if title and CHECK not in title:
        ev["title"] = title
    for x in top:
        m = re.search(r"\(일\s*시\)\s*(\d{4})\.\s*(\d{1,2})\.\s*(\d{1,2})\.?.*?(\d{1,2}:\d{2})\s*[~∼-]\s*(\d{1,2}:\d{2})", x)
        if m:
            ev.update(date=f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}", start=m.group(4), end=m.group(5))
        m = re.search(r"\(장\s*소\)\s*(.+)", x)
        if m and "확인 필요" not in m.group(1):
            ev["venue"] = m.group(1).strip()
        m = re.search(r"\(참\s*석\)\s*(\d+)\s*명\s*(?:\(([^)]*)\))?", x)
        if m:
            ev["headcount"] = f"{m.group(1)}명"
            if m.group(2):
                ev["attendee_label"] = re.sub(r"\s*등$", "", m.group(2).strip())
        m = re.search(r"※\s*배석\s*\((\d+)\s*명\)\s*[:：]?\s*(.*)", x)
        if m:
            ev["staff_count"] = int(m.group(1))
            if m.group(2).strip():
                ev["staff_note"] = m.group(2).strip()
        m = re.search(r"\(내\s*용\)\s*(.+)", x)
        if m and "확인 필요" not in m.group(1):
            ev["summary"] = m.group(1).strip()
    return {"event": ev} if ev else {}


def unnamed_share(rows):
    """「참석자 1」처럼 아직 사람을 정하지 않은 행의 비율"""
    if not rows:
        return 0
    return sum(1 for r in rows if UNNAMED.match((r.get("name") or "").strip()) and not (r.get("org") or "").strip()) / len(rows)
