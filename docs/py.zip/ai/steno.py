# -*- coding: utf-8 -*-
"""속기록(발언자 줄 「[이름 / 소속 직위]」·「[시장]」 형식) → 결과보고용 결과 데이터(규칙, AI 없이).

- 계획서 참석자를 기준으로 발언을 맞추고, 참석자는 하나도 빼지 않는다(발언이 없으면 「별도 건의사항 없음」으로 남긴다).
- 속기록 끝에 「[붙임] 주요 건의사항 및 처리 부서(안)」 표가 있으면 그것이 건의 목록(제목·건의자·처리 부서)이고,
  없으면 참석자 발언의 요청 문장에서 뽑는다.
- 세부 내용은 건의자 발언에서 현황(문제)·요청 문장을 골라 개조식(…함)으로 다듬고, 이어진 시장·과장 답변을 붙인다.
- 시장 총평은 시장의 마무리 말씀(첫째~다섯째)을 개조식으로 옮긴다. 발언에 없는 내용은 만들지 않는다.
"""
import re

SECTION = re.compile(r"^\s*\d+\.\s*(.+?)\s*\((\d{1,2}:\d{2})\s*[~∼-]\s*(\d{1,2}:\d{2})\)\s*$")
BRACKET = re.compile(r"^\s*\[\s*([^\]/]+?)\s*(?:/\s*([^\]]+?))?\s*\]\s*$")
ROLE_WORDS = ("시장", "부시장", "국장", "실장", "과장", "팀장", "사회자", "담당", "주무관", "센터장", "소장", "단장")
FILLER_LEAD = ("그런데 ", "그래서 ", "그리고 ", "또 ", "다만 ", "문제는 ", "한 가지 더 말씀드리면, ", "저도 짧게 말씀드리면, ",
               "한 가지만 덧붙이겠습니다. ", "그리고 한 가지 더 말씀드리면, ")
REQUEST = re.compile(r"주시면|주셨으면|해 주십시오|주시기 바랍니다|좋겠습니다|부탁|요청|건의|있으면 좋|늘었으면|으면 합니다|했으면 합니다")
ANSWER = re.compile(r"검토하겠|협의|마련하겠|연결해|살펴보겠|찾아보|방안을|전달|확인해|알려드리|알려 드리|지키겠")

# 끝맺음 → 개조식(긴 것부터)
ENDINGS = [
    ("안 되겠지요", "안 된다는 의견임"), ("겠지요", "겠다는 의견임"), ("이군요", "임"), ("이네요", "임"), ("이지요", "임"),
    ("라고 하지요", "라고 함"), ("하지요", "함"), ("해 보시고", "해 보도록 요청함"), ("보시고", "보도록 요청함"),
    ("반갑습니다", "반가움"), ("고맙습니다", "고마움"), ("감사드립니다", "감사드림"), ("감사합니다", "감사함"),
    ("쉽습니다", "쉬움"), ("무겁습니다", "무거움"), ("가볍습니다", "가벼움"), ("아깝습니다", "아까움"),
    ("해 주시면 좋을 것 같습니다", "해 줄 것을 요청함"), ("해 주시면 좋겠습니다", "해 줄 것을 요청함"),
    ("해 주셨으면 합니다", "해 줄 것을 요청함"), ("해 주시기 바랍니다", "해 줄 것을 요청함"), ("해 주십시오", "하도록 요청함"),
    ("주시면 좋겠습니다", "줄 것을 요청함"), ("주셨으면 합니다", "줄 것을 요청함"), ("주시기 바랍니다", "줄 것을 요청함"),
    ("열어 주시면 큰 도움이 될 것 같습니다", "열어 줄 것을 요청함"),
    ("주시면 큰 도움이 될 것 같습니다", "줄 것을 요청함"), ("주시면 서로 부담이 줄 것 같습니다", "주면 서로 부담이 줄 것으로 기대함"),
    ("있으면 좋겠습니다", "있으면 좋겠다는 의견임"), ("늘었으면 합니다", "늘었으면 한다는 의견임"),
    ("만들었으면 합니다", "만들었으면 한다는 의견임"), ("끝나지 않았으면 합니다", "끝나지 않기를 바란다는 의견임"),
    ("좋겠습니다", "좋겠다는 의견임"), ("했으면 합니다", "했으면 한다는 의견임"), ("으면 합니다", "으면 한다는 의견임"),
    ("싶습니다", "싶다는 의견임"), ("될 것 같습니다", "될 것으로 기대함"), ("줄 것 같습니다", "줄 것으로 기대함"),
    ("것 같습니다", "것으로 보임"), ("는 겁니다", "는 것임"), ("라는 겁니다", "라는 것임"), ("겁니다", "것임"),
    ("드리겠습니다", "드리겠음"), ("하겠습니다", "하겠음"), ("겠습니다", "겠음"), ("하고 있습니다", "하고 있음"),
    ("걸립니다", "걸림"), ("있습니다", "있음"), ("없습니다", "없음"), ("어렵습니다", "어려움"), ("부족합니다", "부족함"),
    ("필요합니다", "필요함"), ("큽니다", "큼"), ("많습니다", "많음"), ("됩니다", "됨"), ("합니다", "함"), ("입니다", "임"),
    ("습니다", "음"), ("부담이죠", "부담임"), ("이죠", "임"), ("지요", "임"), ("거든요", "임"), ("네요", "임"),
    ("어떻게 되어 있습니까", "어떻게 되어 있는지 질의함"), ("있습니까", "있는지 질의함"), ("십니까", "는지 질의함"), ("습니까", "는지 질의함"),
]
NOISE = re.compile(r"소개해 드리|자리를 열|시작하겠")
LEAD_CLAUSE = re.compile(r"^.*?(말씀드리면|드리고 싶은데요|덧붙이겠습니다|전해 드리겠습니다)[,.]?\s*")
BUSINESS = re.compile(r"어렵|부족|필요|문제|벽|부담|없|힘|막막|걸리|복잡")


def clean(x):
    """말머리 절(「…말씀드리면,」「…덧붙이겠습니다.」)을 걷어 내고, 남은 말이 없으면 빈 줄"""
    y = LEAD_CLAUSE.sub("", x).strip()
    return y if len(y) >= 8 else ""


def formalize(s):
    """발언 한 문장 → 개조식 한 줄(「…함」「…요청함」). 인사말·끝 마침표는 걷어 낸다."""
    t = re.sub(r"\s+", " ", (s or "").strip()).rstrip(".!? ")
    for lead in FILLER_LEAD:
        if t.startswith(lead):
            t = t[len(lead):]
    t = re.sub(r"^(네|예|아|음|좋은 지적입니다)[,.]\s*", "", t)
    t = re.sub(r"^(저희는|저희가|저희도|저는|저도)\s+", "", t)
    t = re.sub(r"저희(도|가|는)\s+", "", t)
    m = re.match(r"^(.*?)(?:(해|하여) )?주시면(?: .*)?$", t)
    if m and "좋겠" not in t.split("주시면")[0]:
        return f"{m.group(1)}{m.group(2) + ' ' if m.group(2) else ''}줄 것을 요청함".replace("  ", " ")
    t = re.sub(r"^[가-힣]+(과장|국장|팀장)님,\s*", "", t)
    t = re.sub(r"(는데|고|서|면)요$", r"\1", t)
    for a, b in ENDINGS:
        if t.endswith(a):
            return (t[:-len(a)] + b).strip()
    if t.endswith("니다") and len(t) > 3:                    # 끝납니다 → 끝남, 드립니다 → 드림(받침 ㅂ → ㅁ)
        c = ord(t[-3]) - 0xAC00
        if 0 <= c < 11172 and c % 28 == 17:
            return t[:-3] + chr(0xAC00 + c - 1)
    return t


def split_sentences(lines):
    text = " ".join(x.strip() for x in lines if x.strip())
    return [x.strip() for x in re.split(r"(?<=[.?!])\s+", text) if x.strip()]


# ---------- 구문 분석 ----------
def parse(text):
    """→ (segments, sections). segment: {who, org, role, lines, section}"""
    segs, sections, cur, sec = [], [], None, ""
    for raw in text.splitlines():
        line = raw.strip()
        m = SECTION.match(line)
        if m:
            sec = m.group(1)
            sections.append((sec, m.group(2), m.group(3)))
            cur = None
            continue
        if line.startswith(("=", "-")) and set(line) <= set("=-+| "):
            cur = None if line.startswith("=") else cur
            continue
        m = BRACKET.match(line)
        if m and (m.group(2) or any(w in m.group(1) for w in ROLE_WORDS)):
            who, tail = m.group(1).strip(), (m.group(2) or "").strip()
            cur = {"who": who, "org": "", "role": "", "lines": [], "section": sec, "named": bool(tail)}
            if tail:                                       # 「김민준 / ㈜그린로직 대표」
                org, _, role = tail.rpartition(" ")
                cur["org"], cur["role"] = org.strip(), role.strip()
                if re.search(r"(?<!부)시장(님)?$", cur["role"]) and not cur["org"]:     # 「[장기수 / 천안시장]」 = 시장 발언
                    cur["role"] = "시장"
            else:                                          # 「시장」「기업지원과장」「사회자」
                cur["role"], cur["who"] = who, ""
            segs.append(cur)
            continue
        if cur is not None and line and not (line.startswith("(") and line.endswith(")")) and not line.startswith(("□", "※", "[붙임]")):
            cur["lines"].append(line)
    return segs, sections


def looks_like(text):
    segs, _ = parse(text)
    return sum(1 for s in segs if s["named"]) >= 2 and any(s["role"] == "시장" for s in segs)


def fits(text, data):
    """속기록의 이름 적힌 발언자가 계획서(화면) 참석자 명단에 있는지 — 명단이 없으면 녹취 규칙(ai.result)으로 읽는다"""
    names = {a.get("name") for a in data.get("attendees") or [] if a.get("name")}
    segs, _ = parse(text)
    return any(s["named"] and s["who"] in names for s in segs)


def appendix(text):
    """「[붙임] 주요 건의사항 및 처리 부서(안)」 표 → [{no, title, names, depts}]"""
    out, on = [], False
    for line in text.splitlines():
        if "[붙임]" in line and "건의" in line:
            on = True
            continue
        if not on:
            continue
        m = re.match(r"^\s*(\d+)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*$", line)
        if m:
            names = [x for x in re.split(r"[·,、/\s]+", m.group(3)) if x]
            depts = [x.strip() for x in m.group(4).split(",") if x.strip()]
            out.append({"no": int(m.group(1)), "title": m.group(2).strip(), "names": names, "depts": depts})
    return out


def end_time(text, fallback):
    m = re.search(r"\((\d{1,2}:\d{2})\s*폐회\)", text)
    return m.group(1) if m else fallback


# ---------- 세부 내용 ----------
STOP = {"지역", "창업", "기업", "지원", "운영", "제공", "확대", "마련", "연계", "활용", "통합", "대한", "위한", "관련", "문제"}
ORDINAL = re.compile(r"^(첫째|둘째|셋째|넷째|다섯째)(는|은|로는|,)?\s*")


def tokens(title):
    return [t for t in re.findall(r"[가-힣A-Za-z0-9]{2,}", title) if t not in STOP]


def overlap(sentence, toks):
    score = 0
    for t in toks:
        pat = r"(?<![가-힣])" + re.escape(t)                       # 낱말 앞머리에서만(「일자리」 속 「자리」는 세지 않음)
        if re.search(pat, sentence) or (len(t) >= 3 and t[:-1] not in STOP and re.search(r"(?<![가-힣])" + re.escape(t[:-1]), sentence)):
            score += 1
    return score


def is_intro(sentence, name, org_short):
    s = sentence.strip().rstrip(".")
    return bool(re.search(r"입니다$", s)) and len(s) < 40 and (name in s or (org_short and org_short in s) or "저희" in s)


def assign_sentences(sugg, segs, people):
    """건의자 발언의 문장을 건의 항목에 나눠 담는다 → {건의 번호: [(구간 번호, 문장 번호, 문장)]}
    - 「첫째·둘째·셋째」로 나눈 발언은 건의자의 건의 순서대로
    - 그 밖에는 문장 속 낱말이 건의 제목과 겹치는 쪽으로(겹침이 없으면 앞 문장이 속한 건의에 이어 붙임)"""
    got = {id(s): [] for s in sugg}
    mine = lambda name: sorted((s for s in sugg if name in s["names"]), key=lambda s: s["no"])      # noqa: E731
    seen = {}
    for i, sg in enumerate(segs):
        name = sg["who"]
        subs = mine(name)
        if not subs:
            continue
        kseg = seen.get(name, 0)                                     # 같은 사람의 두 번째 발언은 뒤 건의일 가능성이 높다
        seen[name] = kseg + 1
        sents = [clean(x) for x in split_sentences(sg["lines"]) if not is_intro(x, name, people.get(name, {}).get("org_short", ""))
                 and not NOISE.search(x)]
        sents = [x for x in sents if x and not (x.startswith("저희는") and not BUSINESS.search(x))]
        marked = [k for k, x in enumerate(sents) if ORDINAL.match(x)]
        cur = None
        group = -1
        for j, x in enumerate(sents):
            if marked and ORDINAL.match(x):                       # 「첫째는 인력입니다.」 → 제목 줄은 버리고 다음 건의로
                group += 1
                cur = subs[min(group, len(subs) - 1)]
                continue
            if marked and cur is not None:
                got[id(cur)].append((i, j, x))
                continue
            scores = [(overlap(x, tokens(s["title"])) + (0.5 if s is subs[min(kseg, len(subs) - 1)] else 0), s) for s in subs]
            best = max(scores, key=lambda t: t[0])
            if best[0] >= 1:
                cur = best[1]
            elif cur is None:
                cur = subs[0]
            others = [overlap(x, tokens(t["title"])) for t in sugg if name not in t["names"]]
            if best[0] < 1 and others and max(others) >= 2:       # 다른 사람 건의 이야기에 덧붙인 말은 이 건의에서 뺀다
                continue
            got[id(cur)].append((i, j, x))
    return got


def detail_bullets(sug, assigned, segs, people):
    """건의 하나의 세부 내용(개조식 2~4줄): 현황 → 요청 → (시 답변)"""
    toks = tokens(sug["title"])
    sents = assigned
    req = [(overlap(x, toks), i, j, x) for i, j, x in sents if REQUEST.search(x)]
    req.sort(key=lambda t: (-t[0], t[1], t[2]))
    rq = req[0] if req else None
    probs = [(overlap(x, toks), i, j, x) for i, j, x in sents if not REQUEST.search(x)]
    probs.sort(key=lambda t: (-t[0], t[1], t[2]))
    pick = probs[:1]
    if len(probs) > 1 and len(formalize(probs[0][3])) + len(formalize(probs[1][3])) <= 110:    # 두 문장이 짧으면 둘 다
        pick = probs[:2]
    chosen = sorted(pick, key=lambda t: (t[1], t[2]))
    out = [formalize(x) for _, _, _, x in chosen] + ([formalize(rq[3])] if rq else [])
    out = [x for x in out if x]
    if not out:
        t = sug["title"]
        out = [f'{t}{"을" if re.search("[가-힣]$", t) and (ord(t[-1]) - 0xAC00) % 28 else "를"} 요청함']
    # 시 답변: 건의가 나온 구간 바로 뒤의 시장·과장 말 중 이 건의와 낱말이 겹치고 실행을 약속하는 문장
    where = max((i for i, _, _ in sents), default=-1) if sents else -1
    if rq:
        where = rq[1]
    if where >= 0:
        k, best = where + 1, None
        while k < len(segs) and not (segs[k]["named"] and segs[k]["who"] in people):   # 다음 참석자가 말하기 전까지(시장·공무원 답변)
            for x in split_sentences(segs[k]["lines"]):
                if x.endswith("?") or not ANSWER.search(x):
                    continue
                sc = overlap(x, toks) * 2 + (2 if "겠습니다" in x else 0) + (1 if segs[k]["role"] != "시장" else 0)
                if overlap(x, toks) >= 1 and (best is None or sc > best[0]):
                    best = (sc, x, segs[k]["role"])
            k += 1
        if best:
            out.append("(시 답변) " + formalize(best[1]))
            dept = re.match(r"^(.+과)(장|장님)$", best[2] or "")            # 답한 사람이 「기업지원과장」이면 관련부서 = 기업지원과
            if dept and not sug.get("depts"):
                sug["depts"] = [dept.group(1)]
    return out


# ---------- 총평 ----------
def mayor_review(segs, total=0):
    """시장 마무리 말씀 → 개조식 총평 줄"""
    mayor = [s for s in segs if s["role"] == "시장"]
    if not mayor:
        return []
    close = next((s for s in reversed(mayor) if any(ORDINAL.match(x) for x in s["lines"])), mayor[-1])
    themes, rest = [], []
    if not any(ORDINAL.match(x) for x in close["lines"]):       # 「첫째~」가 없으면 앞서 시장이 「종합하면 …」으로 묶은 말을 주제로
        for sg in mayor:
            for x in split_sentences(sg["lines"]):
                m = re.match(r"^(?:말씀을\s*)?종합하면\s*(.+)$", x)
                if m:
                    themes.append(formalize(m.group(1)))
    for x in split_sentences(close["lines"]):
        m = re.match(r"^(첫째|둘째|셋째|넷째|다섯째)[,，]?\s*(.+)$", x)
        if m:
            core = re.sub(r"(는 점|라는 점)(입니다)?\.?$", r"\1", m.group(2)).rstrip(".")
            themes.append(f"{core}에 공감함" if core.endswith("점") else formalize(core))
        elif "감사합니다" not in x and "정리해 보면" not in x and "마치겠" not in x:
            rest.append(x)
    head = [f"현장의 생생한 말씀을 잘 들었으며, 건의된 {total}건은 소관 부서와 검토하겠음" if total else "현장의 생생한 말씀을 잘 들었음"]
    tail = []
    for x in rest:
        f = re.sub(r"여러분께(?!서)", "참석자들께", formalize(x)).replace("여러분이", "참석자들이")
        f = re.sub(r"(해 )?줄 것을 요청함$", lambda m: (m.group(1) or "") + "주기 바람", f)    # 시장 말씀의 「…해 주시기 바랍니다」
        if f.startswith("오늘 정말 귀한 말씀"):
            continue
        tail.append(f)
    return [x.rstrip(".") + "." for x in head + themes + tail]


# ---------- 전체 ----------
def build(text, data):
    """속기록 → result 사전과 메모. data는 load_event() 결과."""
    from core import calc
    ev = data["event"]
    segs, sections = parse(text)
    people = {a["name"]: a for a in data["attendees"] if a.get("name")}
    notes = []
    end = end_time(text, data["derived"]["end"])
    if not re.search(r"\((\d{1,2}:\d{2})\s*폐회\)", text):
        notes.append(f"속기록에 폐회 시각이 없어 계획 종료 시각 {end}을 씀")
    tab = appendix(text)

    def org_of(name):
        a = people.get(name)
        return a["org"].replace("㈜", "").replace("(주)", "").strip() if a else name       # 기관 이름은 풀 이름(㈜만 뗌)

    sugg = []
    if tab:
        for t in tab:
            names = [n for n in t["names"] if n in people] or t["names"]
            orgs = list(dict.fromkeys(org_of(n) for n in names))
            sugg.append({"org": "·".join(orgs), "title": t["title"], "names": names, "depts": t["depts"], "no": t["no"]})
        got = assign_sentences(sugg, segs, people)
        for s in sugg:
            s["detail"] = detail_bullets(s, got[id(s)], segs, people)
        # 건의자 순서(계획서 참석자 순)로 묶고, 건의가 하나도 없는 참석자는 「별도 건의사항 없음」 줄로 남긴다
        order = {a["name"]: k for k, a in enumerate(data["attendees"])}
        sugg.sort(key=lambda s: (min((order.get(n, 99) for n in s["names"]), default=99), s["no"]))
    else:
        notes.append("속기록에 건의사항 표가 없어 참석자 발언의 요청 문장에서 건의를 뽑음 — 확인 필요")
        for a in data["attendees"]:
            mine = [sg for sg in segs if sg["who"] == a.get("name")]
            sents = [s for sg in mine for s in split_sentences(sg["lines"]) if REQUEST.search(s)]
            for s in sents[:2]:
                from ai.result import request_title                  # 요청 문장 → 짧은 건의 제목(뒤쪽 핵심을 살림)
                title = request_title(s) or formalize(s)[:30]
                sugg.append({"org": org_of(a["name"]), "title": title, "names": [a["name"]], "depts": [], "no": len(sugg) + 1})
        got = assign_sentences(sugg, segs, people)
        for s in sugg:
            s["detail"] = detail_bullets(s, got[id(s)], segs, people)
    covered = {n for s in sugg for n in s["names"]}
    for a in data["attendees"]:
        if a.get("name") not in covered:
            sugg.append({"org": org_of(a["name"]), "names": [a["name"]]})      # 별도 건의사항 없음 줄

    # 붙임 회의록: 시장과 계획서 참석자의 발언(원문 순서 그대로, 개조식)
    mins = []
    host = data["host"]
    staff = {x["name"]: x.get("position", "") for x in data.get("staff_present") or [] if x.get("name")}
    for i, sg in enumerate(segs):
        if sg["role"] == "시장":
            who = {"org": "", "position": "시장님", "name": host.get("name", "")}
        elif sg["named"] and sg["who"] in people:
            a = people[sg["who"]]
            who = {"org": a["org"], "position": a["position"], "name": a["name"]}
        else:                                               # 붙임 회의록은 시장님과 참석자 발언만(배석·사회자는 뺀다)
            continue
        who_name = who.get("name", "")
        keep = [x for x in split_sentences(sg["lines"]) if not is_intro(x, who_name, people.get(who_name, {}).get("org_short", ""))]
        lines = [formalize(c) for c in (clean(x) for x in keep) if c]
        lines = [x for x in lines if x and "감사함" != x]
        if lines:
            mins.append({**who, "lines": lines, "_i": i})
    # 붙임 회의록 7칸 표(기관명·직위·성명·발언내용·핵심요약·시장님 답변·비고)용 — 참석자 행마다
    #   핵심요약: 그 사람의 건의 제목(첫 행만), 없으면 발언 중 요청·다짐·필요를 말한 문장
    #   시장님 답변: 건의에 붙은 시 답변, 없으면 그 발언 바로 뒤 시장(또는 시 공무원)의 답하는 말
    #   비고: 건의 처리 부서, 없으면 답한 공무원의 과
    def short(x, n=40):
        if len(x) <= n:
            return x
        cut = x[:n].rsplit(" ", 1)[0]
        return cut if len(cut) >= n // 2 else x[:n]

    first = set()
    for m in mins:
        i = m.pop("_i")
        if not m.get("org"):
            continue
        mine = [x for x in sugg if m["name"] in (x.get("names") or []) and x.get("title")] if m["name"] not in first else []
        first.add(m["name"])
        key = list(dict.fromkeys(short(next((d for d in reversed(x.get("detail") or []) if not d.startswith("(시 답변)")), x["title"]), 50)
                                 for x in mine))                    # 건의를 다듬은 요청 문장(…줄 것을 요청함)
        ans = list(dict.fromkeys(d[len("(시 답변) "):] for x in mine for d in x.get("detail") or [] if d.startswith("(시 답변) ")))
        depts = list(dict.fromkeys(d for x in mine for d in x.get("depts") or []))
        if not key:
            key = [short(x) for x in m["lines"] if re.search(r"요청함|의견임|바람|겠음|필요함|필요가 있음", x)][:2]
        if not ans:
            for k in range(i + 1, len(segs)):
                nx = segs[k]
                if nx["named"] and nx["who"] in people:              # 다음 참석자가 말하면 그만
                    break
                if nx["role"] == "사회자":
                    continue
                said = [x for x in split_sentences(nx["lines"]) if ANSWER.search(x) and not x.endswith("?")]
                if not said and nx["role"] == "시장":                   # 약속하는 말이 없으면 시장님 답의 앞 문장(인사·짧은 맞장구는 빼고)
                    said = [x for x in split_sentences(nx["lines"]) if len(x) >= 15 and not re.search(r"감사|고맙", x)][:2]
                if said:
                    ans = [short(formalize(x), 60) for x in said[:2]]
                    dept = re.match(r"^(.+과)(장|장님)$", nx["role"] or "")
                    if dept and not depts:
                        depts = [dept.group(1)]
                    break
        m.update(key=key, answer=ans, depts=depts)
    spoke = {m["name"] for m in mins}
    for a in data["attendees"]:
        if a.get("name") not in spoke:
            mins.append({"org": a["org"], "position": a["position"], "name": a["name"], "lines": ["별도 발언 없음"]})

    # 표지 핵심 항목: 건의 제목 중 4개(회신·결과 알림 같은 후속 건의는 뺌)
    pool = [s["title"] for s in sorted((x for x in sugg if x.get("title")), key=lambda x: x["no"]) if not re.search(r"회신|결과|공유", s["title"])]
    pick = [pool[round(i * (len(pool) - 1) / 3)] for i in range(4)] if len(pool) >= 4 else pool
    res = {
        "actual_end": end,
        "contents": list(ev.get("agenda") or [p["item"] for p in data["program"]]),
        "opinion_subject": "기관",
        "summary": ev.get("summary") or ", ".join(ev.get("agenda") or [])[:40],
        "next_steps": "관련부서 검토 후 처리 예정",
        "plan_lines": [f["task"] for f in data.get("follow_up") or []],
        "suggestions": sugg,
        "mayor_summary": mayor_review(segs, len([x for x in sugg if x.get("title")])),
        "highlights": list(dict.fromkeys(pick)),
        "minutes": mins,
        "photos": [],
    }
    n_sug = len({s["no"] for s in sugg if s.get("title")} or {s["title"] for s in sugg if s.get("title")})
    notes.append(f"속기록에서 건의 {n_sug}건, 시장 총평 {len(res['mayor_summary'])}줄, 참석자 {len(data['attendees'])}명 전원의 발언을 정리(규칙) — 회의록과 대조 필요")
    return res, notes
