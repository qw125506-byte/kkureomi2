# -*- coding: utf-8 -*-
"""Claude API 호출 — 모든 요청은 비식별(mask)을 거치고, 결과는 JSON 스키마(구조화 출력)로 받는다.

- 인증: anthropic SDK 기본 방식(ANTHROPIC_API_KEY, ANTHROPIC_AUTH_TOKEN, `ant auth login` 프로필).
  자격 증명이 없으면 AIUnavailable을 올리고, 부르는 쪽은 사람이 직접 입력하는 모드로 넘어간다.
- 모델: 환경변수 CLAUDE_MODEL(기본 claude-opus-5-5), 노력 수준: CLAUDE_EFFORT(기본 medium).
- 안전 분류기가 거절하면 서버가 다른 모델로 다시 돌리도록 fallbacks="default"를 켠다.
- 보낸 내용(가린 글)은 out/ai_log/에 남긴다. 키·원문 이름은 남기지 않는다.
"""
import datetime
import json
import os
from pathlib import Path

from ai.mask import leaked, mask, unmask

ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = Path(os.environ.get("KKUREOMI_WORK") or ROOT / "out") / "ai_log"
PROMPTS = ROOT / "prompts"
MODEL = os.environ.get("CLAUDE_MODEL", "claude-opus-5-5")
EFFORT = os.environ.get("CLAUDE_EFFORT", "medium")
FALLBACK_BETA = "server-side-fallback-2026-07-01"


class AIUnavailable(RuntimeError):
    """AI를 쓸 수 없음(자격 증명 없음·네트워크 등) — 직접 입력 모드로"""


class AIRefused(RuntimeError):
    """안전 분류기가 요청을 거절함"""


def available():
    """AI를 써 볼 만한지(자격 증명 단서가 있는지). KKUREOMI_AI=off 이면 항상 False(시험·규칙만 쓰기)."""
    if os.environ.get("KKUREOMI_AI", "").lower() in ("off", "0", "no"):
        return False
    if any(os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_PROFILE")):
        return True
    return (Path.home() / ".config" / "anthropic").exists()


def prompt(name):
    return (PROMPTS / f"{name}.md").read_text(encoding="utf-8")


def _client():
    try:
        import anthropic
    except ImportError as e:
        raise AIUnavailable("anthropic 패키지가 없습니다(pip install anthropic)") from e
    try:
        return anthropic.Anthropic()
    except Exception as e:  # noqa: BLE001 — 자격 증명 해석 실패
        raise AIUnavailable(f"Claude API 자격 증명을 찾지 못했습니다: {e}") from e


def _log(name, payload):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    path = LOG_DIR / f"{ts}_{name}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


class Usage:
    """한 실행에서 쓴 호출 수·토큰(비용 보고용)"""
    calls = 0
    input_tokens = 0
    output_tokens = 0

    @classmethod
    def add(cls, u):
        cls.calls += 1
        cls.input_tokens += getattr(u, "input_tokens", 0) or 0
        cls.output_tokens += getattr(u, "output_tokens", 0) or 0

    @classmethod
    def cost_usd(cls):
        # claude-opus-5-5 기준 입력 $4 / 출력 $20 (100만 토큰당)
        return cls.input_tokens * 4 / 1e6 + cls.output_tokens * 20 / 1e6


def ask_json(name, system, user_text, schema, data=None, client=None, max_tokens=16000):
    """user_text를 가려 보내고, schema 모양의 JSON을 받아 이름을 되돌려 돌려준다."""
    masked, table = mask(user_text, data)
    left = leaked(masked, data)
    if left:
        raise RuntimeError(f"비식별 실패: 보낼 글에 개인정보가 남음 {left[:3]}")
    client = client or _client()
    req = dict(
        model=MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": masked}],
        output_config={"effort": EFFORT, "format": {"type": "json_schema", "schema": schema}},
        betas=[FALLBACK_BETA],
        fallbacks="default",
    )
    _log(name, {"model": MODEL, "system": system, "user": masked, "schema": schema})
    last = None
    for _ in range(2):                                  # 형식 오류면 1회 다시
        try:
            resp = client.beta.messages.create(**req)
        except Exception as e:  # noqa: BLE001
            if type(e).__name__ in ("AuthenticationError", "PermissionDeniedError", "APIConnectionError")                     or "authentication" in str(e).lower() or "api_key" in str(e).lower():
                raise AIUnavailable(f"Claude API를 쓸 수 없습니다: {e}") from e
            raise
        Usage.add(getattr(resp, "usage", None))
        if getattr(resp, "stop_reason", None) == "refusal":
            raise AIRefused("Claude가 요청을 거절했습니다(직접 작성해 주세요)")
        text = next((b.text for b in resp.content if getattr(b, "type", "") == "text"), "")
        try:
            return unmask(json.loads(text), table)
        except json.JSONDecodeError as e:
            last = e
    raise RuntimeError(f"AI 응답이 JSON이 아닙니다: {last}")
