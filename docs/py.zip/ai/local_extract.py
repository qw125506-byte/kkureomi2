# -*- coding: utf-8 -*-
"""자료 → 행사데이터 초안(규칙). AI를 쓸 수 없을 때도 「자료 올리기」가 동작하게 한다.

메모·공문·계획서에서 흔한 꼴을 찾아 채운다(찾은 값은 모두 「추정」으로 표시):
- 행사명: 「행사명:」 줄, 또는 「간담회·회의·설명회·협의회·토론회」로 끝나는 첫 줄
- 날짜: 2026. 10. 22. / 2026-10-22 / 2026년 10월 22일 / 10월 22일(올해)
- 시작: 14:00, 오후 2시(30분)
- 장소: 「장소:」「(장 소)」 줄, 또는 회의실·강당·센터가 든 말
- 부서: 「주관」「부서」 줄의 ○○과
- 식순: 「14:00~14:05 개회」 꼴 줄(소요 분 계산)
"""
import datetime
import re

DATE_PATTERNS = [
    re.compile(r"(20\d{2})\s*[.\-년]\s*(\d{1,2})\s*[.\-월]\s*(\d{1,2})"),
    re.compile(r"(?<!\d)(\d{1,2})\s*월\s*(\d{1,2})\s*일"),
]
TIME_HM = re.compile(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)")
TIME_KO = re.compile(r"(오전|오후)\s*(\d{1,2})\s*시(?:\s*(\d{1,2})\s*분)?")
FLOW = re.compile(r"(\d{1,2}:\d{2})\s*[~\-–]\s*(\d{1,2}:\d{2})\s*(?:\d+\s*[’']\s*)?[▪•·\-]?\s*(.+)")
LABEL = lambda names: re.compile(rf"(?:{names})\s*[):：]?\s*(.+)")  # noqa: E731


def calc_min(hhmm):
    h, m = map(int, hhmm.split(":"))
    return h * 60 + m


def _field(value, source, sure=False):
    return {"value": value, "source": source, "confidence": "확실" if sure and value else ("추정" if value else "없음")}


def _first_line(lines, pat):
    for l in lines:
        m = pat.search(l)
        if m:
            return m, l
    return None, ""


def extract(text, year=None):
    year = year or datetime.date.today().year
    lines = [re.sub(r"\s+", " ", l).strip() for l in text.splitlines() if l.strip() and not l.startswith("[자료 ")]

    # 행사명
    m, src = _first_line(lines, LABEL(r"행사명|사업명|제\s*목|건\s*명"))
    title = m.group(1).strip() if m else ""
    if not title:
        for l in lines:
            mm = re.search(r"([^:：()]{2,60}?(?:간담회|회의|설명회|협의회|토론회|포럼|워크숍))(?![실장록])", l)
            if mm and len(mm.group(1)) >= 4 and not l.startswith("("):
                title, src = mm.group(1).strip(), l
                break
    title = re.sub(r"\s*(개최\s*)?계획\s*\(안\)$", "", title)
    f_title = _field(title, src)

    # 날짜
    date, dsrc = "", ""
    for i, pat in enumerate(DATE_PATTERNS):
        m, dsrc = _first_line(lines, pat)
        if m:
            y, mo, d = (int(m.group(1)), int(m.group(2)), int(m.group(3))) if i == 0 else (year, int(m.group(1)), int(m.group(2)))
            try:
                date = datetime.date(y, mo, d).isoformat()
            except ValueError:
                date = ""
            break
    f_date = _field(date, dsrc, sure=bool(date) and i == 0)

    # 시작 시각(날짜 줄 우선)
    start, ssrc = "", ""
    for l in ([dsrc] if dsrc else []) + lines:
        mk = TIME_KO.search(l)
        mh = TIME_HM.search(l)
        if mh:
            start, ssrc = f"{int(mh.group(1)):02d}:{mh.group(2)}", l
            break
        if mk:
            h = int(mk.group(2)) % 12 + (12 if mk.group(1) == "오후" else 0)
            start, ssrc = f"{h:02d}:{int(mk.group(3) or 0):02d}", l
            break
    f_start = _field(start, ssrc)

    # 장소
    m, vsrc = _first_line(lines, LABEL(r"장\s*소|위\s*치"))
    venue = re.split(r"\s{2,}|[|/]", m.group(1))[0].strip() if m else ""
    if not venue:
        m, vsrc = _first_line(lines, re.compile(r"([가-힣0-9 ]{0,20}(?:회의실|강당|대강당|센터|홀|세미나실))"))
        venue = m.group(1).strip() if m else ""
    f_venue = _field(venue, vsrc)

    # 부서
    m, psrc = _first_line(lines, re.compile(r"(?:주관|부서|담당)[^가-힣]*([가-힣]{2,10}과)(?![가-힣])"))
    if not m:
        m, psrc = _first_line(lines, re.compile(r"[\[(]([가-힣]{2,10}과)[\])]"))
    f_dept = _field(m.group(1) if m else "", psrc)

    # 식순
    program = []
    span = re.compile(r"^(\d{1,2}:\d{2})\s*[~\-–]\s*(\d{1,2}:\d{2})$")
    for i, l in enumerate(lines):               # 표 칸이 줄로 풀린 꼴: 시간 / 5’ / ▪ 내용 / 비고
        ms = span.match(l)
        if ms and i + 2 < len(lines):
            rest = [x for x in lines[i + 1:i + 4] if not re.fullmatch(r"\d+\s*[’']", x)]
            if rest and not span.match(rest[0]):
                a, b = ms.group(1), ms.group(2)
                mins = calc_min(b) - calc_min(a)
                lead = rest[1] if len(rest) > 1 and not span.match(rest[1]) and not rest[1].startswith("▪") else ""
                if mins > 0:
                    program.append({"minutes": mins, "item": rest[0].strip(" ▪•·-"), "lead": lead})
    for l in lines if not program else []:
        mm = FLOW.search(l)
        if mm and not mm.group(3).strip().startswith("("):
            a, b = mm.group(1), mm.group(2)
            ah, am = map(int, a.split(":"))
            bh, bm = map(int, b.split(":"))
            mins = (bh * 60 + bm) - (ah * 60 + am)
            item = re.sub(r"\s{2,}.*$", "", mm.group(3)).strip(" ▪•·-")
            if mins > 0 and item:
                program.append({"minutes": mins, "item": item, "lead": ""})
    if program and not start:
        start = FLOW.search(next(l for l in lines if FLOW.search(l))).group(1).zfill(5)
        f_start = _field(start, "식순 첫 줄")

    blank = _field("", "")
    out = {"title": f_title, "slogan": blank, "date": f_date, "start": f_start, "end": blank,
           "venue": f_venue, "dept": f_dept, "purpose": [], "agenda": [], "program": program, "attendees": []}
    return out


def extras_from_text(text):
    lines = [re.sub(r"\s+", " ", l).strip() for l in text.splitlines() if l.strip()]
    return plan_extras(lines)


APPROVER = ("팀장", "과장", "국장", "실장", "단장", "소장")


def plan_extras(lines):
    """계획서에서 더 읽는 값 → {"event": {...}, "attendees": [...], "approval_line": [...], "follow_up": [...]}

    참석 인원·설명, 배석, 주재, 취지(…하고자 함.), ▶주요안건, 결재선, Ⅵ 향후계획 표, 붙임 참석자 명단(기관·성명).
    """
    ev = {}
    for l in lines:
        m = re.search(r"\(참\s*석\s*(?:대\s*상)?\)\s*(\d+\s*명(?:\s*내외)?)\s*\(([^)]+)\)", l)
        if m and "headcount" not in ev:
            ev["headcount"], ev["attendee_label"] = re.sub(r"(\d)\s+명", r"\1명", m.group(1)), m.group(2).strip()
        m = re.search(r"배석\s*\((\d+)\s*명\)\s*[:：]?\s*(.*)", l)
        if m and "staff_count" not in ev:
            ev["staff_count"] = int(m.group(1))
            if m.group(2).strip():
                ev["staff_note"] = m.group(2).strip()
        m = re.search(r"\(주\s*요\s*내\s*용\)\s*(.+)", l)
        if m and "summary" not in ev:
            ev["summary"] = m.group(1).strip()
        m = re.search(r"\(주\s*재\)\s*(\S+)", l)
        if m and "chair" not in ev:
            ev["chair"] = m.group(1)
    for i, l in enumerate(lines):
        if l.endswith("하고자 함."):
            prev = lines[i - 1] if i else ""
            joined = f"{prev} {l}" if prev and not prev.endswith((".", ")")) and len(prev) > 15 else l
            ev["intent"] = re.sub(r"^[-□○◦▪•·\-\s]+", "", joined)   # 한글 글머리 기호 떼기
            break
    for i, l in enumerate(lines):          # 머리문구: 표지 제목(… 계획(안)) 바로 위의 짧은 줄
        if re.search(r"계획\s*\(안\)$", l):
            prev = lines[i - 1] if i else ""
            if prev and len(prev) <= 30 and not re.search(r"[:：()\[\]]|공개|보존|협\s*조|과장$", prev):
                ev["slogan"] = prev.strip(" -–")
            break
    agenda = [re.sub(r"^▶\s*", "", l) for l in lines if l.startswith("▶")]
    if agenda:
        ev["agenda"] = agenda
    org = {}
    for i, l in enumerate(lines[:-1]):     # 표지 왼쪽 표: 보존기간 / 5년, 공개여부 / 부분공개
        key = {"보존기간": "retention", "공개여부": "disclosure"}.get(re.sub(r"\s", "", l))
        nxt = lines[i + 1]
        if key and key not in org and len(nxt) <= 6 and re.search(r"년|영구|공개", nxt):
            org[key] = nxt
    return {"event": ev, "org": org, "attendees": _order(_roster(lines), lines), "approval_line": _approval(lines), "follow_up": _follow_up(lines)}


def _approval(lines):
    """표지 결재란: 담당자 / 청년정책 / 팀장 / … / 시장 / 결 → [담당자, 청년정책팀장, …, 시장]"""
    if "담당자" not in lines:
        return []
    i, out = lines.index("담당자"), []
    for t in lines[i:i + 20]:
        if t in ("결", "결재", "결 재"):
            break
        if t in APPROVER and out and not out[-1].endswith(APPROVER) and out[-1] not in ("담당자", "부시장", "시장"):
            out[-1] += t
        else:
            out.append(t)
    return out if out and out[-1].endswith("시장") else []


def _follow_up(lines):
    """Ⅵ 향후계획 표: 연번 / 내용 / 기한 줄 묶음"""
    try:
        i = next(k for k, l in enumerate(lines) if re.sub(r"\s", "", l) == "향후계획")
    except StopIteration:
        return []
    out, k = [], i + 1
    while k < len(lines) and not lines[k].startswith("붙"):
        if re.fullmatch(r"\d{1,2}", lines[k]) and k + 1 < len(lines):
            item = {"task": lines[k + 1]}
            if k + 2 < len(lines) and not re.fullmatch(r"\d{1,2}", lines[k + 2]) and not lines[k + 2].startswith("붙") \
                    and len(lines[k + 2]) <= 15:
                item["due"] = lines[k + 2]
                k += 1
            out.append(item)
            k += 2
        else:
            k += 1
    return out


HEADS = {"대학명": "org", "기관명": "org", "소속": "org", "기관": "org", "성명": "name", "직위": "position",
         "비고": "position", "사진": None}


POSITION_WORD = r"[가-힣]{0,8}(대표이사|대표|센터장|회장|총장|이사장|원장|소장|단장|위원장|실장|국장|과장|팀장|이사|교수)"


def _roster(lines):
    """붙임 참석자 명단 표 → [{org, position, name}]

    표 머리(대학명/성명/사진, 소속/성명/비고 …)를 읽어 칸 수를 알고, 두 단 표는 왼쪽 단 → 오른쪽 단 순서로 읽는다.
    「상명 / 대학교」처럼 칸 안에서 줄이 나뉜 기관명은 잇는다. 사진 칸은 글자가 없어 건너뛴다.
    """
    try:
        i = next(k for k, l in enumerate(lines) if l.endswith("명단") and not l.startswith("붙임"))
    except StopIteration:
        return []
    pos = re.search(r"(\S+)\s*명단$", lines[i]).group(1)
    pos = pos if re.fullmatch(r"[가-힣]{1,4}", pos) and pos not in ("참석자", "참석") else ""
    k, heads = i + 1, []
    while k < len(lines) and (re.sub(r"\s", "", lines[k]) in HEADS or re.sub(r"\s", "", lines[k]) == "(직위)"):
        if re.sub(r"\s", "", lines[k]) != "(직위)":                # 보고요지 머리 「비 고 / (직 위)」: 괄호 줄은 앞 칸의 둘째 줄
            heads.append(HEADS[re.sub(r"\s", "", lines[k])])
        k += 1
    if not heads:
        return []
    width = len(dict.fromkeys(heads)) if heads.count(heads[0]) > 1 else len(heads)
    cols = max(1, len(heads) // width)
    fields = [h for h in heads[:width] if h]
    toks = []
    while k < len(lines) and not re.match(r"붙\s*임", lines[k]):
        t, nxt = lines[k], (lines[k + 1] if k + 1 < len(lines) else "")
        if nxt in ("대학교", "대학"):
            t, k = t + nxt, k + 1
        toks.append(t)
        k += 1
    if "position" in fields:                       # 소속·성명·비고(직위) 표: 직위 낱말이 칸의 끝 — 줄이 나뉜 기관명도 이을 수 있다
        found, buf = [], []
        for t in toks:
            tt = re.sub(r"\s", "", t)                                  # 「대 표」처럼 띄운 직위
            if re.fullmatch(POSITION_WORD, tt) and len(buf) >= 2 and re.fullmatch(r"[가-힣○ㅇ]{2,4}", buf[-1]):
                found.append({"org": "".join(buf[:-1]).replace(" ", ""), "position": tt, "name": buf[-1]})
                buf = []
            else:
                buf.append(t)
        if found:
            return sorted(found, key=lambda a: (found.index(a) % cols, found.index(a) // cols))
    items = []
    for n in range(0, len(toks) - len(fields) + 1, len(fields)):
        row = dict(zip(fields, toks[n:n + len(fields)]))
        if not re.fullmatch(r"[가-힣]{1,2}[가-힣○ㅇ]{1,3}", row.get("name", "")):
            break
        items.append({"org": row.get("org", ""), "position": row.get("position") or pos, "name": row["name"]})
    # 두 단 표: 줄마다 왼쪽·오른쪽이 번갈아 나오므로 단 순서로 다시 놓는다
    return sorted(items, key=lambda a: (items.index(a) % cols, items.index(a) // cols))


def _order(roster, lines):
    """본문의 기관 나열(「국립공주대, 나사렛대, …」) 순서로 명단을 정렬하고 짧은 기관명(org_short)을 붙인다."""
    joined, buf = [], ""
    for l in lines:                       # 「…, 선문대,」 / 「순천향대, …」처럼 줄이 나뉜 나열을 잇는다
        buf = f"{buf} {l}" if buf else l
        if not buf.endswith(","):
            joined.append(buf)
            buf = ""
    for l in joined:
        names = [x.strip() for x in l.split(",") if x.strip()]
        if len(names) < 3:
            continue
        short = {}
        for a in roster:
            hit = next((n for n in names if a["org"].startswith(n) or a["org"].replace("학교", "") == n), None)
            if hit:
                short[id(a)] = hit
        if len(short) >= len(roster) - 1 and roster:
            rank = {n: i for i, n in enumerate(names)}
            for a in roster:
                if id(a) in short:
                    a["org_short"] = short[id(a)]
            return sorted(roster, key=lambda a: rank.get(a.get("org_short"), 999))
    return roster
