# -*- coding: utf-8 -*-
"""문서꾸러미 — 행사데이터 하나로 간담회 문서 6종을 만들고 검증한다.

    python bundle.py examples/대학총장_간담회.json --out out/
    python bundle.py 데이터.json --out out/ --stage before        # 행사 전: ①②③④⑤ (보도자료는 미리 배포용)
    python bundle.py 데이터.json --minutes 회의록.txt --out out/  # 행사 후: 회의록 → ⑥ 결과보고 자동
    python bundle.py 데이터.json --out out/ --only plan,ppt --extras --render

옵션
  --only     만들 문서(plan,brief,scenario,press,ppt,result). 기본: 전부
  --stage    before | after (--only가 없을 때만)
  --extras   진행 PPT에 진행 순서·참석자 소개·발언 순서 장표 추가
  --render   한글·PowerPoint로 실제로 열어 쪽 그림을 out/render/에 만듦(이 PC 전용, 문서당 수십 초)
결과: 문서 파일, 전체 ZIP, 검증보고.md. 검증 오류가 있으면 종료 코드 1.

자동 작성: 비워 둔 계획서 문구(취지·추진목적·안건·주요내용)와 보도자료(행사 전 예고)는 만들 때 자동으로 쓴다
(Claude API를 쓸 수 있으면 AI, 아니면 정해진 문형). 회의록을 주면 결과보고 내용(건의사항·총평·붙임 회의록)도 자동.
  python bundle.py --from-files 메모.txt 공문.hwpx --out out/새행사      # 자료 → draft.json(행사데이터 초안)
"""
import argparse
import subprocess
import sys
import time
import zipfile
from pathlib import Path

from core import validate
from core.data import EventDataError, load_event
from generators import ppt
from generators.hwpx import brief, plan, press, result, scenario

ROOT = Path(__file__).resolve().parent
ORDER = ["plan", "brief", "scenario", "press", "ppt", "result"]
STAGES = {"before": ["plan", "brief", "scenario", "press", "ppt"], "after": ["result"]}
FILES = {"plan": ("①", "개최 계획", ".hwpx"), "brief": ("②", "보고요지", ".hwpx"),
         "scenario": ("③", "진행 시나리오", ".hwpx"), "press": ("④", "보도자료", ".hwpx"),
         "ppt": ("⑤", "진행", ".pptx"), "result": ("⑥", "결과보고", ".hwpx")}
GEN = {"plan": plan, "brief": brief, "scenario": scenario, "press": press, "result": result}


def safe(s):
    return "".join("_" if c in '\\/:*?"<>|' else c for c in s).strip()


def file_name(data, key):
    no, kind, ext = FILES[key]
    return f'{no} {safe(data["event"]["title"])} {kind}{ext}'


def build_bundle(data, out_dir, docs=None, extras=False, autofill=True):
    """docs 문서를 만들고 {key: 경로}, 경고 목록, 건너뛴 목록을 돌려준다(웹 앱도 이 함수를 쓴다).
    autofill: 비워 둔 계획서 문구·보도자료를 자동 작성(core/autofill.py)."""
    docs = docs or ORDER
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    files, warnings, skipped = {}, [], []
    if autofill:
        from core.autofill import autofill as fill
        data, notes = fill(data)
        warnings += [("press" if "보도자료" in n else "plan", n) for n in notes]
    for key in [k for k in ORDER if k in docs]:
        if key == "result" and not data.get("result"):
            skipped.append(("result", "행사 후 데이터(result)가 없어 결과보고를 건너뜀"))
            continue
        path = out_dir / file_name(data, key)
        r = ppt.generate(data, path, extras=extras) if key == "ppt" else GEN[key].generate(data, path)
        files[key] = path
        warnings += [(key, w) for w in r.get("warnings") or []]
    return files, warnings, skipped


def build_result(data, minutes_path, out_dir, photos=None):
    """회의록 → 결과 데이터(AI 또는 규칙) → ⑥ 결과보고. photos: 붙임 3에 넣을 사진 경로들. (경로, 결과 데이터, 메모)"""
    from ai.extract import read_source
    from ai.result import build_result as make
    from ai import org_table
    rows = org_table.read_table(minutes_path) if Path(minutes_path).suffix.lower() == ".hwpx" else None
    if rows:                                                  # 이미 「기관별 정리」 표로 정리한 한글 파일 → 그 표 그대로
        res, notes = org_table.result_from_rows(rows, data)
    else:
        res, notes = make(read_source(minutes_path), data)
        if not res.get("org_rows"):                           # 붙임 1 「기관별 정리」 표: 건의 하나가 한 행
            res = {**res, "org_rows": org_table.rows_from_result(res, data)}
    if photos:
        res = {**res, "photos": [str(p) for p in photos]}
    full = {**data, "result": res}
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / file_name(full, "result")
    r = result.generate(full, path)
    return path, full, notes + list(r.get("warnings") or [])


def build_minutes_table(data, minutes_path, out_dir):
    """회의록 → 「기관별 정리」 표 한글 파일(대학명·직위·성명·발언내용·핵심요약·시장님답변·관련부서). (경로, 행 수, 메모)
    - 이미 그 표로 정리한 hwpx: 정리 규칙만 다시 적용
    - 이름이 적힌 속기록: 건의 하나가 한 행(규칙)
    - 녹음 앱 회의록(「참석자 1」): 발언자 이름표·발언만 옮긴다(한글에서 이름·요약을 채워 결과보고에 올리면 됨)"""
    import re as _re
    from ai import org_table, steno
    from ai.extract import read_source
    from ai.result import turns
    path = Path(minutes_path)
    rows = org_table.read_table(path) if path.suffix.lower() == ".hwpx" else None
    if rows:
        rows, how = org_table.finish(rows, data), "기관별 정리 표를 읽어 정리 규칙을 적용함"
    else:
        text = read_source(path)
        if steno.looks_like(text) and steno.fits(text, data):
            res, _ = steno.build(text, data)
            rows, how = org_table.rows_from_result(res, data), "속기록에서 참석자 건의를 한 행씩 정리함"
        else:
            rows = [{"org": "", "position": "", "name": who, "say": [" ".join(ls)], "key": [], "answer": [], "depts": []}
                    for who, ls in turns(text)]
            rows = [r for r in (org_table.clean_row(r) for r in rows) if r["say"]]
            how = "녹음 회의록이라 발언자 이름표와 발언만 옮김 — 한글에서 대학명·직위·성명·요약을 채워 주세요"
    orgs = [r["org"] for r in rows if r["org"]]
    subj = "대학" if orgs and all(_re.search(r"대학(교)?$", o) for o in orgs) else "기관"
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f'{safe(data["event"]["title"])} 회의록 정리.hwpx'
    result.generate_minutes_table(data, rows, out, subj)
    return out, len(rows), [how]


def build_result_press(full, out_dir):
    """회의록에서 읽은 결과(full["result"])까지 반영한 결과형 ④ 보도자료 — 결과보고와 함께 만든다."""
    import copy
    from core import autofill
    data = copy.deepcopy(full)
    data["press"] = {**(data.get("press") or {}), **autofill.rule_press(data)}
    path = Path(out_dir) / file_name(data, "press")
    press.generate(data, path)
    return path


def make_zip(data, files, out_dir):
    zp = Path(out_dir) / f'{safe(data["event"]["title"])} 문서꾸러미.zip'
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for key in ORDER:
            if key in files:
                z.write(files[key], files[key].name)
        rep = Path(out_dir) / "검증보고.md"
        if rep.exists():
            z.write(rep, rep.name)
    return zp


def render(files, out_dir):
    """한글(render_check.py)·PowerPoint(render_check.ps1)로 실제로 열어 본다."""
    results = {}
    for key, path in files.items():
        dest = Path(out_dir) / "render" / key
        if path.suffix == ".hwpx":
            cmd = [sys.executable, str(ROOT / "간담회개최계획-hwpx" / "scripts" / "render_check.py"), str(path), str(dest)]
        else:
            cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File",
                   str(ROOT / "간담회진행PPT" / "scripts" / "render_check.ps1"), str(path), str(dest)]
        enc = "utf-8" if path.suffix == ".hwpx" else "cp949"     # PowerShell 5.1 콘솔은 cp949로 출력
        p = subprocess.run(cmd, capture_output=True, text=True, encoding=enc, errors="replace", timeout=600)
        results[key] = (p.returncode == 0, (p.stdout or p.stderr).strip().splitlines()[:1])
    return results


def main(argv=None):
    ap = argparse.ArgumentParser(description="문서꾸러미: 간담회 문서 6종 만들기")
    ap.add_argument("data", nargs="?")
    ap.add_argument("--out", default="out")
    ap.add_argument("--only")
    ap.add_argument("--stage", choices=["before", "after"])
    ap.add_argument("--extras", action="store_true")
    ap.add_argument("--render", action="store_true")
    ap.add_argument("--from-files", nargs="+", metavar="자료")
    ap.add_argument("--minutes", metavar="회의록")
    a = ap.parse_args(argv)
    if a.from_files or a.minutes:
        return ai_main(a)
    if not a.data:
        ap.error("행사데이터 JSON 경로가 필요합니다")

    try:
        data = load_event(a.data)
    except EventDataError as e:
        print(f"[실패] {e}")
        return 2
    docs = a.only.split(",") if a.only else (STAGES[a.stage] if a.stage else ORDER)
    unknown = [d for d in docs if d not in ORDER]
    if unknown:
        print(f"[실패] 모르는 문서: {unknown} (가능: {', '.join(ORDER)})")
        return 2

    t0 = time.perf_counter()
    files, warnings, skipped = build_bundle(data, a.out, docs, a.extras)
    secs = time.perf_counter() - t0
    findings = validate.run_all(data, files)
    rep = Path(a.out) / "검증보고.md"
    rep.write_text(validate.report_md(data, files, findings, secs), encoding="utf-8")
    zp = make_zip(data, files, a.out)

    print(f'[완료] {data["event"]["title"]} — {len(files)}종, {secs:.1f}초')
    for key in ORDER:
        if key in files:
            print(f"  {files[key]}")
    print(f"  {zp}\n  {rep}")
    for k, msg in skipped:
        print(f"[건너뜀] {msg}")
    for k, w in warnings:
        print(f"[주의] {validate.DOC_NAMES[k]}: {w}")
    err = [f for f in findings if f["level"] == "오류"]
    warn = [f for f in findings if f["level"] == "주의"]
    print(f"[검증] 오류 {len(err)}건, 주의 {len(warn)}건")
    for f in err + warn:
        print(f'  - {f["level"]} {f["doc"]} {f["item"]} {f["expected"]} → {f["actual"]}'.rstrip(" →"))
    if a.render:
        for key, (ok, msg) in render(files, a.out).items():
            print(f'[열기] {validate.DOC_NAMES[key]}: {"통과" if ok else "실패"} {" ".join(msg)}')
    return 1 if err else 0


def ai_main(a):
    """자료 → 행사데이터 초안(draft.json), 회의록 → ⑥ 결과보고(+ 결과가 든 행사데이터)."""
    import json
    from ai.client import MODEL, Usage
    from ai.extract import extract_event, save_draft
    out = Path(a.out)
    if a.from_files:
        d = extract_event(a.from_files)
        p = save_draft(d, out / "draft.json")
        print(f"[초안] 자료 {len(a.from_files)}개 → {p} ({d['_meta']['방식']}) — 확인 후 행사데이터로 쓰세요")
    if a.minutes:
        if not a.data:
            print("[실패] --minutes 는 개최계획서(hwpx·txt·pdf) 또는 행사데이터 JSON이 필요합니다")
            return 2
        from core.data import fill_defaults
        if Path(a.data).suffix.lower() == ".json":
            raw = json.loads(Path(a.data).read_text(encoding="utf-8"))
        else:                                   # 계획서 파일만으로: 행사 정보를 읽어 쓴다
            raw = extract_event([a.data])
            raw.pop("_meta", None)
            print(f"[읽기] 계획서 {Path(a.data).name}에서 행사 정보를 읽음")
        raw, filled = fill_defaults(raw)
        try:
            data = load_event(raw)
        except EventDataError as e:
            print(f"[실패] {e}")
            return 2
        path, full, notes = build_result(data, a.minutes, out)
        notes = filled + notes
        raw["result"] = full["result"]
        save_draft(raw, out / "행사데이터_결과포함.json")
        findings = validate.run_all(full, {"result": path})
        err = [f for f in findings if f["level"] == "오류"]
        print(f"[완료] 회의록 → {path}")
        for n in notes:
            print(f"  - {n}")
        print(f"[검증] 오류 {len(err)}건, 「[확인 필요]」 {validate.doc_text(path).count('[확인 필요]')}곳")
    if Usage.calls:
        print(f"[AI] 모델 {MODEL}, 호출 {Usage.calls}회, 입력 {Usage.input_tokens:,} / 출력 {Usage.output_tokens:,} 토큰, "
              f"약 ${Usage.cost_usd():.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
