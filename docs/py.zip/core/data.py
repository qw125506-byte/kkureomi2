# -*- coding: utf-8 -*-
"""공통 행사데이터 읽기 — 스키마 검사 후 계산값(calc.derive)을 붙여 돌려준다."""
import json
from pathlib import Path

try:
    import jsonschema
except ImportError:          # claude.ai 실행 환경 등 jsonschema가 없을 때: 형식 검사만 건너뜀(계산·검증은 그대로)
    jsonschema = None

from core import calc

ROOT = Path(__file__).resolve().parent.parent
SCHEMA_PATH = ROOT / "schema" / "event.schema.json"


class EventDataError(ValueError):
    """스키마에 맞지 않는 행사데이터"""


def schema():
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def schema_errors(data):
    """스키마 오류를 「위치: 내용」 목록으로 돌려준다(없으면 빈 목록)."""
    if jsonschema is None:
        missing = [k for k in schema()["required"] if k not in data]
        return [f"(최상위): '{k}' is a required property" for k in missing]
    v = jsonschema.Draft202012Validator(schema(), format_checker=jsonschema.FormatChecker())
    out = []
    for e in sorted(v.iter_errors(data), key=lambda e: list(e.absolute_path)):
        path = [str(p) for p in e.absolute_path]
        if e.validator == "required":
            path.append(e.message.split("'")[1])
        where = "/".join(path) or "(최상위)"
        line = f"{where}: {_korean(e, path)}"
        if line not in out:                 # 날짜는 pattern·format 두 규칙에 같은 말로 걸림
            out.append(line)
    return out


LABELS = {
    "event/title": "행사명", "event/date": "날짜", "event/start": "시작 시각", "event/end": "종료 시각",
    "event/venue": "장소", "org/city": "기관", "org/dept": "부서", "host/position": "주빈 직위",
    "host/name": "주빈 성명", "result/actual_end": "실제 종료 시각",
    "minutes": "분", "item": "식순 이름", "lead": "진행자", "org": "기관", "position": "직위", "name": "성명",
    "unit": "단가", "qty": "수량", "task": "내용", "role": "직위",
}
LISTS = {"program": "식순", "attendees": "참석자", "staff_present": "배석", "budget": "예산", "admin_tasks": "행정사항",
         "follow_up": "향후계획", "staff": "담당자", "suggestions": "건의사항"}


def _korean(e, path):
    """스키마 오류를 담당자가 알아볼 말로: 「행사명을 입력하세요」 등"""
    key = "/".join(p for p in path if not p.isdigit())
    label = LABELS.get(key) or LABELS.get(path[-1] if path else "", path[-1] if path else "")
    rows = [f"{LISTS.get(path[i - 1], path[i - 1])} {int(p) + 1}번째" for i, p in enumerate(path) if p.isdigit() and i]
    where = (" ".join(rows) + " ") if rows else ""
    if e.validator == "required":
        return f"{where}{label}{josa_eul(label)} 입력하세요"
    if e.validator in ("pattern", "format"):
        hint = "HH:MM(예: 14:00)" if "start" in key or "end" in key else "YYYY-MM-DD(예: 2026-08-12)" if "date" in key else "형식"
        return f"{where}{label} 형식이 맞지 않습니다 — {hint}"
    if e.validator == "minimum":
        return f"{where}{label}{josa_eun(label)} {e.validator_value} 이상이어야 합니다"
    if e.validator == "minItems":
        return f"{LISTS.get(path[-1], label)}을 한 줄 이상 넣으세요"
    if e.validator == "additionalProperties":
        return f"모르는 항목이 있습니다 — {e.message}"
    if e.validator == "type":
        return f"{where}{label} 값의 종류가 맞지 않습니다({e.validator_value})"
    return e.message


def _has_batchim(word):
    ch = (word or " ")[-1]
    return "가" <= ch <= "힣" and (ord(ch) - 0xAC00) % 28 != 0


def josa_eul(w):
    return "을" if _has_batchim(w) else "를"


def josa_eun(w):
    return "은" if _has_batchim(w) else "는"


def load_event(src):
    """파일 경로 또는 dict를 받아 {**data, "derived": {...}}를 돌려준다."""
    data = src if isinstance(src, dict) else json.loads(Path(src).read_text(encoding="utf-8"))
    errs = schema_errors(data)
    if errs:
        raise EventDataError("행사데이터 오류\n- " + "\n- ".join(errs))
    return {**data, "derived": calc.derive(data)}


# ---------- 빈 값 채우기(문서 만들기 버튼을 언제나 쓸 수 있게) ----------
PLACEHOLDER = "[확인 필요]"


def fill_defaults(raw):
    """필수 값이 비어 있으면 자리표시(ㅇㅇ·[확인 필요])로 채운다. (채운 데이터, 알림 목록)

    지어내지 않기: 채운 값은 모두 문서에서 눈에 띄는 자리표시이고, 무엇을 채웠는지 알림으로 돌려준다.
    """
    import copy
    import datetime
    d = copy.deepcopy(raw or {})
    d.pop("_meta", None)
    notes = []
    ev = d.setdefault("event", {})
    org = d.setdefault("org", {})
    host = d.setdefault("host", {})

    def need(obj, key, value, label):
        if not str(obj.get(key) or "").strip():
            obj[key] = value
            notes.append(f"{label}: 비어 있어 「{value}」 넣음")

    need(ev, "title", "ㅇㅇ 간담회", "행사명")
    need(ev, "venue", PLACEHOLDER, "장소")
    need(org, "city", "천안시", "기관")
    need(org, "dept", "ㅇㅇ과", "부서")
    need(host, "position", "천안시장", "주빈 직위")
    need(host, "name", "ㅇㅇㅇ", "주빈 성명")
    if not [x for x in (org.get("approval_line") or []) if str(x).strip()]:
        org["approval_line"] = ["담당자", "ㅇㅇ팀장", "ㅇㅇ과장", "ㅇㅇ국장", "부시장", "시장"]
    if not str(ev.get("start") or "").strip():
        ev["start"] = "14:00"
        notes.append("시작 시각: 비어 있어 「14:00」 넣음")
    try:
        datetime.date.fromisoformat(str(ev.get("date") or ""))
    except ValueError:
        ev["date"] = datetime.date.today().isoformat()
        notes.append(f"날짜: 비어 있어 오늘({ev['date']}) 넣음 — 꼭 고치세요")
    prog = [p for p in (d.get("program") or []) if str(p.get("item") or "").strip()]
    for p in prog:
        try:
            p["minutes"] = max(1, int(p.get("minutes") or 0))
        except (TypeError, ValueError):
            p["minutes"] = 5
    if not prog:
        prog = [{"minutes": 5, "item": "개회 및 참석자 소개", "type": "attendees"},
                {"minutes": 5, "item": "인사말씀", "lead": "시장님", "is_mayor": True, "mayor_task": "인사말씀"},
                {"minutes": 40, "item": "자유 토의", "type": "discussion"},
                {"minutes": 5, "item": "마무리 말씀", "lead": "시장님", "is_mayor": True, "mayor_task": "마무리 말씀"},
                {"minutes": 5, "item": "기념 촬영 및 폐회"}]
        notes.append("식순: 비어 있어 기본 식순(개회·인사말씀·토의·마무리·폐회) 넣음")
    infer_program(prog)
    d["program"] = prog
    d["attendees"] = [a for a in (d.get("attendees") or []) if any(str(v).strip() for v in a.values())]
    for a in d["attendees"]:
        for k in ("org", "position", "name"):
            a.setdefault(k, "")
    return d, notes


def infer_program(prog):
    """화면 식순(시각·분·주요내용·비고)만 있어도 문서에 필요한 표시를 채운다(이미 있으면 그대로).
    - 비고(진행자)에 「시장」이 있으면 시장님 순서 → 보고요지 「시장님 하실 일」에 주요내용을 넣음
    - 「참석자 소개」는 참석자 소개 순서, 「토의·토론·건의·의견」은 토의 순서(시나리오 발언 순서)"""
    import re
    has_disc = any(p.get("type") == "discussion" for p in prog)
    has_att = any(p.get("type") == "attendees" for p in prog)
    for p in prog:
        item, lead = str(p.get("item") or ""), str(p.get("lead") or "")
        if "is_mayor" not in p and re.search(r"(?<!부)시장", lead):
            p["is_mayor"] = True
        if p.get("is_mayor") and "mayor_task" not in p and not re.search(r"토의|토론|건의|의견", item):
            p["mayor_task"] = re.sub(r"\s*\(.*?\)\s*$", "", item)
        if "type" not in p:
            if not has_att and re.search(r"참석자\s*소개", item):
                p["type"], has_att = "attendees", True
            elif not has_disc and re.search(r"토의|토론|건의|의견", item):
                p["type"], has_disc = "discussion", True
    return prog
