# -*- coding: utf-8 -*-
"""내려받는 문서와 똑같은 미리보기 — 이 컴퓨터의 한글·PowerPoint가 직접 그린 쪽 그림(PNG).

- Windows + 한컴오피스 한글(HWPFrame.HwpObject) / PowerPoint 가 있을 때만 쓴다. 없으면 available() 이 False.
- 한글·PowerPoint 를 한 번 띄워 두고 계속 쓴다(처음 한 번만 오래 걸림 — 서버 시작 때 미리 띄움).
- COM 은 한 스레드에서만 다루므로 작업 하나짜리 스레드에서 차례로 그린다.
"""
import io
import os
import shutil
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

DPI = 120
_pool = None
_lock = threading.Lock()
_state = {"hwp": None, "ppt": None, "hwp_ok": None, "ppt_ok": None}


def _init():
    import pythoncom
    pythoncom.CoInitialize()


def _executor():
    global _pool
    with _lock:
        if _pool is None:
            _pool = ThreadPoolExecutor(max_workers=1, initializer=_init)
        return _pool


def _registered(progid):
    if os.name != "nt":
        return False
    try:
        import winreg
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, progid))
        return True
    except OSError:
        return False


def available(kind):
    """kind: "hwpx" 또는 "pptx" — 그 프로그램으로 실제 쪽 그림을 그릴 수 있는가"""
    if os.environ.get("KKUREOMI_EXACT_PREVIEW") == "off":
        return False
    try:
        import win32com.client  # noqa: F401
        import PIL  # noqa: F401
    except ImportError:
        return False
    return _registered("HWPFrame.HwpObject") if kind == "hwpx" else _registered("PowerPoint.Application")


# ---------- 한글
def _hwp():
    import win32com.client as win32
    if _state["hwp"] is not None:
        try:
            _state["hwp"].PageCount            # 살아 있는지 확인
            return _state["hwp"]
        except Exception:  # noqa: BLE001
            _state["hwp"] = None
    hwp = win32.Dispatch("HWPFrame.HwpObject")
    try:
        hwp.RegisterModule("FilePathCheckDLL", "FilePathCheckerModule")
    except Exception:  # noqa: BLE001
        pass
    hwp.XHwpWindows.Item(0).Visible = False
    hwp.SetMessageBoxMode(0x00020021)
    _state["hwp"] = hwp
    return hwp


def _hwpx_pages(path):
    from PIL import Image
    hwp = _hwp()
    work = Path(tempfile.mkdtemp(prefix="kk_view_"))
    try:
        src = work / "view.hwpx"
        shutil.copyfile(path, src)
        if not hwp.Open(str(src), "HWPX", "forceopen:true"):
            raise RuntimeError("한글이 파일을 열지 못했습니다")
        hwp.Run("MoveDocEnd")                 # 끝까지 쪽 배치를 마치게 한 뒤 그린다
        hwp.Run("MoveDocBegin")
        pages = []
        for i in range(hwp.PageCount):
            bmp = work / f"p{i + 1:03d}.bmp"
            if not hwp.CreatePageImage(str(bmp), i, DPI, 24, "bmp") or not bmp.exists():
                raise RuntimeError(f"{i + 1}쪽 그림을 만들지 못했습니다")
            buf = io.BytesIO()
            Image.open(bmp).convert("RGB").save(buf, "PNG", optimize=True)
            pages.append(buf.getvalue())
        hwp.Clear(1)
        return pages
    finally:
        shutil.rmtree(work, ignore_errors=True)


# ---------- PowerPoint
def _pptx_pages(path):
    import win32com.client as win32
    if _state["ppt"] is None:
        _state["ppt"] = win32.Dispatch("PowerPoint.Application")
    app = _state["ppt"]
    work = Path(tempfile.mkdtemp(prefix="kk_view_"))
    try:
        src = work / "view.pptx"
        shutil.copyfile(path, src)
        pres = app.Presentations.Open(str(src), True, False, False)     # 읽기 전용, 창 없이
        try:
            w = 1280
            h = round(w * pres.PageSetup.SlideHeight / pres.PageSetup.SlideWidth)
            pages = []
            for i in range(1, pres.Slides.Count + 1):
                png = work / f"s{i:03d}.png"
                pres.Slides(i).Export(str(png), "PNG", w, h)
                pages.append(png.read_bytes())
            return pages
        finally:
            pres.Close()
    finally:
        shutil.rmtree(work, ignore_errors=True)


def page_images(path, timeout=150):
    """문서 → 쪽(장표)별 PNG 바이트 목록. 프로그램이 없거나 실패하면 예외."""
    kind = Path(path).suffix.lower().lstrip(".")
    if not available(kind):
        raise RuntimeError("이 컴퓨터에서는 한글·PowerPoint로 그릴 수 없습니다")
    fn = _hwpx_pages if kind == "hwpx" else _pptx_pages
    try:
        return _executor().submit(fn, str(path)).result(timeout=timeout)
    finally:
        _arm_idle_close()


IDLE_SECONDS = 600
_idle = {"timer": None}


def _arm_idle_close():
    """미리보기를 10분 동안 안 쓰면 숨겨 둔 한글·PowerPoint를 닫는다(창을 그냥 닫아 서버가 꺼져도 오래 남지 않게)."""
    with _lock:
        if _idle["timer"] is not None:
            _idle["timer"].cancel()
        t = threading.Timer(IDLE_SECONDS, close)
        t.daemon = True
        _idle["timer"] = t
        t.start()


def warm_up(sample_hwpx=None):
    """서버 시작 때 한글을 미리 띄워 둔다(처음 한 번 수십 초 걸리는 준비를 미리)."""
    if not available("hwpx"):
        return

    _arm_idle_close()

    def go():
        _hwp()
        if sample_hwpx and Path(sample_hwpx).exists():
            try:
                _hwpx_pages(sample_hwpx)
            except Exception:  # noqa: BLE001
                pass
    _executor().submit(go)


def close():
    """서버를 끌 때 숨겨 둔 한글·PowerPoint도 닫는다(사용자가 직접 연 창은 건드리지 않음)."""
    if _pool is None:
        return

    def go():
        if _state["hwp"] is not None:
            try:
                _state["hwp"].Clear(1)
                _state["hwp"].Quit()
            except Exception:  # noqa: BLE001
                pass
            _state["hwp"] = None
        if _state["ppt"] is not None:
            try:
                if _state["ppt"].Presentations.Count == 0:      # 우리가 연 발표만 있었을 때만 끔
                    _state["ppt"].Quit()
            except Exception:  # noqa: BLE001
                pass
            _state["ppt"] = None
    try:
        _pool.submit(go).result(timeout=20)
    except Exception:  # noqa: BLE001
        pass
