# -*- coding: utf-8 -*-
"""웹 기능의 본체 — 서버(server/app.py, FastAPI)와 브라우저판(webapi.py, Pyodide)이 같이 쓴다.

- run_generate: 행사데이터 → 행사 전 문서(빈 필수 값은 자리표시로 채움), 검증보고, ZIP
- run_result:   계획서 + 회의록 파일 → ⑥ 결과보고(회의록은 발언 형식·파일 이름으로 알아봄)
"""
import json
import re
import time
from pathlib import Path

import bundle
from core import validate
from core.data import EventDataError, fill_defaults, load_event

SOURCE_EXT = (".txt", ".md", ".hwpx", ".pdf")
PDF_OK = True          # 브라우저판(webapi)은 PDF를 못 읽어 False — 안내 문구에서 pdf를 뺀다


def kinds():
    return "txt·hwpx·pdf" if PDF_OK else "txt·hwpx"


class ServiceError(Exception):
    """화면에 그대로 보여 줄 오류(status는 HTTP 상태 코드로 씀)"""

    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


def exact_key(data, extra=""):
    """입력 데이터의 지문(같은 입력이면 브라우저·PC 어디서나 같은 값) — 미리 그려 둔 실제 쪽 그림을 찾을 때 쓴다"""
    import hashlib
    body = json.dumps({k: v for k, v in data.items() if k not in ("derived", "_meta")}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1((body + "|" + extra).encode("utf-8")).hexdigest()[:16]


def load_filled(data):
    """빈 필수 값은 자리표시로 채워서 읽는다(버튼을 언제나 쓸 수 있게). (행사데이터, 알림)"""
    filled, notes = fill_defaults(data)
    try:
        return load_event(filled), notes
    except EventDataError as e:
        raise ServiceError(422, str(e))


def merge(base, extra):
    """base의 빈 값만 extra로 채운다(사전은 안쪽까지)."""
    out = dict(base)
    for k, v in (extra or {}).items():
        cur = out.get(k)
        if isinstance(cur, dict) and isinstance(v, dict):
            out[k] = merge(cur, v)
        elif cur in (None, "", [], {}):
            out[k] = v
    return out


def is_minutes(path, text):
    """회의록(녹취·속기록)인지: 파일 이름, 녹음 정보, 발언자 줄(「참석자 1 00:05」「[홍길동 / 천안시장]」) 수로 판단"""
    from ai.result import HEAD, _speaker
    name = Path(path).name
    if any(w in name for w in ("회의록", "녹취", "녹음", "속기")):
        return True
    if any(w in name for w in ("계획", "결과보고")):
        return False
    speakers = sum(1 for l in text.splitlines() if _speaker(l.strip()) and not l.strip().startswith(("(", "❍", "○")))
    return bool(HEAD.search(text[:500])) or speakers >= 3


def check_upload(name, data, what):
    if Path(name).suffix.lower() not in SOURCE_EXT:
        raise ServiceError(400, f"지원하지 않는 파일입니다: {name} — {kinds()} {what}을 올려 주세요")
    if not data:
        raise ServiceError(400, f"빈 파일입니다: {name}")


def run_generate(raw, docs, out, extras=False, minutes=None):
    data, notes = load_filled(raw or {})
    docs = docs or bundle.ORDER
    bad = [d for d in docs if d not in bundle.ORDER]
    if bad:
        raise ServiceError(400, f"모르는 문서: {bad}")
    out = Path(out)
    t0 = time.perf_counter()
    try:
        files, warnings, skipped = bundle.build_bundle(data, out, docs, bool(extras))
    except Exception as e:  # noqa: BLE001 — 생성 실패는 화면에 그대로 알림
        raise ServiceError(500, f"문서 생성 실패: {e}")
    if minutes and "press" in files:                      # 올려 둔 회의록이 있으면 보도자료를 회의록 내용(건의·답변·시장 발언)으로
        try:
            from ai.result import build_result as make_result
            res, _ = make_result(minutes, data)
            files["press"] = bundle.build_result_press({**data, "result": res}, out)
            notes = list(notes) + ["④ 보도자료는 올려 둔 회의록 내용(건의·시 답변·시장 발언)으로 작성했습니다."]
            warnings = [(k, w) for k, w in warnings if k != "press"]      # 계획만으로 쓸 때의 보도자료 안내는 빼기
        except Exception as e:  # noqa: BLE001 — 안 되면 계획 내용으로 쓴 보도자료를 그대로
            notes = list(notes) + [f"회의록을 보도자료에 반영하지 못했습니다({type(e).__name__}) — 계획 내용으로 작성했습니다"]
    secs = time.perf_counter() - t0
    findings = validate.run_all(data, files)
    (out / "검증보고.md").write_text(validate.report_md(data, files, findings, secs), encoding="utf-8")
    zp = bundle.make_zip(data, files, out)
    return {
        "seconds": round(secs, 2),
        "files": [{"key": k, "name": files[k].name, "label": validate.DOC_NAMES[k]} for k in bundle.ORDER if k in files],
        "warnings": [{"doc": validate.DOC_NAMES[k], "text": w} for k, w in warnings],
        "skipped": [m for _, m in skipped],
        "findings": findings, "notes": notes, "exact_key": exact_key(data, "min:" + minutes if minutes else ""),
        "checks": check_counts(files),
        "_paths": {**{k: str(v) for k, v in files.items()}, "zip": str(zp)},
    }


def check_counts(files):
    """문서마다 「[확인 필요]」가 몇 곳 남았는지 → [{label, count}] (화면에서 어디를 채워야 하는지 알려 줌)"""
    out = []
    for k in bundle.ORDER:
        if k in files:
            try:
                n = validate.doc_text(files[k]).count("[확인 필요]")
            except Exception:  # noqa: BLE001 — 세기만 못 하면 건너뜀
                continue
            if n:
                out.append({"label": validate.DOC_NAMES[k], "count": n})
    return out


def _result_base(paths, form):
    """올린 파일 → (글 사전, 회의록들, 계획서들, 계획서+화면을 합친 행사데이터, 메모)"""
    from ai.extract import extract_event, read_source
    try:
        texts = {p: read_source(p) for p in paths}
    except ImportError:
        raise ServiceError(400, "이 화면에서는 PDF를 읽을 수 없습니다 — txt·hwpx 파일로 올려 주세요")
    minutes = [p for p in paths if is_minutes(p, texts[p])]
    plans = [p for p in paths if p not in minutes]
    if not minutes:
        raise ServiceError(400, f"회의록 파일을 찾지 못했습니다 — 회의록(녹취·속기록 {kinds()})을 함께 올려 주세요")
    notes = []
    if plans:
        draft = extract_event(plans)
        draft.pop("_meta", None)
        base = merge(draft, form or {})
        notes.append(f"계획서({', '.join(Path(p).name for p in plans)})에서 행사 정보를 읽음")
    else:
        base = dict(form or {})
        notes.append("계획서가 없어 화면의 행사 정보로 만듦 — 계획서를 함께 올리면 더 정확합니다")
    base.pop("result", None)
    return texts, minutes, plans, base, notes


def speakers(paths, form):
    """회의록 발언자 이름표와 고를 사람(주빈·참석자·배석) — 화면 「발언자 짝짓기」용"""
    from ai.result import speaker_labels
    texts, minutes, _, base, _ = _result_base(paths, form)
    labels = []
    for p in minutes:
        for x in speaker_labels(texts[p]):
            if x["label"] not in {y["label"] for y in labels}:
                labels.append(x)
    ev, _ = load_filled(base)
    people = {"host": {"name": ev["host"].get("name", ""), "position": ev["host"].get("position", "")},
              "attendees": [{"name": a.get("name", ""), "org": a.get("org", ""), "position": a.get("position", "")}
                            for a in ev["attendees"] if a.get("name")],
              "staff": [{"name": s.get("name", ""), "position": s.get("position", "")}
                        for s in ev.get("staff_present") or [] if s.get("name")]}
    return {"labels": labels, "people": people}


def run_result(paths, form, out, photos=None, speakers=None):
    """paths: 올린 파일 경로들(계획서·회의록 섞여도 됨), form: 화면의 행사데이터(계획서에 없는 값만 채움),
    speakers: 회의록 발언자 짝 {「참석자 1」: {kind, name, org, position}} — 주면 속기록 꼴로 바꿔 정리한다"""
    out = Path(out)
    t0 = time.perf_counter()
    texts, minutes, plans, base, notes = _result_base(paths, form)
    ev, filled = load_filled(base)
    src = Path(minutes[0])
    if len(minutes) > 1 or speakers:
        from ai.result import apply_speakers
        body = "\n\n".join(texts[p] for p in minutes)
        if speakers:
            body = apply_speakers(body, speakers)
            notes.append(f"회의록 발언자 {len(speakers)}명을 고른 사람으로 맞춰 정리함")
        src = out / ("_회의록_발언자.txt" if speakers else "_회의록_합침.txt")
        out.mkdir(parents=True, exist_ok=True)
        src.write_text(body, encoding="utf-8")
    key = exact_key(ev, src.read_text(encoding="utf-8", errors="ignore") if src.suffix.lower() in (".txt", ".md") else src.name)
    photos = [Path(p) for p in photos or []]
    base_key = key                                           # 사진 없는 같은 결과보고의 지문(화면이 사진 쪽만 덧붙여 미리보기를 만든다)
    if photos:                                               # 사진을 넣으면 미리 그려 둔 예시 쪽 그림과 달라진다 — 지문에 사진도 넣음
        import hashlib
        key = exact_key(ev, key + "|photos:" + hashlib.sha1(b"".join(p.read_bytes() for p in photos)).hexdigest())
    try:
        path, full, more = bundle.build_result(ev, src, out, photos)
    except Exception as e:  # noqa: BLE001
        raise ServiceError(500, f"결과보고 생성 실패: {e}")
    findings = validate.run_all(full, {"result": path})
    checks = validate.doc_text(path).count("[확인 필요]")
    press_path = None
    try:                                                     # 회의록 내용을 반영한 결과형 보도자료도 함께(실패해도 결과보고는 그대로)
        press_path = bundle.build_result_press(full, out)
    except Exception as e:  # noqa: BLE001
        more = more + [f"결과형 보도자료는 만들지 못했습니다({type(e).__name__}) — 결과보고만 만들었습니다"]
    files = [{"key": "result", "name": path.name, "label": validate.DOC_NAMES["result"]}]
    paths = {"result": str(path)}
    if press_path:
        files.append({"key": "press", "name": press_path.name, "label": "④ 보도자료(회의록 반영)"})
        paths["press"] = str(press_path)
    return {"seconds": round(time.perf_counter() - t0, 2),
            "files": files,
            "notes": notes + filled + more, "checks": checks, "findings": findings,
            "plan_files": [Path(p).name for p in plans], "minutes_files": [Path(p).name for p in minutes], "exact_key": key,
            "exact_base": base_key, "photo_count": len(photos),
            "_paths": paths}


def preview_html(path):
    """내려받는 문서와 같은 모양의 미리보기(HTML) — 표·글꼴·정렬·그림·장표 배치를 그대로(core/preview.py)"""
    from core.preview import document_html
    p = Path(path)
    try:
        return document_html(p)
    except Exception:  # noqa: BLE001 — 모양 미리보기가 안 되면 글자만이라도
        from html import escape
        lines = validate.doc_text(p).splitlines()
        body = "".join(f"<p>{escape(x)}</p>" for x in lines if x.strip())
        return f'<!doctype html><meta charset="utf-8"><title>{escape(p.name)}</title><h3>{escape(p.name)}</h3>{body}'


def example_data(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

