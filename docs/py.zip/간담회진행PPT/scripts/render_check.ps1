﻿# PowerPoint로 실제 열어 슬라이드별 PNG를 만든다(열리지 않으면 실패).
#   powershell -File scripts/render_check.ps1 <deck.pptx> <출력폴더>
param([string]$Deck, [string]$OutDir)
$Deck = (Resolve-Path $Deck).Path
New-Item -ItemType Directory -Force $OutDir | Out-Null
$OutDir = (Resolve-Path $OutDir).Path
Get-ChildItem $OutDir -Filter "slide-*.png" | Remove-Item -Force
$app = New-Object -ComObject PowerPoint.Application
try {
    $p = $app.Presentations.Open($Deck, $true, $false, $false)  # ReadOnly, Untitled=false, WithWindow=false
    foreach ($s in $p.Slides) {
        $s.Export((Join-Path $OutDir ("slide-{0:D2}.png" -f $s.SlideIndex)), "PNG", 1600, 900)
    }
    "슬라이드 $($p.Slides.Count)장 렌더 완료: $OutDir"
    $p.Close()
} finally { $app.Quit() }
