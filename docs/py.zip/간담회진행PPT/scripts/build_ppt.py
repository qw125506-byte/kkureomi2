# -*- coding: utf-8 -*-
"""간담회 진행 PPT 생성기 — 견본(templates/견본_간담회진행.pptx)을 복제해 내용만 바꾼다.

    python scripts/build_ppt.py <행사데이터.json> <출력.pptx> [--extras]

견본 구성: 1 표지 / 2 식순 장표(제목만 가운데) / 8 감사합니다.
- 표지: 행사명, (일시)(장소)(주최·주관)을 데이터로 바꾼다. 글이 길면 정보줄을 두 줄로 나눈다.
- 식순 장표: 견본 2번 장표를 식순 수만큼 복제해 제목만 바꾼다.
- 감사합니다: 견본 그대로.
- 배경색·주황 띠·로고(365 행복 천안, 시 상징)·글꼴은 견본 그대로 둔다.
--extras: 같은 모양(남색 바탕·로고·주황)으로 진행 순서, 참석자 소개, 발언 순서 장표를 추가한다.
시나리오 멘트(program[].script)는 각 장표의 발표자 노트로 들어간다.
"""
import json, re, shutil, sys, tempfile, zipfile, datetime
from pathlib import Path
from xml.sax.saxutils import escape

HERE = Path(__file__).resolve().parent.parent
TEMPLATE = HERE / "templates" / "견본_간담회진행.pptx"

EMU = 914400
NAVY, PANEL, ORANGE, GRAY, WHITE, RULE = "14233D", "2B384F", "F0883E", "9FAABB", "F7F5F0", "3A4760"
SLIDE_W, SLIDE_H = 12192000, 6858000
WEEK = "월화수목금토일"

REL_SLIDE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"
REL_NOTES = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide"
CT_SLIDE = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"
CT_NOTES = "application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"


# ---------- 데이터 ----------
def fmt_date(iso):
    d = datetime.date.fromisoformat(iso)
    return f"{d.year}. {d.month}. {d.day}.({WEEK[d.weekday()]})"


def add_min(hhmm, m):
    h, mm = map(int, hhmm.split(":"))
    t = h * 60 + mm + m
    return f"{t // 60:02d}:{t % 60:02d}"


def with_times(event, program):
    cur, out = event["start"], []
    for i, p in enumerate(program, 1):
        end = add_min(cur, p["minutes"])
        out.append({**p, "no": i, "start": cur, "end": end})
        cur = end
    return out


def text_width(s, pt):
    """글자 폭 추정(EMU). 한글은 1em, 영문·숫자·기호는 0.55em."""
    em = pt * 12700
    return int(sum(em if ord(c) > 0x2E7F else em * 0.55 for c in s))


# ---------- XML 조각 ----------
def run(text, sz=None, bold=False, color=None):
    attrs = 'lang="ko-KR" altLang="en-US" dirty="0"'
    if sz:
        attrs += f' sz="{int(sz * 100)}"'
    if bold:
        attrs += ' b="1"'
    fill = f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill>' if color else ""
    return f'<a:r><a:rPr {attrs}>{fill}</a:rPr><a:t>{escape(text)}</a:t></a:r>'


def para(runs, algn="l"):
    return f'<a:p><a:pPr algn="{algn}"><a:buNone/></a:pPr>{"".join(runs)}</a:p>'


def textbox(sid, name, x, y, w, h, paras, anchor="ctr"):
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="{escape(name)}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{int(x)}" y="{int(y)}"/><a:ext cx="{int(w)}" cy="{int(h)}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
            f'<p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="{anchor}"><a:noAutofit/></a:bodyPr>'
            f'<a:lstStyle/>{"".join(paras)}</p:txBody></p:sp>')


def shape(sid, name, prst, x, y, w, h, fill=None, line=None, line_w=1.25, text_paras=None):
    fill_xml = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else "<a:noFill/>"
    line_xml = (f'<a:ln w="{int(line_w * 12700)}"><a:solidFill><a:srgbClr val="{line}"/></a:solidFill></a:ln>'
                if line else "<a:ln><a:noFill/></a:ln>")
    geom = f'<a:prstGeom prst="{prst}"><a:avLst/></a:prstGeom>'
    if prst == "roundRect":
        geom = '<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 12000"/></a:avLst></a:prstGeom>'
    body = ""
    if text_paras:
        body = ('<p:txBody><a:bodyPr lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:noAutofit/></a:bodyPr>'
                f'<a:lstStyle/>{"".join(text_paras)}</p:txBody>')
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="{escape(name)}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{int(x)}" y="{int(y)}"/><a:ext cx="{int(w)}" cy="{int(h)}"/></a:xfrm>'
            f'{geom}{fill_xml}{line_xml}</p:spPr>{body}</p:sp>')


class Ids:
    def __init__(self, start=100):
        self.n = start

    def __call__(self):
        self.n += 1
        return self.n


# ---------- 장표 만들기 ----------
def set_title(xml, text, algn="ctr"):
    """제목 자리(ph type=title)의 글자를 바꾸고, 길면 두 줄 높이로 키운다."""
    m = re.search(r'(<p:sp>(?:(?!</p:sp>).)*?<p:ph type="title"/>.*?</p:sp>)', xml, flags=re.S)
    sp = m.group(1)
    box_x, box_w = 1000000, SLIDE_W - 1800000          # 주황 띠·화면 가장자리에서 띄움
    lines = 1 if text_width(text, 56) <= box_w else 2
    sz = None if lines == 1 else 48                      # 두 줄이면 56pt → 48pt
    h = 843260 if lines == 1 else 1500000
    y = 3007370 + 843260 // 2 - h // 2
    new = re.sub(r'(<a:p><a:pPr[^>]*>.*?</a:pPr>).*?(<a:endParaRPr)',
                 lambda mm: (mm.group(1).replace('algn="l"', f'algn="{algn}"')
                             .replace('<a:lnSpc><a:spcPts val="6440"/></a:lnSpc>',
                                      '<a:lnSpc><a:spcPts val="6440"/></a:lnSpc>' if lines == 1 else '<a:lnSpc><a:spcPts val="5800"/></a:lnSpc>'))
                 + run(text, sz=sz, bold=True) + mm.group(2),
                 sp, count=1, flags=re.S)
    new = re.sub(r'<a:off x="\d+" y="\d+"/><a:ext cx="\d+" cy="\d+"/>',
                 f'<a:off x="{box_x}" y="{y}"/><a:ext cx="{box_w}" cy="{h}"/>', new, count=1)
    return xml.replace(sp, new)


def drop_empty_textbox(xml):
    """견본에 쓰지 않는 빈 글상자(Text 1)를 지운다."""
    return re.sub(r'<p:sp><p:nvSpPr><p:cNvPr id="3" name="Text 1"/>.*?</p:sp>', "", xml, count=1, flags=re.S)


def cover_xml(tpl, data):
    xml = set_title(drop_empty_textbox(tpl), data["event"]["title"])
    # 견본 정보줄 3개(Text 4, Text 6, Text 8)를 지우고 다시 배치
    for name in ("Text 4", "Text 6", "Text 8"):
        xml = re.sub(rf'<p:sp><p:nvSpPr><p:cNvPr id="\d+" name="{name}"/>.*?</p:sp>', "", xml, count=1, flags=re.S)
    ev, org = data["event"], data["org"]
    items = [("일시", f'{fmt_date(ev["date"])} {ev["start"]}'),
             ("장소", ev["venue"]),
             ("주최·주관", org.get("host_label") or f'{org["city"]} {org["dept"]}')]
    sz, gap = 20, int(0.45 * EMU)
    line_x, line_w = 1752383, 8585138
    widths = [text_width(f"({k}) {v}", sz) + 60000 for k, v in items]
    rows, cur = [], []
    for it, w in zip(items, widths):
        if cur and sum(c[1] for c in cur) + gap * len(cur) + w > line_w:
            rows.append(cur); cur = []
        cur.append((it, w))
    rows.append(cur)
    ids, shapes, y = Ids(), [], 5340000
    for r in rows:
        runs = []
        for j, ((k, v), _) in enumerate(r):
            if j:
                runs.append(run("      ", sz))
            runs += [run(f"({k}) ", sz, color=GRAY), run(v, sz, color=WHITE)]
        shapes.append(textbox(ids(), f"정보줄-{len(shapes) + 1}", line_x, y, line_w, 330000, [para(runs, "ctr")]))
        y += 430000
    return xml.replace("</p:spTree>", "".join(shapes) + "</p:spTree>")


def step_xml(tpl, st):
    return set_title(drop_empty_textbox(tpl), st["item"])


def extra_base(tpl, heading):
    """견본 식순 장표에서 제목 자리를 지우고 위쪽 제목을 단 바탕을 만든다(로고·주황 띠 유지)."""
    xml = drop_empty_textbox(tpl)
    xml = re.sub(r'<p:sp>(?:(?!</p:sp>).)*?<p:ph type="title"/>.*?</p:sp>', "", xml, count=1, flags=re.S)
    head = textbox(90, "장표 제목", 203200, int(1.2 * EMU), SLIDE_W - 203200, int(0.6 * EMU),
                   [para([run(heading, 32, True, WHITE)], "ctr")])
    return xml, [head]


def finish(xml, shapes):
    return xml.replace("</p:spTree>", "".join(shapes) + "</p:spTree>")


def order_xml(tpl, steps):
    xml, sh = extra_base(tpl, "진행 순서")
    ids = Ids()
    left, right = int(1.3 * EMU), int(12.1 * EMU)
    top, rh = int(2.05 * EMU), int(min(0.7, 5.0 / len(steps)) * EMU)
    for i, st in enumerate(steps):
        y = top + i * rh
        if i:
            sh.append(shape(ids(), f"구분선-{st['no']}", "line", left, y - int(0.06 * EMU), right - left, 0, line=RULE, line_w=0.75))
        d = int(0.46 * EMU)
        sh.append(shape(ids(), f"번호-{st['no']}", "ellipse", left, y + (rh - d) // 2 - int(0.06 * EMU), d, d, fill=ORANGE,
                        text_paras=[para([run(str(st["no"]), 16, True, NAVY)], "ctr")]))
        cy, ch = y - int(0.06 * EMU), rh
        sh.append(textbox(ids(), f"시간-{st['no']}", left + int(0.7 * EMU), cy, int(2.0 * EMU), ch,
                          [para([run(f'{st["start"]}~{st["end"]}', 18, color=GRAY)])]))
        sh.append(textbox(ids(), f"순서-{st['no']}", left + int(2.85 * EMU), cy, int(5.0 * EMU), ch,
                          [para([run(st["item"], 22, True, WHITE)])]))
        sh.append(textbox(ids(), f"진행-{st['no']}", left + int(7.9 * EMU), cy, int(1.9 * EMU), ch,
                          [para([run(st["lead"], 16, color=GRAY)])]))
        sh.append(textbox(ids(), f"분-{st['no']}", right - int(0.9 * EMU), cy, int(0.9 * EMU), ch,
                          [para([run(f'{st["minutes"]}분', 16, color=GRAY)], "r")]))
    return finish(xml, sh)


def attendees_xml(tpl, data):
    xml, sh = extra_base(tpl, "참석자 소개")
    ids, left, width = Ids(), int(1.0 * EMU), int(11.4 * EMU)
    h = data["host"]
    host_label = f'{h["org"] + " " if h.get("org") else ""}{h["position"]}'
    sh.append(shape(ids(), "주빈", "roundRect", left, int(2.0 * EMU), width, int(0.62 * EMU), fill=ORANGE,
                    text_paras=[para([run(host_label + "  ", 18, color=NAVY), run(h["name"], 22, True, NAVY)], "ctr")]))
    att = data["attendees"]
    cols, gap = 4, int(0.2 * EMU)
    cw, ch = (width - gap * (cols - 1)) // cols, int(0.92 * EMU)
    rows = (len(att) + cols - 1) // cols
    for i, a in enumerate(att):
        x = left + (i % cols) * (cw + gap)
        y = int(2.85 * EMU) + (i // cols) * (ch + int(0.15 * EMU))
        sh.append(shape(ids(), f"카드-{i + 1}", "roundRect", x, y, cw, ch, fill=PANEL))
        sh.append(textbox(ids(), f"기관-{i + 1}", x + int(0.2 * EMU), y + int(0.1 * EMU), cw - int(0.6 * EMU), int(0.32 * EMU),
                          [para([run(a["org"], 14, color=GRAY)])]))
        sh.append(textbox(ids(), f"번호-{i + 1}", x + cw - int(0.5 * EMU), y + int(0.1 * EMU), int(0.32 * EMU), int(0.32 * EMU),
                          [para([run(str(i + 1), 12, True, ORANGE)], "r")]))
        sh.append(textbox(ids(), f"성명-{i + 1}", x + int(0.2 * EMU), y + int(0.45 * EMU), cw - int(0.3 * EMU), int(0.38 * EMU),
                          [para([run(a["position"] + " ", 15, color=WHITE), run(a["name"], 19, True, WHITE)])]))
    staff = data.get("staff_present") or []
    if staff:
        y = int(2.85 * EMU) + rows * (ch + int(0.15 * EMU)) + int(0.05 * EMU)
        sh.append(textbox(ids(), "배석", left, y, width, int(0.36 * EMU),
                          [para([run("배석   ", 15, True, ORANGE),
                                 run("  ·  ".join(f'{p["position"]} {p["name"]}' for p in staff), 15, color=GRAY)])]))
    return finish(xml, sh)


def discussion_xml(tpl, data, st):
    xml, sh = extra_base(tpl, "발언 순서")
    ids, left, width = Ids(), int(1.0 * EMU), int(11.4 * EMU)
    d = data.get("discussion") or {}
    meta = "  ·  ".join(x for x in [st.get("desc"), st.get("lead"), d.get("order_note"),
                                     f'기관별 {d["per_speaker_minutes"]}분 내외' if d.get("per_speaker_minutes") else None] if x)
    sh.append(textbox(ids(), "토의 안내", 203200, int(1.85 * EMU), SLIDE_W - 203200, int(0.4 * EMU),
                      [para([run(meta, 16, color=GRAY)], "ctr")]))
    att = data["attendees"]
    cols, gap = 3, int(0.25 * EMU)
    rows = (len(att) + cols - 1) // cols
    cw = (width - gap * (cols - 1)) // cols
    ch = int(min(0.82, (4.55 - (rows - 1) * 0.15) / rows) * EMU)
    for i, a in enumerate(att):
        x = left + (i % cols) * (cw + gap)
        y = int(2.5 * EMU) + (i // cols) * (ch + int(0.15 * EMU))
        dd = int(0.5 * EMU)
        sh.append(shape(ids(), f"카드-{i + 1}", "roundRect", x, y, cw, ch, fill=PANEL))
        sh.append(shape(ids(), f"순번-{i + 1}", "ellipse", x + int(0.2 * EMU), y + (ch - dd) // 2, dd, dd, fill=ORANGE,
                        text_paras=[para([run(str(i + 1), 16, True, NAVY)], "ctr")]))
        sh.append(textbox(ids(), f"기관-{i + 1}", x + int(0.9 * EMU), y, cw - int(1.0 * EMU), ch,
                          [para([run(a["org"], 19, True, WHITE)])]))
    return finish(xml, sh)


def notes_xml(tpl, text):
    body = "".join(f'<a:p><a:r><a:rPr lang="ko-KR" dirty="0"/><a:t>{escape(line)}</a:t></a:r></a:p>'
                   for line in text.split("\n")) if text else '<a:p><a:endParaRPr lang="ko-KR"/></a:p>'
    return re.sub(r'(<p:ph type="body" idx="1"/>.*?<a:lstStyle/>).*?(</p:txBody>)',
                  lambda m: m.group(1) + body + m.group(2), tpl, count=1, flags=re.S)


# ---------- 조립 ----------
def build(data, out_path, extras=False):
    steps = with_times(data["event"], data["program"])
    tmp = Path(tempfile.mkdtemp())
    with zipfile.ZipFile(TEMPLATE) as z:
        z.extractall(tmp)
    sd, nd = tmp / "ppt" / "slides", tmp / "ppt" / "notesSlides"
    read = lambda p: p.read_text(encoding="utf-8")
    t_cover, t_step, t_end = read(sd / "slide1.xml"), read(sd / "slide2.xml"), read(sd / "slide8.xml")
    r_cover, r_step, r_end = (read(sd / "_rels" / f"slide{i}.xml.rels") for i in (1, 2, 8))
    t_notes = read(nd / "notesSlide2.xml")
    r_notes = read(nd / "_rels" / "notesSlide2.xml.rels")

    # (장표 xml, 장표 rels 견본, 노트)
    plan = [(cover_xml(t_cover, data), r_cover, "참석자 입장 시 띄워 두는 표지")]
    if extras:
        plan.append((order_xml(t_step, steps), r_step, "전체 진행 순서 안내"))
    for st in steps:
        note = (st.get("script") or "") + f'\n(진행: {st["lead"]} / {st["start"]}~{st["end"]}, {st["minutes"]}분)'
        plan.append((step_xml(t_step, st), r_step, note.strip()))
        if extras and st.get("type") == "attendees":
            plan.append((attendees_xml(t_step, data), r_step, "참석자 소개 순서는 카드 오른쪽 위 번호를 따른다."))
        if extras and st.get("type") == "discussion":
            plan.append((discussion_xml(t_step, data, st), r_step, "발언 순서는 참석 명단 순서를 따른다."))
    plan.append((t_end, r_end, "마무리 장표"))

    # 견본 장표·노트 지우고 새로 쓰기
    for p in list(sd.glob("slide*.xml")) + list((sd / "_rels").glob("*.rels")) + \
            list(nd.glob("notesSlide*.xml")) + list((nd / "_rels").glob("*.rels")):
        p.unlink()
    for i, (xml, rels, note) in enumerate(plan, 1):
        (sd / f"slide{i}.xml").write_text(xml, encoding="utf-8")
        rels = re.sub(r'Target="\.\./notesSlides/notesSlide\d+\.xml"', f'Target="../notesSlides/notesSlide{i}.xml"', rels)
        (sd / "_rels" / f"slide{i}.xml.rels").write_text(rels, encoding="utf-8")
        (nd / f"notesSlide{i}.xml").write_text(notes_xml(t_notes, note), encoding="utf-8")
        (nd / "_rels" / f"notesSlide{i}.xml.rels").write_text(
            re.sub(r'Target="\.\./slides/slide\d+\.xml"', f'Target="../slides/slide{i}.xml"', r_notes), encoding="utf-8")

    # presentation.xml(.rels): 장표 목록 다시 쓰기
    pr_path = tmp / "ppt" / "_rels" / "presentation.xml.rels"
    pr = re.sub(rf'<Relationship [^>]*Type="{REL_SLIDE}"[^>]*/>', "", read(pr_path))
    entries, ids = [], []
    for i in range(1, len(plan) + 1):
        rid = f"rIdS{i}"
        entries.append(f'<Relationship Id="{rid}" Type="{REL_SLIDE}" Target="slides/slide{i}.xml"/>')
        ids.append(f'<p:sldId id="{300 + i}" r:id="{rid}"/>')
    pr_path.write_text(pr.replace("</Relationships>", "".join(entries) + "</Relationships>"), encoding="utf-8")
    p_path = tmp / "ppt" / "presentation.xml"
    p_path.write_text(re.sub(r"<p:sldIdLst>.*?</p:sldIdLst>", f'<p:sldIdLst>{"".join(ids)}</p:sldIdLst>', read(p_path), flags=re.S),
                      encoding="utf-8")

    # [Content_Types].xml
    ct_path = tmp / "[Content_Types].xml"
    ct = re.sub(r'<Override PartName="/ppt/(slides/slide|notesSlides/notesSlide)\d+\.xml"[^>]*/>', "", read(ct_path))
    add = "".join(f'<Override PartName="/ppt/slides/slide{i}.xml" ContentType="{CT_SLIDE}"/>'
                  f'<Override PartName="/ppt/notesSlides/notesSlide{i}.xml" ContentType="{CT_NOTES}"/>'
                  for i in range(1, len(plan) + 1))
    ct_path.write_text(ct.replace("</Types>", add + "</Types>"), encoding="utf-8")

    # docProps/app.xml 장수
    app = tmp / "docProps" / "app.xml"
    if app.exists():
        a = re.sub(r"<Slides>\d+</Slides>", f"<Slides>{len(plan)}</Slides>", read(app))
        app.write_text(re.sub(r"<Notes>\d+</Notes>", f"<Notes>{len(plan)}</Notes>", a), encoding="utf-8")

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(ct_path, "[Content_Types].xml")
        for f in sorted(tmp.rglob("*")):
            if f.is_file() and f != ct_path:
                z.write(f, f.relative_to(tmp).as_posix())
    shutil.rmtree(tmp, ignore_errors=True)
    total = sum(s["minutes"] for s in steps)
    print(f"생성: {out_path}\n장표 {len(plan)}장, 식순 {len(steps)}개, {data['event']['start']}~{steps[-1]['end']} (총 {total}분)")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) != 2:
        sys.exit("사용법: python scripts/build_ppt.py <행사데이터.json> <출력.pptx> [--extras]")
    build(json.loads(Path(args[0]).read_text(encoding="utf-8")), args[1], extras="--extras" in sys.argv)
