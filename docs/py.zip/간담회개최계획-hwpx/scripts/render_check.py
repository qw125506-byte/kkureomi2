#!/usr/bin/env python3
"""한글(한컴오피스)로 HWPX 를 실제로 열어 보고 쪽 그림을 만든다. (Windows + 한글 설치 환경 전용)

사용법:
    python render_check.py 결과.hwpx 그림폴더 [--set-preview]

  - 한글 COM(HWPFrame.HwpObject)으로 파일을 열고 쪽 수를 센 뒤 PDF 로 저장,
    PDF 를 쪽별 PNG(p01.png …)로 바꾼다(pymupdf 필요).
  - --set-preview: 1쪽 그림으로 파일 안의 미리보기(Preview/PrvImage.png)를 바꾼다.
  - 한글이 없거나 Windows 가 아니면 "실제 한글 열기 확인 못 함"을 알리고 종료 코드 3.
종료 코드 0 = 한글에서 열림, 1 = 열기 실패, 3 = 확인 불가 환경.
"""
import os
import shutil
import sys
import tempfile
import zipfile


def set_preview(hwpx, png):
    tmp = hwpx + ".tmp"
    with zipfile.ZipFile(hwpx) as zin, zipfile.ZipFile(tmp, "w") as zout:
        for info in zin.infolist():
            data = open(png, "rb").read() if info.filename == "Preview/PrvImage.png" else zin.read(info.filename)
            zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            zi.compress_type = zipfile.ZIP_STORED if info.filename == "mimetype" else zipfile.ZIP_DEFLATED
            zout.writestr(zi, data)
    os.replace(tmp, hwpx)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    src, outdir = os.path.abspath(argv[0]), os.path.abspath(argv[1])
    if os.name != "nt":
        print("[확인 불가] Windows 가 아니어서 실제 한글 열기 확인을 하지 못했습니다.")
        return 3
    try:
        import win32com.client as win32  # type: ignore
    except ImportError:
        print("[확인 불가] pywin32 가 없어 한글을 부를 수 없습니다 (pip install pywin32).")
        return 3
    try:
        hwp = win32.gencache.EnsureDispatch("HWPFrame.HwpObject")
    except Exception as e:  # noqa
        print("[확인 불가] 한글(한컴오피스)이 설치돼 있지 않거나 COM 을 부를 수 없습니다: %s" % e)
        return 3
    os.makedirs(outdir, exist_ok=True)
    # 원본 경로에 한글이 잠금을 걸지 않도록 임시 복사본을 연다
    work = os.path.join(tempfile.mkdtemp(), "check.hwpx")
    shutil.copyfile(src, work)
    pdf = os.path.join(outdir, "preview.pdf")
    try:
        try:
            hwp.RegisterModule("FilePathCheckDLL", "FilePathCheckerModule")
        except Exception:
            pass
        hwp.XHwpWindows.Item(0).Visible = False
        hwp.SetMessageBoxMode(0x00020021)
        ok = hwp.Open(work, "HWPX", "forceopen:true")
        if not ok:
            print("[실패] 한글이 파일을 열지 못했습니다.")
            return 1
        pages = hwp.PageCount
        hwp.SaveAs(pdf, "PDF", "")
        print("[통과] 한글에서 열림: %d쪽" % pages)
    finally:
        try:
            hwp.Clear(1)
            hwp.Quit()
        except Exception:
            pass
    try:
        import pymupdf as fitz  # type: ignore
    except ImportError:
        try:
            import fitz  # type: ignore
        except ImportError:
            print("[주의] pymupdf 가 없어 PDF 만 만들었습니다: %s" % pdf)
            return 0
    doc = fitz.open(pdf)
    for i, page in enumerate(doc):
        page.get_pixmap(dpi=80).save(os.path.join(outdir, "p%02d.png" % (i + 1)))
    print("  쪽 그림 %d장: %s" % (len(doc), outdir))
    if "--set-preview" in argv and len(doc):
        thumb = os.path.join(outdir, "_thumb.png")
        doc[0].get_pixmap(dpi=30).save(thumb)
        doc.close()
        set_preview(src, thumb)
        os.remove(thumb)
        print("  미리보기 그림을 새 표지로 바꿨습니다.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
