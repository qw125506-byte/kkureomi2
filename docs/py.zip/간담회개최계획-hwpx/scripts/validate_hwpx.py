#!/usr/bin/env python3
"""HWPX 파일이 한글에서 정상적으로 열릴 수 있는 구조인지 검사한다.

사용법:
    python validate_hwpx.py 결과.hwpx [--template 양식.hwpx] [--content content.xml]

검사 항목
  [구조]  ZIP 무결성, mimetype 첫 항목·무압축·내용, 필수 파일, 매니페스트에 적힌 파일 존재
  [XML]   모든 .xml/.hpf/.rdf 파일 문법
  [참조]  본문의 charPr/paraPr/style/borderFill ID가 header.xml에 실제로 있는지, itemCnt 일치
  [표]    rowCnt/colCnt 와 실제 행·칸 일치, 칸 위치(cellAddr) 겹침·빈칸 없음
  [본문]  {{…}} 표시가 남지 않았는지, 문단 id 중복
  [원본]  (--template) 글꼴·크기·색·줄간격·테두리 정의(header.xml), 용지·여백(secPr),
          표마다 원본 표의 열 수·너비·테두리를 쓰는지, 로고·아이콘 그림이 그대로인지
  [내용]  (--content) content.xml 의 모든 글이 문서에 들어갔는지
  [재열기] python-hwpx 가 설치돼 있으면 독립 파서로 다시 열어 봄
종료 코드 0 = 통과, 1 = 실패.
"""
import re
import sys
import zipfile
from collections import Counter

from lxml import etree

HP = "http://www.hancom.co.kr/hwpml/2011/paragraph"
HH = "http://www.hancom.co.kr/hwpml/2011/head"
N = {"hp": HP, "hh": HH}
REQUIRED = ["mimetype", "version.xml", "META-INF/container.xml", "Contents/content.hpf", "Contents/header.xml"]


class Report:
    def __init__(self):
        self.errors, self.warns, self.oks = [], [], []

    def ok(self, m):
        self.oks.append(m)

    def err(self, m):
        self.errors.append(m)

    def warn(self, m):
        self.warns.append(m)


def own_text(p):
    out = []
    for run in p.findall("hp:run", N):
        for t in run.findall("hp:t", N):
            out.append(t.text or "")
            for c in t:
                out.append(c.tail or "")
    return "".join(out)


def check_package(z, r):
    bad = z.testzip()
    if bad:
        r.err("ZIP 손상: %s" % bad)
        return False
    infos = z.infolist()
    names = [i.filename for i in infos]
    if not infos or infos[0].filename != "mimetype":
        r.err("mimetype 이 ZIP의 첫 항목이 아닙니다.")
    else:
        if infos[0].compress_type != zipfile.ZIP_STORED:
            r.err("mimetype 이 압축돼 있습니다(무압축이어야 함).")
        if z.read("mimetype") != b"application/hwp+zip":
            r.err("mimetype 내용이 application/hwp+zip 이 아닙니다.")
    for f in REQUIRED:
        if f not in names:
            r.err("필수 파일 없음: %s" % f)
    dup = [n for n, c in Counter(names).items() if c > 1]
    if dup:
        r.err("ZIP 안에 같은 이름의 파일이 중복됨: %s" % dup)
    if not r.errors:
        r.ok("구조: ZIP·mimetype·필수 파일 정상")
    return True


def parse_all(z, r):
    docs = {}
    for n in z.namelist():
        if n.endswith((".xml", ".hpf", ".rdf")):
            try:
                docs[n] = etree.fromstring(z.read(n), etree.XMLParser(huge_tree=True))
            except etree.XMLSyntaxError as e:
                r.err("XML 문법 오류: %s (%s)" % (n, e))
    hpf = docs.get("Contents/content.hpf")
    sections = []
    if hpf is not None:
        for item in hpf.iter("{http://www.idpf.org/2007/opf/}item"):
            href = item.get("href")
            if href and href not in z.namelist():
                r.err("content.hpf 에 적힌 파일이 없음: %s" % href)
            if href and re.fullmatch(r"Contents/section\d+\.xml", href):
                sections.append(href)
    if not sections:
        sections = sorted(n for n in z.namelist() if re.fullmatch(r"Contents/section\d+\.xml", n))
    if not sections:
        r.err("본문(section*.xml)이 없습니다.")
    if not any(m.startswith("XML") for m in r.errors):
        r.ok("XML: %d개 파일 문법 정상" % len(docs))
    return docs, sections


def header_ids(header):
    ids = {}
    for group, child in [("charProperties", "charPr"), ("paraProperties", "paraPr"), ("styles", "style"), ("borderFills", "borderFill")]:
        g = header.find(".//hh:%s" % group, N)
        els = g.findall("hh:%s" % child, N) if g is not None else []
        ids[child] = {e.get("id") for e in els}
        if g is not None and g.get("itemCnt") and int(g.get("itemCnt")) != len(els):
            yield ("err", "header.xml %s itemCnt(%s) ≠ 실제 개수(%d)" % (group, g.get("itemCnt"), len(els)))
    yield ("ids", ids)


def check_refs(docs, sections, r):
    header = docs.get("Contents/header.xml")
    if header is None:
        return
    ids = {}
    for kind, val in header_ids(header):
        if kind == "err":
            r.err(val)
        else:
            ids = val
    # 스타일이 가리키는 글자/문단 모양
    for st in header.iter("{%s}style" % HH):
        for attr, k in [("paraPrIDRef", "paraPr"), ("charPrIDRef", "charPr")]:
            v = st.get(attr)
            if v is not None and v not in ids[k]:
                r.err("스타일 '%s'의 %s=%s 가 header.xml 에 없음" % (st.get("name"), attr, v))
    attr_map = {"charPrIDRef": "charPr", "paraPrIDRef": "paraPr", "styleIDRef": "style", "borderFillIDRef": "borderFill"}
    bad = Counter()
    for sec in sections:
        root = docs.get(sec)
        if root is None:
            continue
        for el in root.iter():
            for attr, k in attr_map.items():
                v = el.get(attr)
                if v is not None and v not in ids.get(k, set()):
                    bad["%s=%s" % (attr, v)] += 1
    if bad:
        r.err("header.xml 에 없는 서식 참조: %s" % dict(bad))
    else:
        r.ok("참조: 본문의 서식 ID가 모두 header.xml 에 존재")


def check_tables(docs, sections, r):
    n_tbl = 0
    for sec in sections:
        root = docs.get(sec)
        if root is None:
            continue
        for tbl in root.iter("{%s}tbl" % HP):
            n_tbl += 1
            rows = tbl.findall("hp:tr", N)
            rc, cc = int(tbl.get("rowCnt", "0")), int(tbl.get("colCnt", "0"))
            tag = "표 #%d" % n_tbl
            if rc != len(rows):
                r.err("%s: rowCnt=%d 인데 실제 행은 %d" % (tag, rc, len(rows)))
            grid = {}
            for tr in rows:
                for tc in tr.findall("hp:tc", N):
                    a, s = tc.find("hp:cellAddr", N), tc.find("hp:cellSpan", N)
                    if a is None or s is None:
                        r.err("%s: cellAddr/cellSpan 누락" % tag)
                        continue
                    c0, r0 = int(a.get("colAddr")), int(a.get("rowAddr"))
                    cs, rs = int(s.get("colSpan", "1")), int(s.get("rowSpan", "1"))
                    for rr in range(r0, r0 + rs):
                        for c in range(c0, c0 + cs):
                            if (rr, c) in grid:
                                r.err("%s: 칸 (%d,%d) 이 겹침" % (tag, rr, c))
                            grid[(rr, c)] = True
                            if c >= cc or rr >= rc:
                                r.err("%s: 칸 (%d,%d) 이 표 범위(%dx%d) 밖" % (tag, rr, c, rc, cc))
            missing = [(rr, c) for rr in range(rc) for c in range(cc) if (rr, c) not in grid]
            if missing:
                r.err("%s: 비어 있는 칸 위치 %s" % (tag, missing[:5]))
    if not any(e.startswith("표") for e in r.errors):
        r.ok("표: %d개 표의 행·열·칸 위치 정상" % n_tbl)
    return n_tbl


def check_body(docs, sections, r):
    lines, pids = [], Counter()
    for sec in sections:
        root = docs.get(sec)
        if root is None:
            continue
        for p in root.iter("{%s}p" % HP):
            if p.get("id") not in (None, "", "0"):
                pids[p.get("id")] += 1
            t = own_text(p)
            if t.strip():
                lines.append(t)
    left = [m for t in lines for m in re.findall(r"\{\{[^{}]*\}\}", t)]
    if any("\n" in t for t in lines):
        r.err("글자 칸(hp:t) 안에 줄바꿈 문자가 있습니다 — 문단을 나눠야 합니다")
    if left:
        r.err("채워지지 않은 표시가 남음: %s" % left[:5])
    dup = [k for k, c in pids.items() if c > 1]
    if dup:
        r.warn("문단 id 중복 %d건 (한글은 대개 허용하지만 확인 권장)" % len(dup))
    if not lines:
        r.err("본문에 글자가 하나도 없습니다.")
    elif not left:
        r.ok("본문: 글 있는 문단 %d개, 남은 표시 없음" % len(lines))
    return lines


def table_signature(root):
    sig = []
    for tbl in root.iter("{%s}tbl" % HP):
        widths = []
        first = tbl.find("hp:tr", N)
        if first is not None:
            widths = [tc.find("hp:cellSz", N).get("width") for tc in first.findall("hp:tc", N)]
        bfs = sorted({tc.get("borderFillIDRef") for tc in tbl.iter("{%s}tc" % HP)})
        sig.append((tbl.get("colCnt"), tbl.get("borderFillIDRef"), tuple(widths), tuple(bfs)))
    return sig


def _strip_img(xml_bytes):
    """본문에서 안 쓰는 그림 채우기(원본 행사 사진)를 뺀 header 는 같은 서식으로 본다."""
    root = etree.fromstring(xml_bytes)
    for ib in root.iter("{http://www.hancom.co.kr/hwpml/2011/core}imgBrush"):
        fb = ib.getparent()
        fb.remove(ib)
        if len(fb) == 0:
            fb.getparent().remove(fb)
    return etree.tostring(root, method="c14n")


def check_template(z, docs, sections, tpl_path, r):
    t = zipfile.ZipFile(tpl_path)
    if _strip_img(t.read("Contents/header.xml")) != _strip_img(z.read("Contents/header.xml")):
        r.err("header.xml(글꼴·크기·색·줄간격·문단모양·테두리 정의)이 원본과 다릅니다")
    else:
        r.ok("원본 보존: 글꼴·크기·색·줄간격·문단모양·테두리 정의 동일")
    for n in ["settings.xml", "version.xml", "META-INF/container.xml"]:
        if n in t.namelist() and n in z.namelist() and t.read(n) != z.read(n):
            r.warn("%s 가 원본과 다릅니다" % n)
    tsig, osig = set(), []
    for sec in sections:
        if sec in t.namelist():
            tsig |= set(table_signature(etree.fromstring(t.read(sec))))
        if docs.get(sec) is not None:
            osig += table_signature(docs[sec])
    # 행 수·병합·(붙임 현황 표의) 열 수는 내용에 따라 달라지므로, 표마다
    # 원본 어느 표와 바깥 테두리·전체 너비가 같고 칸 테두리·배경이 그 표의 것만 쓰는지 본다
    def same_table(g, t):
        if g[1] != t[1] or set(g[3]) - set(t[3]):
            return False
        if g[:3] == t[:3]:
            return True
        tw = lambda x: sum(int(w) for w in x[2] if w)  # noqa: E731
        return int(g[0]) <= int(t[0]) and abs(tw(g) - tw(t)) <= int(g[0])
    bad = [g for g in osig if not any(same_table(g, t) for t in tsig)]
    if bad:
        r.err("원본에 없는 표 모양 %d개: %s" % (len(bad), bad[:3]))
    else:
        r.ok("원본 보존: 표 %d개 모두 원본 표의 너비·테두리·칸 모양 사용" % len(osig))
    used = set()
    for sec in sections:
        if docs.get(sec) is not None:
            used |= {tc.get("borderFillIDRef") for tc in docs[sec].iter("{%s}tc" % HP)}
    allbf = set()
    for sec in sections:
        if sec in t.namelist():
            allbf |= {tc.get("borderFillIDRef") for tc in etree.fromstring(t.read(sec)).iter("{%s}tc" % HP)}
    if used - allbf:
        r.err("원본에 없는 칸 테두리·배경 사용: %s" % sorted(used - allbf))

    def secpr(root):
        s = root.find(".//hp:secPr", N)
        return etree.tostring(s) if s is not None else b""
    if sections and sections[0] in t.namelist():
        if secpr(etree.fromstring(t.read(sections[0]))) != secpr(docs[sections[0]]):
            r.err("용지·여백 설정(secPr)이 원본과 다릅니다")
        else:
            r.ok("원본 보존: 용지·여백·쪽 설정(secPr) 동일")
    tb = {n for n in t.namelist() if n.startswith("BinData/")}
    ob = {n for n in z.namelist() if n.startswith("BinData/")}
    if ob - tb:
        r.warn("원본에 없던 그림 파일: %s" % sorted(ob - tb))
    sec_xml = b"".join(z.read(s) for s in sections)
    logos = sorted(set(re.findall(rb'binaryItemIDRef="([^"]+)"', sec_xml)))
    tpl_logos = sorted(set(re.findall(rb'binaryItemIDRef="([^"]+)"', b"".join(t.read(s) for s in sections if s in t.namelist()))))
    if logos != tpl_logos:
        r.err("로고·아이콘 그림 참조가 원본과 다릅니다: %s / 원본 %s" % (logos, tpl_logos))
    else:
        r.ok("원본 보존: 로고·아이콘 그림 %d개 유지" % len(logos))


def check_content(lines, content_path, r):
    root = etree.parse(content_path, etree.XMLParser(remove_comments=True)).getroot()
    body = re.sub(r"\s+", "", "".join(lines))
    miss = []
    for el in root.iter():
        if len(el) == 0 and (el.text or "").strip():
            for ln in el.text.split("\n"):
                if re.sub(r"\s+", "", ln) and re.sub(r"\s+", "", ln) not in body:
                    miss.append("%s: %s" % (el.tag, ln.strip()[:30]))
    if miss:
        r.err("문서에 들어가지 않은 내용 %d건: %s" % (len(miss), miss[:5]))
    else:
        r.ok("내용: content.xml 의 모든 글이 문서에 들어감")


def check_reopen(path, r):
    try:
        from hwpx.document import HwpxDocument  # type: ignore
    except Exception:
        r.warn("python-hwpx 미설치 — 독립 파서 재열기 생략 (pip install python-hwpx)")
        return
    try:
        d = HwpxDocument.open(path)
        n = len(d.paragraphs)
        r.ok("재열기: python-hwpx 로 다시 열림 (문단 %d개)" % n)
    except Exception as e:  # noqa
        r.err("재열기 실패(python-hwpx): %s" % e)
        return
    # 공식 OWPML(KS X 6101) 스키마 검사 + 한글 편집기 열기 안전성 검사
    try:
        from hwpx.tools.validator import validate_document  # type: ignore
        v = validate_document(path)
        if getattr(v, "ok", False):
            r.ok("표준: OWPML(KS X 6101) 스키마 검사 통과")
        else:
            r.err("OWPML 스키마 위반: %s" % [str(i)[:150] for i in getattr(v, "issues", [])][:5])
    except Exception as e:  # noqa
        r.warn("OWPML 스키마 검사 생략: %s" % e)
    try:
        from hwpx.tools.package_validator import validate_editor_open_safety  # type: ignore
        s = validate_editor_open_safety(path)
        if s.ok:
            r.ok("편집기: 한글에서 열기를 막는 패키지 문제 없음")
        else:
            r.err("한글 열기 차단 요인: %s" % (s.summary if hasattr(s, "summary") else s.to_dict()))
    except Exception as e:  # noqa
        r.warn("편집기 열기 안전성 검사 생략: %s" % e)


def main(argv):
    args, opts, i = [], {}, 0
    while i < len(argv):
        if argv[i] in ("--template", "--content"):
            opts[argv[i][2:]] = argv[i + 1]
            i += 2
        else:
            args.append(argv[i])
            i += 1
    if len(args) != 1:
        print(__doc__)
        return 2
    path = args[0]
    r = Report()
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        print("[실패] ZIP(HWPX) 파일로 열리지 않습니다: %s" % path)
        return 1
    if check_package(z, r):
        docs, sections = parse_all(z, r)
        if not r.errors:
            check_refs(docs, sections, r)
            check_tables(docs, sections, r)
            lines = check_body(docs, sections, r)
            if "template" in opts:
                check_template(z, docs, sections, opts["template"], r)
            if "content" in opts:
                check_content(lines, opts["content"], r)
            check_reopen(path, r)
    for m in r.oks:
        print("  [통과] " + m)
    for m in r.warns:
        print("  [주의] " + m)
    for m in r.errors:
        print("  [실패] " + m)
    print("결과: %s (실패 %d, 주의 %d)" % ("통과" if not r.errors else "실패", len(r.errors), len(r.warns)))
    return 0 if not r.errors else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
