# -*- coding: utf-8 -*-
"""브라우저판(GitHub Pages) 입구 — Pyodide 안에서 server/app.py 대신 부른다.

서버 없이 방문자 브라우저 안에서 core.service 를 그대로 돌린다(입력·문서가 밖으로 나가지 않음).
JS(web/src/pyapi.js)가 올린 파일을 /tmp/kk/up/ 에 써 두고 아래 함수를 부른 뒤,
돌려받은 경로의 파일을 브라우저 메모리에서 읽어 내려받기 링크로 만든다.
모든 함수는 JSON 문자열을 받고 JSON 문자열을 돌려준다(오류는 {"error", "status"}).
"""
import json
import shutil
import traceback
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = Path("/tmp/kk")
EXAMPLES = {"청년창업": ROOT / "examples" / "청년창업_간담회.json"}
EXAMPLE_MINUTES = {"청년창업": ROOT / "examples" / "청년창업_회의록.txt"}


def _no_pdf():
    """브라우저판은 PDF를 못 읽는다 — 안내 문구에서 pdf를 뺀다"""
    try:
        from core import service
        service.PDF_OK = False
    except Exception:  # noqa: BLE001
        pass


_no_pdf()


def _call(fn):
    try:
        return json.dumps(fn(), ensure_ascii=False)
    except Exception as e:  # noqa: BLE001 — 화면에 그대로 알림
        from core.service import ServiceError
        if isinstance(e, ServiceError):
            return json.dumps({"error": e.message, "status": e.status}, ensure_ascii=False)
        return json.dumps({"error": f"처리 중 오류: {e}", "status": 500, "trace": traceback.format_exc()[-800:]},
                          ensure_ascii=False)


def _job():
    d = WORK / "jobs" / uuid.uuid4().hex[:12]
    d.mkdir(parents=True, exist_ok=True)
    return d


def health():
    from core import validate
    return _call(lambda: {"ok": True, "mode": "browser", "docs": validate.DOC_NAMES})


def example(name):
    from core.service import ServiceError, example_data

    def go():
        if name not in EXAMPLES:
            raise ServiceError(404, "예시가 없습니다")
        return example_data(EXAMPLES[name])
    return _call(go)


def generate(payload_json):
    from core import service

    def go():
        p = json.loads(payload_json)
        return service.run_generate(p.get("data") or {}, p.get("docs"), _job(), p.get("extras"), p.get("minutes"))
    return _call(go)


def result(names_json, data_json, photos_json="[]"):
    """names: /tmp/kk/up/ 아래에 JS가 써 둔 파일 경로들, photos: 붙임 3에 넣을 사진 경로들"""
    from core import service

    def go():
        paths = [Path(x) for x in json.loads(names_json)]
        for q in paths:
            service.check_upload(q.name, q.read_bytes(), "계획서·회의록")
        try:
            form = json.loads(data_json or "{}")
        except ValueError:
            form = {}
        try:
            photos = [Path(x) for x in json.loads(photos_json or "[]")]
            return service.run_result(paths, form, _job(), photos)
        finally:
            shutil.rmtree(WORK / "up", ignore_errors=True)
    return _call(go)


def extract(names_json):
    from ai.extract import extract_event
    from core import service

    def go():
        paths = [Path(x) for x in json.loads(names_json)]
        for q in paths:
            service.check_upload(q.name, q.read_bytes(), "파일")
        try:
            draft = extract_event(paths, use_ai=False)
        except ImportError:
            raise service.ServiceError(400, "이 화면에서는 PDF를 읽을 수 없습니다 — txt·hwpx 파일로 올려 주세요")
        except Exception as e:  # noqa: BLE001
            raise service.ServiceError(422, f"파일을 읽지 못했습니다: {e}")
        finally:
            shutil.rmtree(WORK / "up", ignore_errors=True)
        return {"ok": True, "mode": draft["_meta"]["방식"], "draft": draft}
    return _call(go)


def example_file(name, kind):
    """예시 개최계획서(예시 데이터로 만든 hwpx)·회의록 경로"""
    import bundle
    from core.data import load_event
    from core.service import ServiceError

    def go():
        if name not in EXAMPLES or kind not in ("plan", "minutes"):
            raise ServiceError(404, "예시 파일이 없습니다")
        if kind == "minutes":
            return {"path": str(EXAMPLE_MINUTES[name])}
        out = WORK / "example" / name
        plan = next(out.glob("①*.hwpx"), None) if out.exists() else None
        if not plan:
            files, _, _ = bundle.build_bundle(load_event(EXAMPLES[name]), out, ["plan"], False)
            plan = files["plan"]
        return {"path": str(plan)}
    return _call(go)


def preview(path):
    from core.service import preview_html
    return _call(lambda: {"html": preview_html(path)})
