# -*- coding: utf-8 -*-
"""증빙용 비식별 데이터 만들기 — 사람 이름을 「장○○」꼴로 바꾸고 내선번호는 뺀다.

    python scripts/anonymize.py examples/대학총장_간담회.json examples/대학총장_간담회_비식별.json

성씨는 남기고 이름만 가린다(문서 모양은 그대로, 누구인지는 알 수 없게). 띄어 쓴 이름(「홍 길 동」)도 바꾼다.
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from ai.mask import known_names  # noqa: E402


def masked(name):
    return name[0] + "○" * (len(name) - 1)


def anonymize(data):
    text = json.dumps(data, ensure_ascii=False)
    for n in sorted(known_names(data), key=len, reverse=True):
        text = text.replace(n, masked(n)).replace(" ".join(n), " ".join(masked(n)))
    out = json.loads(text)
    for s in (out.get("org") or {}).get("staff") or []:
        s.pop("tel", None)                # 내선번호는 뺀다(「0000」을 넣으면 칸이 넘쳐 표지 배치가 바뀜)
    out.setdefault("_meta", {})["비식별"] = "증빙용: 사람 이름은 성만 남기고 가림, 내선번호 뺌"
    return out


def leftover(original, anon):
    """비식별본에 원래 이름이 남았는지 — 남은 이름 목록"""
    t = json.dumps(anon, ensure_ascii=False)
    return [n for n in known_names(original) if n in t or " ".join(n) in t]


if __name__ == "__main__":
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    data = json.loads(src.read_text(encoding="utf-8"))
    anon = anonymize(data)
    left = leftover(data, anon)
    dst.write_text(json.dumps(anon, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[완료] {dst} — 가린 이름 {len(known_names(data))}명, 남은 이름 {left or '없음'}")
    sys.exit(1 if left else 0)
