# -*- coding: utf-8 -*-
"""⑤ 진행 PPT — templates/ppt.pptx(사용자 견본 「(견본) 간담회 진행 PPT」)를 복제해 내용만 바꾼다.

견본 구성: 1 표지(남색 바탕·행사명·일시·장소·주최) / 2~7 식순 장표(큰 번호 + 식순 이름 + 아래 진행 막대) / 8 감사합니다.
- 표지: 행사명, 일시·장소·주최·주관을 데이터로 바꾼다. 글이 길면 크기를 줄이고 칸 폭을 글에 맞춘다.
- 식순 장표: 견본 3번 장표를 식순 수만큼 복제한다. 번호(01, 02 …)·제목·진행 막대(지난 식순 초록, 지금 식순 주황 큰 점,
  남은 식순 흰 점)를 식순 수에 맞게 다시 만든다.
- 감사합니다: 행사명만 바꾼다. 배경·로고·도형·글꼴은 견본 그대로.
- 시나리오 멘트(program[].script)는 각 장표의 발표자 노트로 들어간다.
"""
import copy
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from lxml import etree

from core.hwpx import TEMPLATES

NS = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "p": "http://schemas.openxmlformats.org/presentationml/2006/main"}
A, P_ = "{%s}" % NS["a"], "{%s}" % NS["p"]
REL_SLIDE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"
CT_SLIDE = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"
CT_NOTES = "application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"

LINE_X, LINE_W, LINE_Y = 1280160, 9628632, 5486400      # 진행 막대(견본 좌표)
BIG, SMALL = 310896, 182880                              # 지금 식순 점 / 그 밖의 점
LABEL_Y, LABEL_W, LABEL_H = 5742432, 1828800, 365760
FILLER = {"주요", "참석자", "관련"}                      # 진행 막대 이름에서 뺄 군더더기 낱말
REPLACE = {"기념촬영": "촬영"}


# ---------- 글자 ----------
def text_width(s, pt):
    """글자 폭 추정(EMU): 한글·기호 1em, 영문·숫자·공백 0.55em"""
    em = pt * 12700
    return int(sum(em if ord(c) > 0x2E7F else em * 0.55 for c in s))


def fit_size(text, box_w, size, floor):
    """한 줄에 들어가는 가장 큰 글자 크기(pt). 안 되면 floor"""
    while size > floor and text_width(text, size) > box_w:
        size -= 1
    return size


def short_label(item):
    """진행 막대 이름: 「개회 및 참석자 소개」→「개회·소개」, 「주요 사업 보고」→「사업보고」, 「폐회, 기념촬영」→「폐회·촬영」"""
    s = re.sub(r"\s*\([^)]*\)", "", item)
    s = re.sub(r"\s*등$", "", s).replace(" 및 ", "·").replace(", ", "·").replace(",", "·")
    parts = []
    for chunk in s.split("·"):
        words = [REPLACE.get(w, w) for w in chunk.split() if w not in FILLER] or chunk.split()
        parts.append("".join(words))
    out = "·".join(x for x in parts if x)
    if len(out) > 9:                                    # 너무 길면 마지막 두 낱말만(열린 토의 → 열린토의)
        words = [REPLACE.get(w, w) for w in re.sub(r"[·,]", " ", s).split()]
        out = "".join(words[-2:])
    return out or item


def title_text(item):
    """견본처럼 네 글자 안팎 붙여 쓴 이름은 글자 사이를 띄운다: 인사말씀 → 인 사 말 씀"""
    t = item.strip()
    return " ".join(t) if " " not in t and 3 <= len(t) <= 5 else t


# ---------- XML 도구 ----------
def parse(xml):
    return etree.fromstring(xml.encode("utf-8"))


def dump(root):
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True).decode("utf-8")


def shape(root, name):
    for sp in root.iter(P_ + "sp"):
        nv = sp.find("p:nvSpPr/p:cNvPr", NS)
        if nv is not None and nv.get("name") == name:
            return sp
    raise KeyError(f"견본 장표에 도형 「{name}」이 없습니다 — templates/ppt.pptx 가 바뀌었는지 확인")


def set_text(sp, text, size=None):
    """도형의 첫 글자 조각에 text를 넣고 나머지 조각은 지운다. size(pt)가 있으면 글자 크기도"""
    paras = sp.findall(".//a:p", NS)
    runs = paras[0].findall("a:r", NS)
    for extra in paras[1:]:
        extra.getparent().remove(extra)
    for r in runs[1:]:
        paras[0].remove(r)
    runs[0].find("a:t", NS).text = text
    if size:
        runs[0].find("a:rPr", NS).set("sz", str(int(size * 100)))
        end = paras[0].find("a:endParaRPr", NS)
        if end is not None:
            end.set("sz", str(int(size * 100)))


def set_box(sp, x=None, y=None, w=None, h=None):
    off, ext = sp.find(".//a:off", NS), sp.find(".//a:ext", NS)
    if x is not None:
        off.set("x", str(int(x)))
    if y is not None:
        off.set("y", str(int(y)))
    if w is not None:
        ext.set("cx", str(int(w)))
    if h is not None:
        ext.set("cy", str(int(h)))


def renumber_ids(root):
    for i, nv in enumerate(root.iter(P_ + "cNvPr"), 1):
        nv.set("id", str(i))


# ---------- 장표 ----------
def cover(tpl, data):
    root = parse(tpl)
    ev, org, d = data["event"], data["org"], data["derived"]
    t = shape(root, "Text 0")
    width = int(t.find(".//a:ext", NS).get("cx"))
    size = fit_size(ev["title"], width, 44, 32)
    m = re.match(r"^(\d{4})\s+(.+)$", ev["title"])           # 견본: 앞의 연도(2026)만 노란색, 나머지는 흰색
    head, tail = (m.group(1) + " ", m.group(2)) if m else ("", ev["title"])
    runs = t.findall(".//a:r", NS)
    runs[0].find("a:t", NS).text, runs[1].find("a:t", NS).text = head, tail
    for r in runs:
        r.find("a:rPr", NS).set("sz", str(size * 100))
    t.find(".//a:endParaRPr", NS).set("sz", str(size * 100))
    host = " ".join(x for x in (org.get("city"), org.get("dept")) if x)
    fields = [("일시", f'{d["date_text"]} {ev["start"]}'), ("장소", ev["venue"]), ("주최·주관", host)]
    fields = [(k, v) for k, v in fields if v]
    gap, left, room = 457200, 822960, 7200000                # 오른쪽 원 모양에 닿지 않게 7.2M EMU 안에
    fs = 18
    while fs > 14 and sum(text_width(v, fs) + 100000 for _, v in fields) + gap * (len(fields) - 1) > room:
        fs -= 1
    x = left
    for k, v in fields:
        w = max(text_width(v, fs) + 100000, text_width(k, 13) + 100000)
        for nm, txt, sz in (("label-" + k, k, None), ("value-" + k, v, fs)):
            sp = shape(root, nm)
            set_box(sp, x=x, w=w)
            set_text(sp, txt, sz)
        x += w + gap
    for k in ("일시", "장소", "주최·주관"):                    # 값이 없는 칸은 지운다
        if k not in dict(fields):
            for nm in ("label-" + k, "value-" + k):
                sp = shape(root, nm)
                sp.getparent().remove(sp)
    return dump(root)


def step_slide(tpl, steps, k):
    """식순 k(0부터) 장표: 번호·제목·진행 막대"""
    root = parse(tpl)
    n = len(steps)
    st = steps[k]
    set_text(shape(root, "step-number"), f"{k + 1:02d}")
    title = title_text(st["item"])
    box = shape(root, "Text 0")
    size = fit_size(title, int(box.find(".//a:ext", NS).get("cx")), 48, 32)
    set_text(box, title, size)

    # 진행 막대 본(견본: 지난 식순 / 지금 식순 / 남은 식순의 점과 이름)을 떼어 두고 모두 새로 만든다
    protos = {}
    for key, idx in (("done", 1), ("now", 2), ("next", 3)):
        protos[key] = (copy.deepcopy(shape(root, f"node-{idx}")), copy.deepcopy(shape(root, f"node-label-{idx}")))
    # 견본 3번 장표: node-1 지난, node-2 지금, node-3 남은 — 이 장표가 아닌 쪽에서 오면 아래에서 확인
    for sp in list(root.iter(P_ + "sp")):
        nm = sp.find("p:nvSpPr/p:cNvPr", NS).get("name")
        if re.match(r"node(-label)?-\d+$", nm):
            sp.getparent().remove(sp)
    tree = root.find(".//p:spTree", NS)
    step_x = LINE_W / (n - 1) if n > 1 else 0
    label_w = int(min(LABEL_W, step_x * 0.96)) if n > 1 else LABEL_W
    for i, s in enumerate(steps):
        kind = "done" if i < k else "now" if i == k else "next"
        node, label = (copy.deepcopy(x) for x in protos[kind])
        cx = LINE_X + (i * step_x if n > 1 else LINE_W / 2)
        size_pt = BIG if kind == "now" else SMALL
        set_box(node, x=cx - size_pt / 2, y=LINE_Y - size_pt / 2, w=size_pt, h=size_pt)
        node.find("p:nvSpPr/p:cNvPr", NS).set("name", f"node-{i + 1}")
        text = short_label(s["item"])
        cap = max(4, int(label_w / (13 * 12700)))
        lines = [text] if len(text) <= cap else [text[:(len(text) + 1) // 2], text[(len(text) + 1) // 2:]]
        set_text(label, lines[0], 13 if len(lines) == 1 else 11)
        if len(lines) == 2:                                       # 두 줄: 둘째 줄을 같은 서식의 문단으로 붙임
            para = label.find(".//a:p", NS)
            p2 = copy.deepcopy(para)
            p2.find("a:r/a:t", NS).text = lines[1]
            para.addnext(p2)
        set_box(label, x=cx - label_w / 2, y=LABEL_Y, w=label_w)
        label.find("p:nvSpPr/p:cNvPr", NS).set("name", f"node-label-{i + 1}")
        tree.append(node)
        tree.append(label)
    renumber_ids(root)
    return dump(root)


def closing(tpl, data):
    root = parse(tpl)
    sp = shape(root, "event-name")
    size = fit_size(data["event"]["title"], int(sp.find(".//a:ext", NS).get("cx")), 18, 14)
    set_text(sp, data["event"]["title"], size)
    return dump(root)


def notes_xml(tpl, text):
    body = "".join(f'<a:p><a:r><a:rPr lang="ko-KR" dirty="0"/><a:t>{escape(line)}</a:t></a:r></a:p>'
                   for line in text.split("\n")) if text else '<a:p><a:endParaRPr lang="ko-KR"/></a:p>'
    return re.sub(r'(<p:ph type="body" idx="1"/>.*?<a:lstStyle/>).*?(</p:txBody>)',
                  lambda m: m.group(1) + body + m.group(2), tpl, count=1, flags=re.S)


# ---------- 조립 ----------
def generate(data, out_path, extras=False):
    """extras: 이전 양식의 추가 장표(순서·참석자·발언 순서) 옵션 — 견본에 없는 장표라 쓰지 않는다(호환용 자리)."""
    steps = data["derived"]["program"]
    tmp = Path(tempfile.mkdtemp())
    with zipfile.ZipFile(TEMPLATES / "ppt.pptx") as z:
        z.extractall(tmp)
    sd, nd = tmp / "ppt" / "slides", tmp / "ppt" / "notesSlides"
    read = lambda p: p.read_text(encoding="utf-8")                              # noqa: E731
    t_cover, t_step, t_end = read(sd / "slide1.xml"), read(sd / "slide3.xml"), read(sd / "slide8.xml")
    r_cover, r_step, r_end = (read(sd / "_rels" / f"slide{i}.xml.rels") for i in (1, 3, 8))
    t_notes, r_notes = read(nd / "notesSlide3.xml"), read(nd / "_rels" / "notesSlide3.xml.rels")

    plan = [(cover(t_cover, data), r_cover, "참석자 입장 시 띄워 두는 표지입니다.")]
    for k, st in enumerate(steps):
        note = (st.get("script") or "") + f'\n(진행: {st["lead"]} / {st["start"]}~{st["end"]}, {st["minutes"]}분)'
        plan.append((step_slide(t_step, steps, k), r_step, note.strip()))
    plan.append((closing(t_end, data), r_end, "마무리 장표입니다."))

    for p in list(sd.glob("slide*.xml")) + list((sd / "_rels").glob("*.rels")) + \
            list(nd.glob("notesSlide*.xml")) + list((nd / "_rels").glob("*.rels")):
        p.unlink()
    for i, (xml, rels, note) in enumerate(plan, 1):
        (sd / f"slide{i}.xml").write_text(xml, encoding="utf-8")
        rels = re.sub(r'Target="\.\./notesSlides/notesSlide\d+\.xml"', f'Target="../notesSlides/notesSlide{i}.xml"', rels)
        (sd / "_rels" / f"slide{i}.xml.rels").write_text(rels, encoding="utf-8")
        (nd / f"notesSlide{i}.xml").write_text(notes_xml(t_notes, note), encoding="utf-8")
        (nd / "_rels" / f"notesSlide{i}.xml.rels").write_text(
            re.sub(r'Target="\.\./slides/slide\d+\.xml"', f'Target="../slides/slide{i}.xml"', r_notes), encoding="utf-8")

    pr_path = tmp / "ppt" / "_rels" / "presentation.xml.rels"
    pr = re.sub(rf'<Relationship [^>]*Type="{REL_SLIDE}"[^>]*/>', "", read(pr_path))
    entries = "".join(f'<Relationship Id="rIdS{i}" Type="{REL_SLIDE}" Target="slides/slide{i}.xml"/>' for i in range(1, len(plan) + 1))
    pr_path.write_text(pr.replace("</Relationships>", entries + "</Relationships>"), encoding="utf-8")
    ids = "".join(f'<p:sldId id="{300 + i}" r:id="rIdS{i}"/>' for i in range(1, len(plan) + 1))
    p_path = tmp / "ppt" / "presentation.xml"
    p_path.write_text(re.sub(r"<p:sldIdLst>.*?</p:sldIdLst>", f"<p:sldIdLst>{ids}</p:sldIdLst>", read(p_path), flags=re.S),
                      encoding="utf-8")

    ct_path = tmp / "[Content_Types].xml"
    ct = re.sub(r'<Override PartName="/ppt/(slides/slide|notesSlides/notesSlide)\d+\.xml"[^>]*/>', "", read(ct_path))
    add = "".join(f'<Override PartName="/ppt/slides/slide{i}.xml" ContentType="{CT_SLIDE}"/>'
                  f'<Override PartName="/ppt/notesSlides/notesSlide{i}.xml" ContentType="{CT_NOTES}"/>'
                  for i in range(1, len(plan) + 1))
    ct_path.write_text(ct.replace("</Types>", add + "</Types>"), encoding="utf-8")

    app = tmp / "docProps" / "app.xml"
    if app.exists():
        a = re.sub(r"<Slides>\d+</Slides>", f"<Slides>{len(plan)}</Slides>", read(app))
        app.write_text(re.sub(r"<Notes>\d+</Notes>", f"<Notes>{len(plan)}</Notes>", a), encoding="utf-8")

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(ct_path, "[Content_Types].xml")
        for f in sorted(tmp.rglob("*")):
            if f.is_file() and f != ct_path:
                z.write(f, f.relative_to(tmp).as_posix())
    shutil.rmtree(tmp, ignore_errors=True)
    return {"path": str(out_path), "warnings": [],
            "log": f'장표 {len(plan)}장, 식순 {len(steps)}개, {data["event"]["start"]}~{steps[-1]["end"]}'}


def read_text(path):
    """PPTX 장표 글자(검증용)"""
    out = []
    with zipfile.ZipFile(path) as z:
        names = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                       key=lambda n: int(re.findall(r"\d+", n)[0]))
        for n in names:
            x = z.read(n).decode("utf-8")
            for para in re.findall(r"<a:p>.*?</a:p>", x, flags=re.S):
                s = "".join(re.findall(r"<a:t>([^<]*)</a:t>", para))
                if s.strip():
                    out.append(s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"'))
    return out
