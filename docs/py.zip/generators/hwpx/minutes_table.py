# -*- coding: utf-8 -*-
"""회의록 정리 한글 파일 — templates/minutes_table.hwpx(사용자 정리본 「대학별_회의록_정리」의 표 양식: 머리 줄 + 빈 양식 행)를
복제해 행만 채운다. 표 모양(칸 폭·글자 9pt·위아래 가운데·정렬)·쪽 설정(세로, 여백)은 양식 그대로.
칸: 기관(대학명) · 직위 · 성명 · 발언내용 · 핵심요약 · 시장님답변 · 관련부서(한 줄에 한 부서)"""
import copy
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from lxml import etree

TEMPLATE = Path(__file__).resolve().parents[2] / "templates" / "minutes_table.hwpx"
HP = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"


def _cells(tr):
    return tr.findall(HP + "tc")


def _set_lines(tc, lines):
    sub = tc.find(HP + "subList")
    ps = sub.findall(HP + "p")
    base = copy.deepcopy(ps[0])
    for p in ps:
        sub.remove(p)
    for ls in base.findall(HP + "linesegarray"):
        base.remove(ls)
    runs = base.findall(HP + "run")
    for r in runs[1:]:
        base.remove(r)
    run = runs[0]
    for x in list(run):
        if x.tag == HP + "t":
            run.remove(x)
    for line in lines or [""]:
        p = copy.deepcopy(base)
        t = etree.SubElement(p.find(HP + "run"), HP + "t")
        t.text = line
        sub.append(p)


def generate(rows, out_path, subject="기관", title=""):
    """rows: [{org, position, name, say[], key[], answer[], depts[]}]"""
    z = zipfile.ZipFile(TEMPLATE)
    sec = etree.fromstring(z.read("Contents/section0.xml"))
    tbl = next(sec.iter(HP + "tbl"))
    head, proto = tbl.findall(HP + "tr")[:2]
    tbl.remove(proto)
    _set_lines(_cells(head)[0], ["대학명" if subject == "대학" else "기관명"])
    for i, r in enumerate(rows or [{}], 1):
        tr = copy.deepcopy(proto)
        vals = [[r.get("org", "")], [r.get("position", "")], [r.get("name", "")], r.get("say") or [""], r.get("key") or [""],
                r.get("answer") or [""], r.get("depts") or [""]]
        for c, (tc, ls) in enumerate(zip(_cells(tr), vals)):
            _set_lines(tc, ls)
            tc.find(HP + "cellAddr").set("rowAddr", str(i))
            tc.find(HP + "cellAddr").set("colAddr", str(c))
        tbl.append(tr)
    tbl.set("rowCnt", str(len(tbl.findall(HP + "tr"))))
    for p in sec.iter(HP + "p"):                                  # 줄 배치는 한글이 새로
        for ls in p.findall(HP + "linesegarray"):
            p.remove(ls)
    data = etree.tostring(sec, xml_declaration=True, encoding="UTF-8", standalone=True)
    out_path = Path(out_path)
    with zipfile.ZipFile(out_path, "w") as zo:
        for n in z.namelist():
            b = z.read(n)
            if n == "Contents/section0.xml":
                b = data
            elif n == "Preview/PrvText.txt":
                b = (title or "회의록 정리").encode("utf-8")
            elif n == "Contents/content.hpf":
                h = b.decode("utf-8")
                now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                import re
                h = re.sub(r'(<opf:meta name="ModifiedDate"[^>]*>)[^<]*', r"\g<1>" + now, h)
                b = h.encode("utf-8")
            zo.writestr(n, b, compress_type=zipfile.ZIP_STORED if n == "mimetype" else zipfile.ZIP_DEFLATED)
    return {"path": out_path}
