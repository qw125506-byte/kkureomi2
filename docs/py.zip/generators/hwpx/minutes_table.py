# -*- coding: utf-8 -*-
"""회의록 정리 한글 파일 — templates/minutes_table.hwpx(사용자 정리본 「대학별_회의록_정리」의 표 양식: 머리 줄 + 빈 양식 행)를
복제해 ① 제목 상자 ② 행사 개요 ③ 결과표를 차례로 담는다(PRD 「회의록 정리 기능」).
- 제목 상자: 1열 3행 표 — 위아래 파란 그러데이션 띠(#3057B9→#A0B4E6, #1F5794→#A0B4E6) 사이에 행사명(나눔스퀘어 ExtraBold 28pt)
- 행사 개요: 「❍ (일    시) …」 꼴(한컴산뜻돋움 13pt), 배석은 들여 쓴 10pt 줄(계획서에 있을 때만), 못 찾은 값은 「(확인 필요)」
- 결과표: 기관 · 직위 · 성명 · 발언내용 · 핵심요약 · 시장님답변 · 관련부서(한 줄에 한 부서). 표 모양·쪽 설정은 양식 그대로.
글꼴이 이 컴퓨터에 없으면 한글이 비슷한 글꼴로 바꿔 보여 준다(결과보고 양식과 같은 방식)."""
import copy
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from lxml import etree

TEMPLATE = Path(__file__).resolve().parents[2] / "templates" / "minutes_table.hwpx"
HP = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"
HH = "{http://www.hancom.co.kr/hwpml/2011/head}"
HC = "{http://www.hancom.co.kr/hwpml/2011/core}"
CHECK = "(확인 필요)"
TABLE_W = 51024
LANGS = ("hangul", "latin", "hanja", "japanese", "other", "symbol", "user")


def _cells(tr):
    return tr.findall(HP + "tc")


def _set_lines(tc, lines):
    sub = tc.find(HP + "subList")
    ps = sub.findall(HP + "p")
    base = copy.deepcopy(ps[0])
    for p in ps:
        sub.remove(p)
    for ls in base.findall(HP + "linesegarray"):
        base.remove(ls)
    runs = base.findall(HP + "run")
    for r in runs[1:]:
        base.remove(r)
    run = runs[0]
    for x in list(run):
        if x.tag == HP + "t":
            run.remove(x)
    for line in lines or [""]:
        p = copy.deepcopy(base)
        t = etree.SubElement(p.find(HP + "run"), HP + "t")
        t.text = line
        sub.append(p)


# ---------- header.xml 에 모양 더하기(새 번호) ----------
def _append(parent, el, count_attr="itemCnt"):
    el.set("id", str(max(int(x.get("id")) for x in parent) + 1))
    parent.append(el)
    parent.set(count_attr, str(len(parent)))
    return el.get("id")


def _font(head, face):
    """모든 언어 글꼴 목록에 face를 더하고 {언어: 번호}"""
    ids = {}
    for ff in head.iter(HH + "fontface"):
        have = [f for f in ff.findall(HH + "font") if f.get("face") == face]
        if have:
            ids[ff.get("lang").lower()] = have[0].get("id")
            continue
        f = copy.deepcopy(ff.findall(HH + "font")[0])
        f.set("face", face)
        for sub in list(f):
            if sub.tag != HH + "typeInfo":
                f.remove(sub)
        ids[ff.get("lang").lower()] = _append(ff, f, "fontCnt")
    return ids


def _char(head, base_id, height, face=None, bold=None, color=None):
    src = next(c for c in head.iter(HH + "charPr") if c.get("id") == base_id)
    c = copy.deepcopy(src)
    c.set("height", str(height))
    if color:
        c.set("textColor", color)
    if face:
        ids = _font(head, face)
        ref = c.find(HH + "fontRef")
        for lang in LANGS:
            if lang in ids:
                ref.set(lang, ids[lang])
    b = c.find(HH + "bold")
    if bold and b is None:
        etree.SubElement(c, HH + "bold")
    elif bold is False and b is not None:
        c.remove(b)
    return _append(src.getparent(), c)


def _para(head, base_id, align, left=0):
    src = next(p for p in head.iter(HH + "paraPr") if p.get("id") == base_id)
    p = copy.deepcopy(src)
    for al in p.iter(HH + "align"):
        al.set("horizontal", align)
    for m in p.iter(HH + "margin"):
        for v in m:
            name = v.tag.split("}")[-1]
            v.set("value", str(left) if name == "left" else "0")
    return _append(src.getparent(), p)


def _band_fill(head, c1, c2):
    """테두리 없이 왼쪽→오른쪽 그러데이션 채우기(c1 → c2) — 양식 머리 줄(남색 그러데이션) 칸 모양을 본뜬다"""
    src = next(b for b in head.iter(HH + "borderFill") if b.find(f"{HC}fillBrush/{HC}gradation") is not None)
    b = copy.deepcopy(src)
    for side in ("leftBorder", "rightBorder", "topBorder", "bottomBorder"):
        e = b.find(HH + side)
        if e is not None:
            e.set("type", "NONE")
    g = b.find(f"{HC}fillBrush/{HC}gradation")
    g.set("angle", "0")
    cs = g.findall(HC + "color")
    cs[0].set("value", c1)
    cs[1].set("value", c2)
    return _append(src.getparent(), b)


def _plain_fill(head):
    """테두리·채우기 없는 칸"""
    src = next(b for b in head.iter(HH + "borderFill") if b.find(HC + "fillBrush") is not None)
    b = copy.deepcopy(src)
    for side in ("leftBorder", "rightBorder", "topBorder", "bottomBorder"):
        e = b.find(HH + side)
        if e is not None:
            e.set("type", "NONE")
    b.remove(b.find(HC + "fillBrush"))
    return _append(src.getparent(), b)


# ---------- 본문 문단 ----------
def _p(para_id, char_id, text):
    p = etree.Element(HP + "p", {"id": "0", "paraPrIDRef": para_id, "styleIDRef": "0", "pageBreak": "0", "columnBreak": "0", "merged": "0"})
    r = etree.SubElement(p, HP + "run", {"charPrIDRef": char_id})
    t = etree.SubElement(r, HP + "t")
    t.text = text
    return p


def _title_box(table_p, head, title, center_para):
    """결과표 문단을 본떠 1열 3행 제목 상자 문단을 만든다"""
    p = copy.deepcopy(table_p)
    tbl = p.find(f".//{HP}tbl")
    tbl.set("id", str(int(tbl.get("id")) + 7))
    tbl.set("rowCnt", "3")
    tbl.set("colCnt", "1")
    tbl.set("repeatHeader", "0")
    tbl.set("pageBreak", "NONE")
    for t in p.iter(HP + "t"):
        if t.getparent().getparent() is p:
            t.text = ""
    trs = tbl.findall(HP + "tr")
    proto = copy.deepcopy(_cells(trs[1])[0])
    for tr in trs:
        tbl.remove(tr)
    top, mid, bot = _band_fill(head, "#3057B9", "#A0B4E6"), _plain_fill(head), _band_fill(head, "#1F5794", "#A0B4E6")
    title_char = _char(head, "13", 2800, face="나눔스퀘어 ExtraBold", bold=True, color="#000000")
    for row, (fill, h, text) in enumerate(((top, 425, ""), (mid, 3400, title), (bot, 425, ""))):
        tr = etree.SubElement(tbl, HP + "tr")
        tc = copy.deepcopy(proto)
        tc.set("borderFillIDRef", fill)
        tc.set("header", "0")
        tc.find(HP + "cellAddr").set("colAddr", "0")
        tc.find(HP + "cellAddr").set("rowAddr", str(row))
        tc.find(HP + "cellSz").set("width", str(TABLE_W))
        tc.find(HP + "cellSz").set("height", str(h))
        mar = tc.find(HP + "cellMargin")
        if mar is not None and row != 1:
            for k in ("top", "bottom"):
                mar.set(k, "0")
        _set_lines(tc, [text])
        for q in tc.iter(HP + "p"):
            q.set("paraPrIDRef", center_para)
            for rn in q.iter(HP + "run"):
                rn.set("charPrIDRef", title_char if row == 1 else rn.get("charPrIDRef"))
        tr.append(tc)
    sz = tbl.find(HP + "sz")
    if sz is not None:
        sz.set("width", str(TABLE_W))
        sz.set("height", str(425 + 3400 + 425))
    return p


def generate(rows, out_path, subject="기관", title="", overview=None):
    """rows: [{org, position, name, say[], key[], answer[], depts[]}]
    overview: {"title": 행사명, "lines": [("❍ (일    시) …", "main"|"sub"), …]} — 주면 ①제목 상자 ②행사 개요를 앞에 넣는다"""
    z = zipfile.ZipFile(TEMPLATE)
    sec = etree.fromstring(z.read("Contents/section0.xml"))
    head = etree.fromstring(z.read("Contents/header.xml"))
    tbl = next(sec.iter(HP + "tbl"))
    table_p = next(p for p in sec if p.tag == HP + "p" and p.find(f".//{HP}tbl") is not None)
    first = [p for p in sec if p.tag == HP + "p"][0]
    head_tr, proto = tbl.findall(HP + "tr")[:2]
    tbl.remove(proto)
    _set_lines(_cells(head_tr)[0], ["대학명" if subject == "대학" else "기관명"])
    for i, r in enumerate(rows or [{}], 1):
        tr = copy.deepcopy(proto)
        vals = [[r.get("org", "")], [r.get("position", "")], [r.get("name", "")], r.get("say") or [""], r.get("key") or [""],
                r.get("answer") or [""], r.get("depts") or [""]]
        for c, (tc, ls) in enumerate(zip(_cells(tr), vals)):
            _set_lines(tc, ls)
            tc.find(HP + "cellAddr").set("rowAddr", str(i))
            tc.find(HP + "cellAddr").set("colAddr", str(c))
        tbl.append(tr)
    tbl.set("rowCnt", str(len(tbl.findall(HP + "tr"))))
    if overview:
        center = _para(head, table_p.get("paraPrIDRef"), "CENTER")
        left = _para(head, table_p.get("paraPrIDRef"), "LEFT")
        sub = _para(head, table_p.get("paraPrIDRef"), "LEFT", left=2400)
        main_char = _char(head, "1", 1300, face="한컴산뜻돋움", bold=False)
        sub_char = _char(head, "1", 1000, face="한컴산뜻돋움", bold=False)
        blank_char = _char(head, "1", 1000)
        new = [_title_box(table_p, head, overview.get("title") or CHECK, center), _p(left, blank_char, "")]
        for text, kind in overview.get("lines") or []:
            new.append(_p(sub, sub_char, text) if kind == "sub" else _p(left, main_char, text))
        new.append(_p(left, blank_char, ""))
        k = list(sec).index(first) + 1
        for n, p in enumerate(new):
            sec.insert(k + n, p)
    for p in sec.iter(HP + "p"):                                  # 줄 배치는 한글이 새로
        for ls in p.findall(HP + "linesegarray"):
            p.remove(ls)
    data = etree.tostring(sec, xml_declaration=True, encoding="UTF-8", standalone=True)
    hdata = etree.tostring(head, xml_declaration=True, encoding="UTF-8", standalone=True)
    out_path = Path(out_path)
    with zipfile.ZipFile(out_path, "w") as zo:
        for n in z.namelist():
            b = z.read(n)
            if n == "Contents/section0.xml":
                b = data
            elif n == "Contents/header.xml":
                b = hdata
            elif n == "Preview/PrvText.txt":
                b = (title or "회의록 정리").encode("utf-8")
            elif n == "Contents/content.hpf":
                h = b.decode("utf-8")
                now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                h = re.sub(r'(<opf:meta name="ModifiedDate"[^>]*>)[^<]*', r"\g<1>" + now, h)
                b = h.encode("utf-8")
            zo.writestr(n, b, compress_type=zipfile.ZIP_STORED if n == "mimetype" else zipfile.ZIP_DEFLATED)
    return {"path": out_path}


def overview_from(data):
    """행사데이터(load_event) → 제목 상자·개요 줄. 못 찾은 값은 「(확인 필요)」"""
    ev, d = data["event"], data["derived"]
    real = lambda s: s if s and not re.fullmatch(r"[ㅇ○\s.()\[\]확인필요]*", s) else CHECK      # noqa: E731
    when = d.get("when_text") if not str(ev.get("date", "")).startswith("1900") else ""
    lines = [(f"❍ (일    시) {real(when)}", "main"), (f"❍ (장    소) {real(ev.get('venue', ''))}", "main"),
             (f"❍ (참    석) {real(d.get('attendee_text', ''))}", "main")]
    if d.get("staff_count"):
        lines.append((d.get("staff_text") or f"※ 배석({d['staff_count']}명)", "sub"))
    content = ev.get("summary") or ", ".join(ev.get("agenda") or [])
    lines.append((f"❍ (내    용) {real(content)}", "main"))
    return {"title": real(ev.get("title", "")), "lines": lines}
