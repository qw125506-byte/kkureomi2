# -*- coding: utf-8 -*-
"""⑥ 결과보고 — templates/result.hwpx(사용자가 직접 다듬어 붙임으로 준 「⑥ 창업생태계 활성화 간담회 결과보고」)를 복제해 내용만 바꾼다.

양식(11쪽): 결재란 / 요약 표지(핵심 항목·일시·장소·참석·주요내용·의견수렴·향후계획) / 본문 제목·보고 문장 /
Ⅰ 총평(시장님) / Ⅱ 간담회 개요 / Ⅲ 기관별 의견수렴 내용(쪽마다 따로 표) / Ⅳ 향후계획 / 붙임 1 회의록 / 붙임 2 참석자 명단 / 붙임 3 사진.

핵심 원칙 — 「바뀐 데가 없으면 건드리지 않는다」: 새로 만든 글이 양식에 들어 있는 글과(띄어쓰기를 빼고) 같으면 그 문단·행·표를
그대로 둔다. 사람이 손으로 맞춘 줄바꿈·글자 모양·행 높이가 그대로 남는다(같은 예시 데이터로 만들면 붙임문서와 똑같다).
글이 달라진 곳만 같은 자리 문단·행을 본으로 복제해 다시 쓴다.
"""
import copy
import math
import re
from pathlib import Path

from core import calc
from core import hwpx as _core
from core.hwpx import (BuildError, Doc, N, Q, bp, cell, cell_ps, clone, expect_text, insert_after, josa, merge_same,
                       owner_p, p_with, remove, renumber, spaced, tr_cells)
from generators.hwpx.brief import fit

T_APPROVAL = "2113655862"
T_COVER_TITLE = "1212474946"
T_COVER_BOX = "2113655868"
T_DEPT = "2113655880"
T_BODY_TITLE = "1212474948"
T_INTENT = "2113655899"
T_SUGGEST_HEAD = "1212474973"
T_SUGGEST = "1170865051"
T_PLAN = "1212474982"
T_MINUTES = "1170865071"
T_ROSTER = "1171806919"
P = dict(review=19, overview=25, suggest=30, suggest_more=(31, 32, 33), minutes_title=46, photo_head=52)
TOPS = 54
# 결과보고 양식: 편집본(기본, 사용자가 다듬은 창업 예시 양식) / 견본(공모전제출 문서참조 「(견본) 결과보고」 그대로)
TEMPLATES = {"편집본": "result.hwpx", "견본": "result_sample.hwpx"}


def find_layout(doc):
    """양식마다 문단 자리가 달라서(견본은 의견수렴 표 2개, 편집본은 4개) 글·표로 자리를 찾는다 → P와 같은 꼴의 사전"""
    tops = doc.orig
    has = lambda p, tid: any(t.get("id") == tid for t in p.iter(Q("tbl")))          # noqa: E731
    idx = lambda f, start=0: next(i for i in range(start, len(tops)) if f(tops[i]))  # noqa: E731
    review = idx(lambda p: has(p, "1212474952"))
    overview = idx(lambda p: "(일    시)" in ptext(p), review + 1)
    suggest = idx(lambda p: has(p, T_SUGGEST))
    plan_head = idx(lambda p: has(p, "1212474975"))
    more = [i for i in range(suggest + 1, plan_head) if any("주요 건의사항" in ptext(t) for t in tops[i].iter(Q("tbl")))]
    m1 = idx(lambda p: has(p, "1212474977"))
    return dict(review=review, overview=overview, suggest=suggest, suggest_more=tuple(more),
                list=idx(lambda p: ptext(p).strip().startswith("붙임 1.")),
                minutes_title=idx(lambda p: ptext(p).strip().startswith("["), m1 + 1),
                roster_head=idx(lambda p: has(p, "1212474979")), photo_head=idx(lambda p: has(p, "1212474981")))
REVIEW_SLOTS = 13          # 총평 글상자(쪽 위 고정)에 들어가는 줄 수
CHARS_PER_LINE = 33
FIRST_TABLE_H, OTHER_TABLE_H, HEAD_H = 64545, 69500, 3700     # 의견수렴 표 한 쪽의 높이(첫 쪽은 Ⅲ 제목 줄 때문에 낮음)
WIDTHS = [4266, 6600, 11200, 21837, 7400]


def run_text(r):
    return "".join(t.text or "" for t in r.findall("hp:t", N))


def set_only(p, s):
    """문단 글 바꾸기 — 글이 같으면(띄어쓰기·글머리 기호 무시) 그대로"""
    if norm(ptext(p)) != norm(s):
        bp.set_only(p, s)


def set_runs(p, values, expect=None):
    """칸별 글 바꾸기 — 모두 같으면 그대로"""
    rs = p.findall("hp:run", N)
    if all(i < len(rs) and norm(run_text(rs[i])) == norm(v) for i, v in values.items()):
        return
    _core.set_runs(p, values, expect)


def set_cell_lines(tc, lines):
    """표 칸 글 바꾸기 — 칸 안 문단이 글까지 같으면 그대로(자간 맞춤도 이미 되어 있음)"""
    want = [lines] if isinstance(lines, str) else [str(x) for x in lines] or [""]
    if [norm(ptext(p)) for p in cell_ps(tc)] == [norm(x) for x in want]:
        return
    bp.set_cell_lines(tc, want)


def norm(s):
    return re.sub(r"[\s-]+", "", s or "")             # 띄어쓰기와 글머리 기호(글꼴 속 기호 글자)는 같은 글로 본다


def ptext(p):
    return "".join(t.text or "" for t in p.iter(Q("t")))


def short_pos(position, city):
    """천안시장 → 시장 (명단의 기관 칸에 시 이름이 있으므로)"""
    stem = city[:-1] if city.endswith("시") else city
    return position[len(stem):] if position.startswith(stem) and len(position) > len(stem) else position


def spaced_pos(pos):
    """원본 표기: 시   장, 총   장 (짧은 직위만 띄움)"""
    return ("  " if len(pos) == 3 else "   ").join(pos) if len(pos) <= 3 else pos


def last_text_run(p):
    """문단에서 글이 든 마지막 칸 번호(뒤에 빈 칸이 있어도)"""
    rs = p.findall("hp:run", N)
    idx = [i for i, r in enumerate(rs) if "".join(t.text or "" for t in r.findall("hp:t", N)).strip()]
    return idx[-1] if idx else len(rs) - 1


def own_row(old, i, n):
    """i번째 새 줄의 본: 같은 자리 옛 줄(모양 그대로). 줄 수가 달라졌으면 머리·꼬리·가운데 줄을 차례로 쓴다."""
    if n == len(old):
        return old[i]
    if i == 0:
        return old[0]
    if i == n - 1 and len(old) > 1:
        return old[-1]
    return old[1] if len(old) > 2 else old[0]


def reset_height(tr, h=3546):
    for tc in tr.findall("hp:tc", N):
        tc.find("hp:cellSz", N).set("height", str(h))


def cells_sig(tr):
    return [norm(ptext(tc)) for tc in tr.findall("hp:tc", N)]


def rebuild(tbl, keep, data, fill, sig):
    """keep: 남길 머리 줄 수. data 한 항목마다 한 줄. fill(tr, item, i)이 줄을 채우고 sig(tr)가 줄 안 글의 정규화 목록.
    줄 수가 같으면 같은 자리 옛 줄을 그대로 채워(글이 같으면 손대지 않음) 모양을 지키고,
    달라진 줄만 높이를 한글이 다시 잡게 한다."""
    old = tbl.findall("hp:tr", N)[keep:]
    for tr in old:
        tbl.remove(tr)
    n = len(data)
    for i, item in enumerate(data):
        if n == len(old):
            tr = old[i]
            before = sig(tr)
            fill(tr, item, i)
            if sig(tr) != before:
                reset_height(tr)
        else:
            tr = clone(own_row(old, i, n))
            fill(tr, item, i)
            reset_height(tr)
        tbl.append(tr)
    renumber(tbl)


def fill_approval(doc, data):
    org, t = data["org"], doc.tbl(T_APPROVAL)
    set_cell_lines(cell(t, 0, 1), [f'{org["dept"]}    - '])
    line = org.get("approval_line") or []
    slots = [3, 4, 5, 6, 8, 9]
    if len(line) != len(slots):
        doc.warnings.append(f"결재선 {len(line)}칸 — 원본 결재란은 {len(slots)}칸이라 앞에서부터 채움")
    for col, who in zip(slots, line + [""] * len(slots)):
        set_cell_lines(cell(t, 0, col), [who[:-2], who[-2:]] if len(who) > 4 else [who])   # 청년정책 / 팀장
    set_cell_lines(cell(t, 2, 1), [org.get("retention", "")])
    set_cell_lines(cell(t, 5, 1), [org.get("disclosure", "")])


def cover_title(tbl, text):
    tc = cell(tbl, 1, 0)
    p = cell_ps(tc)[0]
    if norm(ptext(p)) == norm(text):
        return
    set_only(p, text)
    fit(p, bp.cell_avail(tc), ratio=0.97, squeeze=8)


def reconcile(paras, texts, make):
    """paras: 양식에 있는 문단들, texts: 새 글들. 글이 모두 같으면 그대로(False), 아니면 make(글)로 만든 문단들로 바꾼다(True)."""
    if len(paras) == len(texts) and all(norm(ptext(p)) == norm(t) for p, t in zip(paras, texts)):
        return False
    new = [make(t) for t in texts]
    anchor = paras[0]
    for np_ in new:
        anchor.addprevious(np_)
    for p in paras:
        remove(p)
    return True


def fill_cover(doc, data, d, res, end):
    ev = data["event"]
    cover_title(doc.tbl(T_COVER_TITLE), f'{ev["title"]} 결과 보고')
    box = owner_p(doc.tbl(T_COVER_BOX))
    ps = list(box.iter(Q("p")))
    hl = [p for p in ps if p is not box and ptext(p).lstrip().startswith("- ")]
    items = (res.get("highlights") or [])[:4]
    if items and hl:
        proto = copy.deepcopy(hl[-1])

        def make(t):
            np_ = clone(proto)
            set_only(np_, t)
            return np_
        reconcile(hl, [f" - {h}" for h in items], make)
    set_runs(p_with(box, "(일    시)"), {3: f'{d["date_text"]} ', 4: f'{ev["start"]} ~ {end}'})
    pv = p_with(box, "(장    소)")
    set_runs(pv, {3: ev.get("venue_short") or ev["venue"], **{k: "" for k in range(4, len(pv.findall("hp:run", N))) if ptext(pv.findall("hp:run", N)[k])}})
    from generators.hwpx.plan import cover_attend
    who = cover_attend(d["attendee_text"])
    if len(who) > 30:                     # 표지는 한 줄: 길면 인원만(긴 설명은 본문 (참석대상)에)
        who = ev.get("headcount") or who.split("(")[0]
    short_staff = f'※ 배석({d["staff_count"]}명)' if d["staff_count"] else ""
    set_runs(p_with(box, "(참    석)"), {3: f'{who} ', 4: short_staff})
    summary = res.get("summary") or ev.get("summary", "")
    pm = p_with(box, "(주요내용)")
    rs = pm.findall("hp:run", N)
    lab = next(k for k, r in enumerate(rs) if "(주요내용)" in ptext(r))
    if doc.style == "견본":                                        # 견본은 내용이 여러 칸(굵게·괄호) — 첫 글 칸에 쓰고 나머지는 비운다
        set_runs(pm, {lab + 2: summary, **{k: "" for k in range(lab + 3, len(rs))}})
    else:
        set_runs(pm, {last_text_run(pm): summary})                    # 양식: 라벨 뒤 글 칸이 내용
    sug = res.get("suggestions") or []
    people = len({a["name"] for a in data["attendees"] if a.get("name")}) or len({s["org"] for s in sug})
    cnt = sum(1 for s in sug if s.get("title"))
    subj = res.get("opinion_subject") or "기관"
    set_runs(p_with(box, "(의견수렴)"), {2: f"(의견수렴) {people}개 {subj} 주요의견 " if subj != "기관" else f"(의견수렴) 참석자 {people}명 주요의견 ",
                                        3: f"[총 {cnt}건]"})
    pf = p_with(box, "(향후계획)")
    set_runs(pf, {last_text_run(pf): res.get("next_steps", "")})
    dt = doc.tbl(T_DEPT)
    set_only(p_with(dt, "천안시"), data["org"]["city"])
    set_only(p_with(dt, "["), f'[{data["org"]["dept"]}]')


def intent_sentence(data, style="편집본"):
    """본문 보고 문장: 제목이 「…활성화·발전·강화 간담회」 꼴이면 「창업 현장의 주요 의견과 건의사항을 정리하고,
    창업생태계 활성화를 위한 정책 개선 및 지원방안을 검토하고자 함」, 아니면 「머리문구 「행사명」을 개최하고 그 결과를 다음과 같이 보고함.」"""
    ev = data["event"]
    words = re.sub(r"^\d{4}년?\s*", "", ev["title"]).split()
    kind = words[-1] if words and words[-1].endswith(("간담회", "회의", "설명회", "토론회")) else ""
    core = " ".join(words[:-1] if kind else words)
    if style != "견본" and kind and len(words) >= 3 and words[-2].endswith(("활성화", "발전", "강화", "증진")):
        field = re.sub(r"(생태계|산업|분야)$", "", words[0]) or words[0]
        return f"{field} 현장의 주요 의견과 건의사항을 정리하고, {core}{josa(core, '을/를')} 위한 정책 개선 및 지원방안을 검토하고자 함"
    title = ev["title"]
    lead = f'{ev.get("slogan", "")} 「{title}」{josa(title, "을/를")}'.strip()
    return f"{lead} 개최하고 그 결과를 다음과 같이 보고함."


def fill_body_head(doc, data):
    ev = data["event"]
    cover_title(doc.tbl(T_BODY_TITLE), f'{ev["title"]} 결과 보고')
    t = doc.tbl(T_INTENT)
    ps = [p for p in t.iter(Q("p")) if ptext(p).strip()]
    sent = intent_sentence(data, doc.style)
    first = ps[0]
    if norm(ptext(first).replace("", "")) == norm(sent) and len(ps) == 1:
        return
    runs = first.findall("hp:run", N)
    texts = [ptext(r) for r in runs]
    k = next((i for i, x in enumerate(texts) if "" in x), 0)
    body = [i for i, x in enumerate(texts) if i != k and x.strip()]
    values = {i: "" for i in body[1:]}
    values[body[0] if body else min(k + 1, len(runs) - 1)] = sent
    set_runs(first, values)
    for extra in ps[1:]:                                           # 견본의 둘째 줄은 쓰지 않는다(한 줄로 이어 씀)
        set_runs(extra, {i: "" for i in range(len(extra.findall("hp:run", N)))})


def est_lines(s):
    return max(1, math.ceil(len(s) / CHARS_PER_LINE))


def fit_review(lines):
    """총평 줄 수를 글상자(쪽 위 고정)에 맞게: 맺음 인사 → 첫머리 인사 순으로 빼고, 그래도 넘치면 뒤에서부터"""
    lines = list(lines)

    def total():
        return sum(est_lines(x) for x in lines)
    if len(lines) > 3 and total() > REVIEW_SLOTS:
        for k in (len(lines) - 1, 0):
            if len(lines) > 3 and total() > REVIEW_SLOTS:
                lines.pop(k)
    while len(lines) > 3 and total() > REVIEW_SLOTS:
        lines.pop()
    return lines


def set_bullet(p, text):
    """글머리 문단: 첫 칸의 글머리 기호는 두고 나머지 칸은 비운 뒤 글을 둘째 칸(없으면 첫 칸)에"""
    rs = p.findall("hp:run", N)
    sym = re.match(r"^(\s*[-]+\s*)", ptext(rs[0]))
    head = sym.group(1) if sym else ""
    for r in rs:
        for t in r.findall("hp:t", N):
            bp.set_t(t, "")
    if len(rs) > 1:
        bp.set_t(rs[0].find("hp:t", N), head)
        bp.set_t(rs[1].find("hp:t", N), text)
    else:
        bp.set_t(rs[0].find("hp:t", N), head + text)
    bp.drop_lineseg(p)


HH = "http://www.hancom.co.kr/hwpml/2011/head"
SAMPLE_REVIEW_SLOTS = 14   # 견본 총평 글상자: 글 줄 + 사이 빈 줄 합쳐 들어가는 줄 수(견본 5항목 10줄 + 빈 줄 4)


def hanging_para(doc, pid, indent):
    """문단 모양 pid를 복제해 내어쓰기(둘째 줄부터 indent만큼 안으로) 모양을 만든다 → 새 id"""
    cache = doc.__dict__.setdefault("_hang", {})
    if (pid, indent) in cache:
        return cache[(pid, indent)]
    src = next(x for x in doc.header.iter("{%s}paraPr" % HH) if x.get("id") == pid)
    parent = src.getparent()
    np_ = copy.deepcopy(src)
    np_.set("id", str(max(int(x.get("id")) for x in parent) + 1))
    for m in np_.iter("{%s}margin" % HH):
        for x in m:
            if x.tag.endswith("}intent"):
                x.set("value", str(-indent))
    parent.append(np_)
    parent.set("itemCnt", str(len(parent)))
    cache[(pid, indent)] = np_.get("id")
    return np_.get("id")


def fill_review_sample(doc, top, lines):
    """견본 총평: 「 ❍ 글」 문단 사이에 빈 줄 하나씩(견본 그대로), 줄이 넘어가면 글 첫머리에 맞춰 내어쓰기"""
    inner = [p for p in top.iter(Q("p")) if p is not top and not any(a.tag == Q("tbl") for a in p.iterancestors() if a is not top)]
    bullets = [p for p in inner if "" in ptext(p)]
    first, last = inner.index(bullets[0]), inner.index(bullets[-1])
    blank = next(p for p in inner[first:last] if not ptext(p).strip())
    olds = [p for p in inner[first:last + 1]]
    est = lambda x: max(1, math.ceil(len(x) / 35))                  # noqa: E731  견본 글상자는 한 줄 35자쯤(내어쓰기 뒤)
    while len(lines) > 3 and sum(est(x) for x in lines) + len(lines) - 1 > SAMPLE_REVIEW_SLOTS:
        lines = lines[:-1]                                          # 넘치면 뒤(맺음 말)부터 뺀다
    proto, bproto = copy.deepcopy(bullets[0]), copy.deepcopy(blank)
    pid = hanging_para(doc, proto.get("paraPrIDRef"), 2900)      # 「 ❍ 」 너비만큼(15pt 글자 기준)
    new = []
    for k, t in enumerate(lines):
        if k:
            new.append(clone(bproto))
        np_ = clone(proto)
        np_.set("paraPrIDRef", pid)
        set_only(np_, f"  {t}")
        new.append(np_)
    for np_ in new:
        olds[0].addprevious(np_)
    for p in olds:
        remove(p)


def fill_review(doc, res):
    top = doc.orig[doc.P["review"]]
    lines = fit_review(res.get("mayor_summary") or [])
    if not lines:
        remove(top)
        return
    if doc.style == "견본":
        return fill_review_sample(doc, top, list(res.get("mayor_summary") or []))
    ps = []
    for p in top.iter(Q("p")):
        if p is top or "" not in ptext(p):
            continue
        a, in_tbl = p.getparent(), False
        while a is not None and a is not top:
            in_tbl = in_tbl or a.tag == Q("tbl")
            a = a.getparent()
        if not in_tbl:
            ps.append(p)
    proto = copy.deepcopy(ps[0])

    def make(t):
        np_ = clone(proto)
        set_bullet(np_, t)
        return np_
    reconcile(ps, lines, make)


def fill_overview(doc, data, d, end):
    ev, res = data["event"], data.get("result") or {}
    box = doc.orig[doc.P["overview"]]
    set_runs(p_with(box, "(일    시)"), {2: f'{d["date_text"]} {ev["start"]} ~ {end}'})
    set_runs(p_with(box, "(장    소)"), {3: ev.get("venue_short") or ev["venue"]})
    from generators.hwpx.plan import cover_attend
    set_runs(p_with(box, "(참석대상)"), {2: f'{cover_attend(d["attendee_text"])} ', 3: f'※ 배석({d["staff_count"]}명)' if d["staff_count"] else ""})
    label = p_with(box, "(회의내용)")
    ps = list(box.iter(Q("p")))
    olds = [p for p in ps[ps.index(label) + 1:] if ptext(p).strip()]
    proto = copy.deepcopy(olds[0])

    def make(t):
        np_ = clone(proto)
        set_only(np_, t)
        return np_
    reconcile(olds, [f"   - {c}" for c in (res.get("contents") or [])[:4]], make)


# ---------- Ⅲ 기관별 의견수렴 ----------
def trim_request(x):
    """아주 긴 요청 줄은 끝의 「함」을 뗀다(줄바꿈 때 「요청함」만 홀로 남지 않게 — 사람이 다듬는 방식)"""
    return x[:-1] if x.endswith("요청함") and len(x) >= 75 else x


def who_lines(s, people):
    """견본 「직 위 (성 명)」 칸: 건의자마다 기관(줄임)·직위·(성명) 세 줄"""
    out = []
    for name in s.get("names") or []:
        a = people.get(name)
        if not a:
            continue
        pos = a.get("position", "")
        out += [(a.get("org") or "").strip(), spaced_pos(pos) if len(pos) <= 3 else pos, f"({spaced(name)})"]
    return [x for x in out if x]


def suggestion_rows(res, people=None):
    """의견수렴 표 줄: (기관 줄들, 건의 제목, 세부 문단들[(글, 종류)], 부서 줄들). 계획서 참석자는 한 명도 빼지 않는다.
    people(이름 → 참석자)을 주면 기관 칸 대신 견본처럼 기관·직위·(성명)을 쓴다."""
    rows = []
    for s in res.get("suggestions") or []:
        orgs = s["org"].split("·") if s.get("title") else [s["org"]]
        if people:
            orgs = who_lines(s, people) or orgs
        if not s.get("title"):
            rows.append((orgs, "별도 건의사항 없음", [("-", "b")], [""]))
            continue
        det = [(x, "a") if x.startswith("(시 답변)") else (trim_request(x), "b") for x in s.get("detail") or []]
        rows.append((orgs, s["title"], det, s.get("depts") or [""]))
    return rows


def detail_paras(row_det):
    """세부 문단 글 목록: 현황·요청 문단들, (시 답변이 있으면) 빈 줄, 시 답변"""
    out = [x for x, k in row_det if k == "b"]
    ans = [x for x, k in row_det if k == "a"]
    return out + (["", ans[0]] if ans else [])


def col_chars(widths):
    """칸 너비(HWPUNIT) → 한 줄 글자 수(편집본 너비에서 세부 24자·제목 11자·기관 6자인 비율 그대로)"""
    if list(widths) == list(WIDTHS):
        return 6, 11, 24
    # 다른 양식(견본): 좁은 세부 칸은 「- 」 내어쓰기와 양쪽 맞춤 때문에 2자쯤 덜 들어간다
    return (max(3, int(6 * widths[1] / WIDTHS[1])), max(5, int(11 * widths[2] / WIDTHS[2])),
            max(8, int(24 * widths[3] / WIDTHS[3]) - 2))


def est_row_height(item, widths=WIDTHS):
    """줄 수로 어림한 행 높이(HWPUNIT): 칸마다 한 줄 글자 수(col_chars)로 줄 수를 센다"""
    orgs, title, det, depts = item
    c_org, c_title, c_det = col_chars(widths)
    paras = detail_paras(det)
    lines = max(sum(max(1, math.ceil(len(x) / c_det)) for x in paras) if paras else 1,
                math.ceil(len(title) / c_title), sum(math.ceil(len(x) / c_org) for x in orgs), len(depts))
    return lines * 1750 + 1500


def chunk_rows(rows, widths=WIDTHS):
    """쪽마다 한 표: 어림 높이가 쪽 높이를 넘기 전까지 넣는다"""
    chunks, cur, h = [], [], 0
    for r in rows:
        rh = est_row_height(r, widths)
        cap = (OTHER_TABLE_H if chunks else FIRST_TABLE_H) - HEAD_H
        if cur and h + rh > cap:
            chunks.append(cur)
            cur, h = [], 0
        cur.append(r)
        h += rh
    chunks += [cur] if cur else []
    return balance_chunks(rows, chunks, widths)


def balance_chunks(rows, chunks, widths=WIDTHS):
    """마지막 쪽에 행이 조금만 남으면(쪽 높이의 절반 미만) 같은 쪽 수 안에서 행을 고르게 나눈다
    — 남은 두세 행이 한 쪽 전체로 늘어나 보이지 않게(견본처럼 쪽마다 비슷한 행 수)"""
    if len(chunks) < 2:
        return chunks
    est = [est_row_height(r, widths) for r in rows]
    caps = [(FIRST_TABLE_H if k == 0 else OTHER_TABLE_H) - HEAD_H for k in range(len(chunks))]
    if sum(est[-len(chunks[-1]):]) >= caps[-1] / 2:
        return chunks
    target = sum(est) / len(chunks)
    out, i = [], 0
    for k in range(len(chunks)):
        left = len(chunks) - k - 1                      # 뒤에 남겨야 할 쪽 수(쪽마다 한 행 이상)
        cur, h = [], 0
        while i < len(rows) - left and (not cur or (h + est[i] <= caps[k] and h + est[i] / 2 <= target)):
            cur.append(rows[i])
            h += est[i]
            i += 1
        out.append(cur)
    if i < len(rows) or any(sum(est_row_height(r, widths) for r in c) > cap for c, cap in zip(out, caps)):
        return chunks                                  # 고르게 나눌 수 없으면 원래대로
    return out


def set_runs_text(p, text, label=None):
    """문단 안 모든 칸을 비우고 글을 마지막 칸에(label이 있으면 첫 칸에 라벨)"""
    rs = p.findall("hp:run", N)
    for k, r in enumerate(rs):
        for t in r.findall("hp:t", N):
            bp.set_t(t, (label if k == 0 else text if k == len(rs) - 1 else "") if label is not None else (text if k == len(rs) - 1 else ""))
    bp.drop_lineseg(p)


def fill_detail_cell_sample(tc, row_det, dash_proto):
    """견본 세부 칸: 두 줄 이상이면 견본의 「- 」 문단 모양으로 「- 글」, 하나뿐이면 견본 1번처럼 「-」 없이"""
    want = [x for x in detail_paras(row_det) if x and not x.startswith("(시 답변)")]
    if len(want) > 2:                                              # 견본처럼 두 줄까지: 현황(첫 줄)과 요청(끝 줄)
        want = [want[0], want[-1]]
    sub = tc.find("hp:subList", N)
    ps = cell_ps(tc)
    single = copy.deepcopy(ps[0])
    for p in ps:
        sub.remove(p)
    for x in want:
        np_ = clone(dash_proto if len(want) > 1 else single)
        set_only(np_, f"- {x}" if len(want) > 1 else x)
        sub.append(np_)


def fill_detail_cell(tc, row_det):
    """세부 칸: 문단들이 글까지 같으면 그대로. 아니면 현황·요청은 첫 문단 모양, 빈 줄, 시 답변은 라벨(굵게)+글 모양으로 다시 씀"""
    want = detail_paras(row_det)
    ps = cell_ps(tc)
    if [norm(ptext(p)) for p in ps] == [norm(x) for x in want]:
        return
    sub = tc.find("hp:subList", N)
    bullet = copy.deepcopy(ps[0])
    blank = next((copy.deepcopy(p) for p in ps if not ptext(p).strip()), None)
    answer = next((copy.deepcopy(p) for p in ps if norm(ptext(p)).startswith("(시답변)")), None)
    for p in ps:
        sub.remove(p)
    for x in want:
        if not x:
            np_ = clone(blank if blank is not None else bullet)
            if blank is None:
                set_runs_text(np_, "")
        elif x.startswith("(시 답변)") and answer is not None:
            np_ = clone(answer)
            label = "(시 답변) "
            set_runs_text(np_, x[len(label):], label)
        else:
            np_ = clone(bullet)
            set_runs_text(np_, x)
        sub.append(np_)


def fill_suggest_table(tbl, part, start, subj, height, who=False, widths=WIDTHS, dash=None):
    trs = tbl.findall("hp:tr", N)
    set_cell_lines(tr_cells(trs[0])[1], ["직 위", "(성 명)"] if who else [f"{subj}명"])

    def fill(tr, item, i):
        orgs, title, det, depts = item
        c = tr_cells(tr)
        set_cell_lines(c[0], [str(start + i)])
        set_cell_lines(c[1], orgs)
        if who:                                                    # 직위(성명) 칸: 긴 기관명(㈜모빌리티랩 등)이 낱말 중간에서 끊기지 않게 한 줄로
            for q in cell_ps(c[1]):
                if len(ptext(q).strip()) > 5 and not ptext(q).strip().startswith("("):
                    fit(q, bp.cell_avail(c[1]), ratio=0.85, squeeze=15)
        set_cell_lines(c[2], [title])
        if dash is not None:
            fill_detail_cell_sample(c[3], det, dash)
        else:
            fill_detail_cell(c[3], det)
        set_cell_lines(c[4], depts)
    rebuild(tbl, 1, part, fill, cells_sig)
    rows = tbl.findall("hp:tr", N)[1:]
    if any(tr.find("hp:tc/hp:cellSz", N).get("height") == "3546" for tr in rows):
        # 새로 쓴 줄이 있으면 표가 쪽을 채우도록 어림 높이에 비례해 높이를 나눈다(사람이 표 아래 선을 끌어 맞추는 것과 같게)
        est = [est_row_height(x, widths) for x in part]
        scale = max(1.0, (height - HEAD_H) / sum(est))
        for tr, e in zip(rows, est):
            reset_height(tr, int(e * scale))
    tbl.find("hp:sz", N).set("height", str(sum(int(tr.find("hp:tc/hp:cellSz", N).get("height")) for tr in tbl.findall("hp:tr", N))))
    for tr in tbl.findall("hp:tr", N):
        for tc in tr.findall("hp:tc", N):
            tc.find("hp:cellSz", N).set("width", str(widths[int(tc.find("hp:cellAddr", N).get("colAddr"))]))


def fill_suggestions(doc, data, res):
    who = data["event"].get("opinion_column", "직위(성명)") != "기관명"     # 기본: 견본처럼 기관·직위·(성명)
    widths, dash = WIDTHS, None
    if doc.style == "견본":
        dash = copy.deepcopy(next(p for p in doc.tbl(T_SUGGEST).iter(Q("p")) if ptext(p).lstrip().startswith("- ")))                                        # 견본 표의 칸 너비 그대로(머리 줄 다음 줄에서 읽음)
        first = doc.tbl(T_SUGGEST).findall("hp:tr", N)[1]
        widths = [int(tc_.find("hp:cellSz", N).get("width")) for tc_ in sorted(first.findall("hp:tc", N), key=lambda c: int(c.find("hp:cellAddr", N).get("colAddr")))]
    rows = suggestion_rows(res, {a["name"]: a for a in data["attendees"] if a.get("name")} if who else None)
    if doc.style == "견본":                                        # 높이 어림도 실제로 쓰는 두 줄 기준으로
        rows = [(o_, t_, (lambda b: [b[0], b[-1]] if len(b) > 2 else b)([x for x in d_ if x[1] == "b"]), dp) for o_, t_, d_, dp in rows]
    n = sum(1 for s in res.get("suggestions") or [] if s.get("title"))
    subj = res.get("opinion_subject") or "기관"
    chunks = chunk_rows(rows, widths) or [[]]
    holders = [doc.orig[doc.P["suggest"]]] + [doc.orig[k] for k in doc.P["suggest_more"]]
    tbls = [doc.tbl(T_SUGGEST)] + [h.find(".//hp:tbl", N) for h in holders[1:]]
    start, prev = 1, holders[0]
    for k, part in enumerate(chunks):
        if k < len(tbls):
            tbl, holder = tbls[k], holders[k]
        else:                                                      # 쪽이 더 필요하면 마지막 표 문단을 복제
            holder = clone(holders[-1])
            holder.set("pageBreak", "1")
            tbl = holder.find(".//hp:tbl", N)
            insert_after(prev, [holder])
        fill_suggest_table(tbl, part, start, subj, FIRST_TABLE_H if k == 0 else OTHER_TABLE_H, who, widths, dash)
        start += len(part)
        prev = holder
    for k in range(len(chunks), len(tbls)):                        # 남는 쪽의 표 문단은 지운다
        remove(holders[k])
    set_only(p_with(doc.tbl(T_SUGGEST_HEAD), "의견수렴"), f"{subj}별 의견수렴 내용 [총{n}건]")


def _due(due):
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})$", due or "")
    return f"~{int(m.group(2))}.{int(m.group(3))}.일한" if m else re.sub(r"\s+", "", due or "")


def fill_plan(doc, data, res):
    t = doc.tbl(T_PLAN)
    fu = data.get("follow_up") or []
    items = [(f["task"], _due(f.get("due"))) for f in fu] or [(x, "") for x in res.get("plan_lines") or []]
    if not items:
        items = [("소관 부서 검토 후 결과 안내", "")]

    def fill(tr, it, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [str(i + 1)])
        set_cell_lines(c[1], [re.sub(r"\s+", " ", it[0])])
        set_cell_lines(c[2], [it[1]])
    rebuild(t, 1, items, fill, cells_sig)


def add_budget_admin(doc, data, d):
    """Ⅳ 향후계획 뒤에 화면에서 적은 소요예산·행정사항을 Ⅴ·Ⅵ으로 덧붙인다(칸이 비면 넣지 않음).
    제목 띠·표는 Ⅳ의 것을 복제해 쓰므로 모양이 같다(같은 쪽 아래 빈 자리에 들어감)."""
    rows = [r for r in d.get("budget_rows") or [] if (r.get("item") or "").strip() or r.get("amount")]
    admin = [a for a in data.get("admin_tasks") or [] if (a.get("task") or "").strip()]
    if not rows and not admin:
        return
    tops = doc.orig
    holder = owner_p(doc.tbl(T_PLAN))
    k = tops.index(holder)
    head = next(tops[i] for i in range(k - 1, -1, -1) if ptext(tops[i]).replace(" ", "").endswith("향후계획"))
    gap = [tops[i] for i in range(tops.index(head) + 1, k)]           # 제목 띠와 표 사이 빈 줄
    blank = gap[0] if gap else None
    sections = []
    if rows:
        items = [(f'{r.get("item", "").strip()} ({r["basis"]})' if r.get("basis") else r.get("item", "").strip(),
                  f'{calc.won(r["amount"])}원') for r in rows]
        items.append(("합  계", f'{calc.won(d["budget_total"])}원'))
        sections.append(("소요예산", ("구  분 (산출기초)", "금  액"), items))
    if admin:
        items = [(a["task"].strip() + (f' ({a["dept"].strip()})' if (a.get("dept") or "").strip() else ""), _due(a.get("due")))
                 for a in admin]
        sections.append(("행정사항", ("내  용 (관련부서)", "비 고 (기 한)"), items))
    prev = holder
    for no, (title, (h1, h2), items) in zip(("Ⅴ", "Ⅵ"), sections):
        new = []
        if blank is not None:
            new += [clone(blank), clone(blank)]                         # 앞 표와 띄움
        hp = clone(head)
        hp.set("pageBreak", "0")
        keep_next(doc, hp)
        for t in hp.iter(Q("t")):
            if t.text and t.text.strip() == "Ⅳ":
                t.text = t.text.replace("Ⅳ", no)
            elif t.text and "향후계획" in t.text:
                t.text = t.text.replace("향후계획", title)
        new.append(hp)
        for g in gap:                                                   # 제목 띠가 표와 다른 쪽으로 떨어지지 않게
            new.append(keep_next(doc, clone(g)))
        tp = clone(holder)
        tbl = tp.find(".//hp:tbl", N)
        hc = tr_cells(tbl.findall("hp:tr", N)[0])
        set_cell_lines(hc[1], [h1])
        set_cell_lines(hc[2], [h2])

        def fill(tr, it, i, n=len(items), total=title == "소요예산"):
            c = tr_cells(tr)
            last = total and i == n - 1
            set_cell_lines(c[0], ["" if last else str(i + 1)])
            set_cell_lines(c[1], [re.sub(r"\s+", " ", it[0]) if not last else it[0]])
            set_cell_lines(c[2], [it[1]])
        rebuild(tbl, 1, items, fill, cells_sig)
        new.append(tp)
        insert_after(prev, new)
        prev = tp


def keep_next(doc, p):
    """문단 모양을 복제해 「다음 문단과 함께」(keepWithNext)를 켠 모양으로 바꾼다"""
    cache = doc.__dict__.setdefault("_keep", {})
    pid = p.get("paraPrIDRef")
    if pid not in cache:
        src = next(x for x in doc.header.iter("{%s}paraPr" % HH) if x.get("id") == pid)
        parent = src.getparent()
        np_ = copy.deepcopy(src)
        np_.set("id", str(max(int(x.get("id")) for x in parent) + 1))
        for b in np_.iter("{%s}breakSetting" % HH):
            b.set("keepWithNext", "1")
        parent.append(np_)
        parent.set("itemCnt", str(len(parent)))
        cache[pid] = np_.get("id")
    p.set("paraPrIDRef", cache[pid])
    return p


def spacing_para(doc, pid, percent):
    """문단 모양 pid를 복제해 줄 간격(%)만 바꾼 새 모양 id(같은 요청은 한 번만 만든다)"""
    cache = doc.__dict__.setdefault("_spacing", {})
    if (pid, percent) in cache:
        return cache[(pid, percent)]
    src = next(x for x in doc.header.iter("{%s}paraPr" % HH) if x.get("id") == pid)
    parent = src.getparent()
    np_ = copy.deepcopy(src)
    np_.set("id", str(max(int(x.get("id")) for x in parent) + 1))
    for ls in np_.iter("{%s}lineSpacing" % HH):
        if ls.get("type") == "PERCENT" and int(ls.get("value")) > percent:
            ls.set("value", str(percent))
    parent.append(np_)
    parent.set("itemCnt", str(len(parent)))
    cache[(pid, percent)] = np_.get("id")
    return np_.get("id")


MIN_CPL, MIN_LH = 50, 1200                        # 회의록 칸 한 줄 글자 수·줄 높이(10pt×120%) — 한글 쪽 그림에서 잰 값(130%에서 1300)
MIN_FIRST_H, MIN_OTHER_H = 58300, 69000           # 회의록 행이 쓰는 쪽 높이(첫 쪽은 붙임 제목·회의 제목·머리 줄만큼 낮음, 3% 여유)


def fill_minutes_pages(t, ms):
    """회의록 행을 쪽마다 나눠(행은 쪽에서 안 나뉨) 쪽 아래까지 꽉 차게 행 높이를 늘린다(남는 높이는 행마다 똑같이)"""
    rows = t.findall("hp:tr", N)[1:]
    est = []
    for m in ms:
        ls = m.get("lines") or [""]
        body = sum(max(1, math.ceil((len(x) + 2) / MIN_CPL)) for x in ls)
        who = 2 + (1 if m.get("org") else 0)
        est.append(int(max(body, who, 2.75) * MIN_LH))           # 두 줄짜리 행도 이름 칸 때문에 2.75줄쯤
    pages, cur, h, cap = [], [], 0, MIN_FIRST_H
    for tr, e in zip(rows, est):
        if cur and h + e > cap:
            pages.append((cur, cap))
            cur, h, cap = [], 0, MIN_OTHER_H
        cur.append((tr, e))
        h += e
    if cur:                                                        # 마지막 쪽은 반 넘게 찼을 때만 채운다(붙임 2는 늘 새 쪽)
        pages.append((cur, cap if h >= cap / 2 else None))
    for part, cap in pages:
        if cap is None:
            continue
        extra = max(0, cap - sum(e for _, e in part)) / len(part)    # 남는 높이는 행마다 똑같이(짧은 행도 위아래 여유가 같게)
        for tr, e in part:
            reset_height(tr, int(e + extra))


def add_minutes_header(doc, t):
    """붙임 회의록 표 맨 위에 의견수렴 표와 같은 머리 줄 「직 위 (성 명) | 세부 내용」(회색 칸·굵은 글)"""
    head = tr_cells(doc.tbl(T_SUGGEST).findall("hp:tr", N)[0])
    src = {0: head[1], 1: head[3]}                                  # 의견수렴 머리: 직위(성명) 칸, 세부 내용 칸
    first = t.findall("hp:tr", N)[0]
    tr = copy.deepcopy(first)
    for col, tc in tr_cells(tr).items():
        s_tc = src[col]
        tc.set("borderFillIDRef", s_tc.get("borderFillIDRef"))
        tc.set("header", "0")                                      # 첫 쪽에만(반복하면 회의록이 한 쪽 더 늘어남)
        tc.replace(tc.find("hp:subList", N), copy.deepcopy(s_tc.find("hp:subList", N)))
        tc.find("hp:cellSz", N).set("height", "2400")                 # 두 줄 글만큼 낮게(한글이 글 높이에 맞춰 늘림)
        mar = tc.find("hp:cellMargin", N)
        if mar is not None:
            mar.set("top", "141"), mar.set("bottom", "141")
        for q in tc.iter(Q("p")):
            bp.drop_lineseg(q)
    if col_text := ptext(tr_cells(tr)[0]).replace(" ", ""):
        if "성명" not in col_text:                                  # 의견수렴 표가 기관명 칸이면 회의록 머리는 직위(성명)로
            set_cell_lines(tr_cells(tr)[0], ["직 위", "(성 명)"])
    first.addprevious(tr)
    renumber(t)


# ---------- 붙임 1 회의록: 7칸 표 ----------
# 기관명 · 직위 · 성명 · 발언내용 · 핵심요약 · 시장님 답변 · 비고(관련부서) — 양식 표(2칸, 폭 50460)를 그대로 나눈다
MIN7 = [("기관명", 3956, 0), ("직 위", 2967, 0), ("성 명", 4945, 0), ("발언 내용", 13351, 1),     # 폭은 사용자 정리본(기관별 정리 표)과 같은 비율
        ("핵심 요약", 4945, 1), ("시장님 답변", 12856, 1), ("비 고\n(관련부서)", 7440, 0)]
MIN7_PAD = 300                       # 칸 안쪽 좌우 여백(정리본과 같게)
MIN7_CHAR = 690                      # 9pt 글자 하나의 폭(HWPUNIT)
MIN7_LH = 1400                       # 9pt × 줄 간격 150% 한 줄 높이
MIN7_PT = 900                        # 표 글자 크기 9pt
MIN7_ROW_MAX = 60000                 # 한 행이 이보다 높으면 다음 행으로 이어 쓴다(행은 쪽에서 안 나뉨)


def min7_values(m, data):
    """회의록 한 사람 → 7칸 글 줄 목록"""
    if m.get("org"):
        org, pos, name = m["org"], m.get("position", ""), m.get("name", "")
    else:                                                          # 시장님(주빈)
        org, pos = data["org"].get("city", ""), m.get("position", "").replace("님", "") or "시장"
        name = m.get("name") or data["host"].get("name", "")
    say = ["- " + re.sub(r"^[\s\-–·]+", "", x) for x in (m.get("lines") or [""]) if x.strip()] or [""]
    return [[org], [pos], [name], say,
            ["- " + x for x in m.get("key") or []], ["- " + x for x in m.get("answer") or []], m.get("depts") or [""]]


def min7_lines(vals):
    """칸마다 줄 수를 어림해 가장 많은 칸의 줄 수"""
    best = 1
    for (_, w, _), ls in zip(MIN7, vals):
        cpl = max(2, (w - 2 * MIN7_PAD) / MIN7_CHAR)
        best = max(best, sum(max(1, math.ceil(len(x) / cpl)) for x in ls))
    return best


def min7_rows(ms, data):
    """사람마다 7칸 값 — 발언이 길어 한 행이 너무 높으면 발언을 나눠 다음 행에 이어 쓴다(이름 칸은 같게)"""
    out = []
    for m in ms:
        vals = min7_values(m, data)
        say, part = vals[3], []
        head_done = False
        for x in say:
            trial = vals[:3] + [part + [x]] + ([[""], [""], [""]] if head_done else vals[4:])
            if part and min7_lines(trial) * MIN7_LH > MIN7_ROW_MAX:
                out.append(vals[:3] + [part] + ([[""], [""], [""]] if head_done else vals[4:]))
                head_done, part = True, []
            part.append(x)
        out.append(vals[:3] + [part] + ([[""], [""], [""]] if head_done else vals[4:]))
    return out


def plain_para(doc, pid, align, percent=150):
    """문단 모양을 복제해 들여쓰기·내어쓰기·문단 간격 0, 줄 간격 percent%, 정렬 align으로(같은 요청은 한 번만)"""
    cache = doc.__dict__.setdefault("_plain", {})
    if (pid, align) in cache:
        return cache[(pid, align)]
    src = next(x for x in doc.header.iter("{%s}paraPr" % HH) if x.get("id") == pid)
    parent = src.getparent()
    np_ = copy.deepcopy(src)
    np_.set("id", str(max(int(x.get("id")) for x in parent) + 1))
    for al in np_.iter("{%s}align" % HH):
        al.set("horizontal", align)
        al.set("vertical", "CENTER")
    for m in np_.iter("{%s}margin" % HH):
        for v in m:
            v.set("value", "0")
    for ls in np_.iter("{%s}lineSpacing" % HH):
        ls.set("type", "PERCENT")
        ls.set("value", str(percent))
    parent.append(np_)
    parent.set("itemCnt", str(len(parent)))
    cache[(pid, align)] = np_.get("id")
    return np_.get("id")


def sized_char(doc, cid, height):
    """글자 모양을 복제해 크기만 바꾼다"""
    cache = doc.__dict__.setdefault("_sized", {})
    if (cid, height) in cache:
        return cache[(cid, height)]
    src = next(x for x in doc.header.iter("{%s}charPr" % HH) if x.get("id") == cid)
    parent = src.getparent()
    nc = copy.deepcopy(src)
    nc.set("id", str(max(int(x.get("id")) for x in parent) + 1))
    nc.set("height", str(height))
    parent.append(nc)
    parent.set("itemCnt", str(len(parent)))
    cache[(cid, height)] = nc.get("id")
    return nc.get("id")


def widen_minutes(doc, t, rows, labels=None):
    """2칸 회의록 표 → 머리 줄 + 7칸 행. 짧은 칸은 양식 왼쪽 칸(가운데 맞춤), 긴 칸은 오른쪽 칸(양쪽 맞춤)을 복제한다."""
    trs = t.findall("hp:tr", N)
    proto = tr_cells(trs[0])
    head_src = tr_cells(doc.tbl(T_SUGGEST).findall("hp:tr", N)[0])[1]       # 의견수렴 표 머리 칸(회색·굵게·가운데)

    def cell(src, col, row, width, lines, head=False, kind=0):
        tc = copy.deepcopy(src)
        if head:
            tc.set("borderFillIDRef", head_src.get("borderFillIDRef"))
            tc.replace(tc.find("hp:subList", N), copy.deepcopy(head_src.find("hp:subList", N)))
        tc.find("hp:cellAddr", N).set("colAddr", str(col))
        tc.find("hp:cellAddr", N).set("rowAddr", str(row))
        tc.find("hp:cellSz", N).set("width", str(width))
        mar = tc.find("hp:cellMargin", N)
        if mar is not None:
            mar.set("left", str(MIN7_PAD)), mar.set("right", str(MIN7_PAD))
        tc.set("hasMargin", "1")
        tc.find("hp:subList", N).set("vertAlign", "CENTER")             # 칸 안 글은 위아래 가운데
        set_cell_lines(tc, lines)
        for q in tc.iter(Q("p")):
            bp.drop_lineseg(q)
            q.set("paraPrIDRef", plain_para(doc, q.get("paraPrIDRef"), "CENTER" if head or kind == 0 else "LEFT"))
            for rn in q.iter(Q("run")):
                rn.set("charPrIDRef", sized_char(doc, rn.get("charPrIDRef"), MIN7_PT))
        return tc

    for tr in trs:
        t.remove(tr)
    new = []
    head = copy.deepcopy(trs[0])
    for tc in head.findall("hp:tc", N):
        head.remove(tc)
    for col, (label, w, kind) in enumerate(MIN7):
        label = labels[col] if labels else label
        head.append(cell(proto[kind], col, 0, w, label.split("\n"), head=True))
    reset_height(head, 2400)
    new.append(head)
    for r, vals in enumerate(rows, 1):
        tr = copy.deepcopy(trs[0])
        for tc in tr.findall("hp:tc", N):
            tr.remove(tc)
        for col, ((_, w, kind), ls) in enumerate(zip(MIN7, vals)):
            tr.append(cell(proto[kind], col, r, w, ls or [""], kind=kind))
        reset_height(tr, max(3546, int(min7_lines(vals) * MIN7_LH + 600)))
        new.append(tr)
    for tr in new:
        t.append(tr)
    t.set("colCnt", str(len(MIN7)))
    t.set("rowCnt", str(len(new)))
    t.set("pageBreak", "TABLE")                                     # 행은 쪽에서 안 나뉨
    t.set("repeatHeader", "1")
    for tc in head.findall("hp:tc", N):                             # 쪽이 넘어가면 머리 줄을 다시 보여 준다
        tc.set("header", "1")


def fill_minutes(doc, data, ms):
    t = doc.tbl(T_MINUTES)
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    title = f'[{data["event"]["title"]} : {(disc.get("desc") or disc["item"]) if disc else "의견 수렴"}]'
    set_only(doc.orig[doc.P["minutes_title"]], title)

    def fill(tr, m, i):
        c = tr_cells(tr)
        who = ([m["org"]] if m.get("org") else []) + [spaced_pos(m["position"]) if len(m["position"]) <= 3 else m["position"]]
        if m.get("name"):
            who.append(f'({spaced(m["name"])})')
        set_cell_lines(c[0], who)
        lines = ["- " + re.sub(r"^[\s\-–·]+", "", x) for x in (m.get("lines") or [""])]
        if dash is None:
            set_cell_lines(c[1], lines)
            return
        sub = c[1].find("hp:subList", N)                         # 견본: 「- 」 줄 모양(내어쓰기·줄 간격 160%·아래 띄움)으로 한 줄씩
        for p in sub.findall("hp:p", N):
            sub.remove(p)
        for x in lines:
            np_ = clone(dash)
            set_only(np_, x)
            sub.append(np_)
    # 견본 회의록 칸은 맨 앞이 줄 간격 0%인 빈 문단이라 그 모양을 쓰면 줄이 겹친다 — 「- 」로 시작하는 첫 문단 모양을 쓴다
    dash = None
    if doc.style == "견본":
        dash = copy.deepcopy(next(p for p in tr_cells(t.findall("hp:tr", N)[0])[1].iter(Q("p")) if ptext(p).lstrip().startswith("- ")))
    rebuild(t, 0, ms, fill, cells_sig)
    head = data["event"].get("opinion_column", "직위(성명)") != "기관명"   # 옛 양식(기관명 칸)은 머리 줄 없이 그대로
    if head and dash is None:                                       # 기본: 기관별 정리 7칸 표(대학명·직위·성명·발언내용·핵심요약·시장님답변·관련부서)
        res = data.get("result") or {}
        rows = res.get("org_rows")
        if rows:
            labels = ["대학명" if res.get("opinion_subject") == "대학" else "기관명", "직 위", "성 명", "발언내용", "핵심요약", "시장님답변", "관련부서"]
            widen_minutes(doc, t, [[[r["org"]], [r["position"]], [r["name"]], r["say"] or [""], r["key"] or [""], r["answer"] or [""],
                                    r["depts"] or [""]] for r in rows], labels)
        else:
            widen_minutes(doc, t, min7_rows(ms, data))
        for k in (2, 1):                                            # 붙임 제목 밑 빈 줄(-1)은 둔다
            gap = doc.orig[doc.P["minutes_title"] + k]
            if not ptext(gap).strip() and not list(gap.iter(Q("tbl"))):
                remove(gap)
        return
    if head:
        add_minutes_header(doc, t)
        t.set("pageBreak", "TABLE")                                 # 한 사람 말(행)이 두 쪽으로 나뉘지 않게: 행 단위로만 쪽을 넘김
    if head and dash is None:                                       # 머리 줄이 생긴 만큼: 양식 행의 남는 높이를 빼고 글 높이에 맞추고,
        for tr in t.findall("hp:tr", N)[1:]:                       # 제목과 표 사이 빈 줄을 뺀다(회의록 쪽 수 그대로)
            reset_height(tr)
            for q in tr.iter(Q("p")):                               # 행이 쪽에서 안 나뉘는 대신 줄 간격을 좁혀(150·160% → 120%) 쪽 수를 지키고
                q.set("paraPrIDRef", spacing_para(doc, q.get("paraPrIDRef"), 120))   # 남는 높이는 행마다 위아래 여유로
                bp.drop_lineseg(q)
        fill_minutes_pages(t, ms)
        for k in (2, 1):                                            # 붙임 제목 밑 빈 줄(-1)은 둔다(제목과 너무 붙지 않게)
            gap = doc.orig[doc.P["minutes_title"] + k]
            if not ptext(gap).strip() and not list(gap.iter(Q("tbl"))):
                remove(gap)
    if dash is not None:                                           # 견본처럼 칸 위아래에 여유: 줄 수(한 줄 38자)·문단 간격으로 행 높이
        for tr, m in zip(t.findall("hp:tr", N)[1 if head else 0:], ms):   # 머리 줄 다음부터
            ls = m.get("lines") or [""]
            h = sum(max(1, math.ceil((len(x) + 2) / 38)) for x in ls) * 1650 + len(ls) * 400 + 700
            reset_height(tr, max(3546, h))


def fill_roster(doc, data, res):
    city = data["org"]["city"]
    h = data["host"]
    people = [(spaced(city), spaced_pos(short_pos(h["position"], city)), h["name"])]
    people += [(spaced(city), s["position"], s["name"]) for s in data.get("staff_present") or []]
    people += [(spaced(city), s["position"], s["name"]) for s in res.get("present_extra") or []]
    people += [(a["org"], a["position"], a["name"]) for a in data["attendees"]]
    t = doc.tbl(T_ROSTER)
    rows = t.findall("hp:tr", N)
    want, prev = [], None                                          # 양식의 명단이 글까지 같으면(병합 칸 포함) 그대로 둔다
    for i, p in enumerate(people):
        want += [str(i + 1)] + ([p[0]] if p[0] != prev else []) + [p[1], " ".join(p[2])]
        prev = p[0]
    have = [norm(ptext(tc)) for tr in rows[1:] for tc in tr.findall("hp:tc", N) if norm(ptext(tc))]
    if have == [norm(x) for x in want]:
        return
    row_t = copy.deepcopy(rows[-1])
    hh = int(min(5244, (66428 - 3546) / len(people)))              # 한 쪽을 채우는 행 높이(양식: 12명 5244). 사람이 많으면 줄여 한 쪽에 담는다

    def fill(tr, p, i):
        c = tr_cells(tr)
        set_cell_lines(c[0], [str(i + 1)])
        set_cell_lines(c[1], [p[0]])
        set_cell_lines(c[2], [p[1]])
        set_cell_lines(c[3], [" ".join(p[2])])
        set_cell_lines(c[4], [""])
        reset_height(tr, hh)
    bp.rebuild_rows(t, 1, None, row_t, None, people, fill)
    merge_same(t, 1, [p[0] for p in people], 1)
    renumber(t)


# ---------- 붙임 3 간담회 사진 ----------
T_PHOTO = "1170865074"          # 붙임 3 사진 표(한 쪽에 2칸, 칸마다 「별도 첨부」)
PHOTO_MEDIA = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif", ".bmp": "image/bmp"}
HC = "http://www.hancom.co.kr/hwpml/2011/core"
OPF = "http://www.idpf.org/2007/opf/"


def image_size(b):
    """그림 파일 머리에서 가로·세로 화소(PIL 없이 — 브라우저판에서도 돌게)"""
    import struct
    if b[:8] == b"\x89PNG\r\n\x1a\n":
        return struct.unpack(">II", b[16:24])
    if b[:6] in (b"GIF87a", b"GIF89a"):
        return struct.unpack("<HH", b[6:10])
    if b[:2] == b"BM":
        w, h = struct.unpack("<ii", b[18:26])
        return w, abs(h)
    if b[:2] == b"\xff\xd8":
        i = 2
        while i + 9 < len(b):
            if b[i] != 0xFF:
                i += 1
                continue
            m = b[i + 1]
            if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                h, w = struct.unpack(">HH", b[i + 5:i + 9])
                return w, h
            i += 2 + struct.unpack(">H", b[i + 2:i + 4])[0]
    raise BuildError("사진 크기를 읽지 못했습니다 — jpg·png 파일인지 확인해 주세요")


def put_photo(doc, tc, path):
    """사진 한 장을 칸 가운데에 글자처럼(treatAsChar) 넣는다 — 칸 안에 들어가게 비율대로 줄임"""
    from lxml import etree
    path = Path(path)
    data = path.read_bytes()
    ext = path.suffix.lower()
    if ext not in PHOTO_MEDIA:
        raise BuildError(f"사진은 jpg·png·gif·bmp만 넣을 수 있습니다: {path.name}")
    pw, ph = image_size(data)
    sz, mar = tc.find("hp:cellSz", N), tc.find("hp:cellMargin", N)
    cw = int(sz.get("width")) - (int(mar.get("left")) + int(mar.get("right")) if mar is not None else 1020)
    ch = int(sz.get("height")) - (int(mar.get("top")) + int(mar.get("bottom")) if mar is not None else 282)
    w = int(cw * 0.96)
    h = int(w * ph / pw)
    if h > ch * 0.94:
        h = int(ch * 0.94)
        w = int(h * pw / ph)
    items = list(doc.hpf.iter("{%s}item" % OPF))
    nums = [int(m.group(1)) for it in items for m in [re.match(r"image(\d+)$", it.get("id") or "")] if m]
    bid = f"image{max(nums, default=0) + 1}"
    href = f"BinData/{bid}{'.jpg' if ext == '.jpeg' else ext}"
    item = etree.SubElement(items[0].getparent(), "{%s}item" % OPF)
    item.set("id", bid), item.set("href", href), item.set("media-type", PHOTO_MEDIA[ext]), item.set("isEmbeded", "1")
    doc.new_bins[href] = data
    dw, dh = pw * 75, ph * 75                     # 그림 원본 크기(화소 × 75, 한글이 쓰는 단위)
    pid, inst = bp.new_id(), bp.new_id()
    xml = (f'<hp:pic xmlns:hp="{N["hp"]}" xmlns:hc="{HC}" id="{pid}" zOrder="0" numberingType="PICTURE" textWrap="TOP_AND_BOTTOM" '
           f'textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" href="" groupLevel="0" instid="{inst}" reverse="0">'
           f'<hp:offset x="0" y="0"/><hp:orgSz width="{w}" height="{h}"/><hp:curSz width="{w}" height="{h}"/>'
           f'<hp:flip horizontal="0" vertical="0"/><hp:rotationInfo angle="0" centerX="{w // 2}" centerY="{h // 2}" rotateimage="1"/>'
           f'<hp:renderingInfo><hc:transMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/>'
           f'<hc:scaMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/><hc:rotMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/></hp:renderingInfo>'
           f'<hc:img binaryItemIDRef="{bid}" bright="0" contrast="0" effect="REAL_PIC" alpha="0"/>'
           f'<hp:imgRect><hc:pt0 x="0" y="0"/><hc:pt1 x="{w}" y="0"/><hc:pt2 x="{w}" y="{h}"/><hc:pt3 x="0" y="{h}"/></hp:imgRect>'
           f'<hp:imgClip left="0" right="{dw}" top="0" bottom="{dh}"/><hp:inMargin left="0" right="0" top="0" bottom="0"/>'
           f'<hp:imgDim dimwidth="{dw}" dimheight="{dh}"/><hp:effects/>'
           f'<hp:sz width="{w}" widthRelTo="ABSOLUTE" height="{h}" heightRelTo="ABSOLUTE" protect="0"/>'
           f'<hp:pos treatAsChar="1" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" '
           f'horzRelTo="PARA" vertAlign="TOP" horzAlign="LEFT" vertOffset="0" horzOffset="0"/>'
           f'<hp:outMargin left="0" right="0" top="0" bottom="0"/><hp:shapeComment>그림입니다.\n원본 그림의 이름: {path.name}</hp:shapeComment></hp:pic>')
    pic = etree.fromstring(xml)
    ps = cell_ps(tc)
    p = ps[0]
    for q in ps[1:]:
        q.getparent().remove(q)
    set_only(p, "")
    run = p.find("hp:run", N)
    run.insert(0, pic)
    bp.drop_lineseg(p)


def fill_photos(doc, photos):
    """붙임 3: 사진을 2장씩 한 쪽에 — 3장 이상이면 사진 표 쪽을 늘린다. 사진이 없으면 양식 그대로(「별도 첨부」)"""
    if not photos:
        return
    tbl = doc.tbl(T_PHOTO)
    holder = owner_p(tbl)
    proto = copy.deepcopy(holder)
    prev = holder
    for k in range(0, len(photos), 2):
        if k == 0:
            h = holder
        else:
            h = clone(proto)
            h.set("pageBreak", "1")
            insert_after(prev, [h])
        cells = [tr.find("hp:tc", N) for tr in h.find(".//hp:tbl", N).findall("hp:tr", N)]
        for tc, ph in zip(cells, photos[k:k + 2] + [None]):
            if ph:
                put_photo(doc, tc, ph)
            else:
                set_cell_lines(tc, [""])
        prev = h


def generate(data, out_path):
    d, ev = data["derived"], data["event"]
    res = data.get("result") or {}
    if not res:
        raise BuildError("결과보고는 행사 후 데이터(result)가 있어야 만들 수 있습니다")
    end = res.get("actual_end") or d["end"]
    if res.get("host_name") and data["host"].get("name", "").strip("ㅇ○ ") == "":     # 계획서에 시장 이름이 없을 때: 회의록에서 찾은 이름
        data = {**data, "host": {**data["host"], "name": res["host_name"]}}
    style = ev.get("result_style") or "편집본"
    doc = Doc(TEMPLATES.get(style, "result.hwpx"))
    doc.style = style
    tops = doc.orig
    try:
        doc.P = find_layout(doc)
    except StopIteration:
        raise BuildError(f"결과보고 양식({style})에서 총평·의견수렴·붙임 자리를 찾지 못했습니다 — templates/ 원본을 확인")
    if style == "편집본" and len(tops) != TOPS:
        raise BuildError(f"결과보고 원본 문단 수({len(tops)})가 예상({TOPS})과 다릅니다")
    expect_text(tops[doc.P["list"]], "붙임", "붙임 목록")

    fill_approval(doc, data)
    fill_cover(doc, data, d, res, end)
    fill_body_head(doc, data)
    fill_review(doc, res)
    fill_overview(doc, data, d, end)
    fill_suggestions(doc, data, res)
    fill_plan(doc, data, res)
    add_budget_admin(doc, data, d)
    ms = res.get("minutes") or []
    if not ms and not res.get("org_rows"):
        doc.warnings.append("회의록 발언이 없어 붙임 1 회의록 표를 양식 그대로 둠 — 확인 필요")
    else:
        fill_minutes(doc, data, ms or [{"org": "", "position": "", "name": "", "lines": [""]}])   # 표만 있으면 행 틀 하나
    fill_roster(doc, data, res)
    fill_photos(doc, res.get("photos") or [])
    for k, label in ((doc.P["roster_head"], "참석자 명단"), (doc.P["photo_head"], "간담회 사진")):   # 붙임 2·3은 늘 새 쪽에서
        expect_text(tops[k], label, f"붙임 「{label}」 제목")
        tops[k].set("pageBreak", "1")
    return doc.save(out_path, f'{ev["title"]} 결과보고', {}, keep_layout=True)


# ---------- 회의록 정리(따로 내려받는 한글 파일) ----------
def generate_minutes_table(data, rows, out_path, subject="기관"):
    """결과보고 양식의 붙임 1(제목 띠·회의 제목·표)만 남겨 「기관별 정리」 표 한글 파일을 만든다(쪽 설정은 양식 그대로)."""
    ev = data["event"]
    doc = Doc(TEMPLATES.get("편집본", "result.hwpx"))
    doc.style = "편집본"
    doc.P = find_layout(doc)
    tops = doc.orig
    k = doc.P["minutes_title"]
    t = doc.tbl(T_MINUTES)
    holder = owner_p(t)
    head = next(tops[i] for i in range(k - 1, -1, -1) if list(tops[i].iter(Q("tbl"))))    # 「붙임 1 회의록」 제목 띠
    keep = [head, tops[k], holder]
    labels = ["대학명" if subject == "대학" else "기관명", "직 위", "성 명", "발언내용", "핵심요약", "시장님답변", "관련부서"]
    widen_minutes(doc, t, [[[r["org"]], [r["position"]], [r["name"]], r["say"] or [""], r["key"] or [""], r["answer"] or [""],
                            r["depts"] or [""]] for r in rows] or [[[""]] * 7], labels)   # 머리 칸 모양을 의견수렴 표에서 가져오므로 먼저
    first = tops[0]
    for run in first.findall("hp:run", N):                        # 첫 문단: 쪽 설정(secPr·ctrl)만 남긴다
        for c in list(run):
            if etree_name(c) not in ("secPr", "ctrl"):
                run.remove(c)
    for p in tops[1:]:
        if p not in keep:
            remove(p)
    for p in keep:
        p.set("pageBreak", "0")
    disc = next((p for p in data["program"] if p.get("type") == "discussion"), None)
    set_only(tops[k], f'[{ev["title"]} : {(disc.get("desc") or disc["item"]) if disc else "의견 수렴"}]')
    return doc.save(out_path, f'{ev["title"]} 회의록 정리', {}, keep_layout=True)


def etree_name(el):
    return el.tag.split("}")[-1]
