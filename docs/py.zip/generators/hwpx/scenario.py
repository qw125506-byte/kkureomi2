# -*- coding: utf-8 -*-
"""③ 사회자 시나리오 — templates/scenario.hwpx(사용자 견본 「(견본) 사회자 시나리오」)를 복제해 내용만 바꾼다.

견본 구성(가로 쪽): 표지 → 「사전안내·안내」 쪽 → 개회 쪽 → 참석자 소개 쪽(대학별 가나다순) → 간부 소개 쪽 →
식순 쪽(한 쪽에 식순 1~2개: 「식 순 | 시 나 리 오 | 비 고」 표, 앞 식순이 끝난 뒤 말은 [○○ 종료 후]로 시작).
- 사회자 멘트: program[].script (없으면 「다음은 ~이 있겠습니다.」 기본 문형)
- type=attendees 식순: 개회 쪽 + 참석자 소개 쪽 + 간부 소개 쪽(다음 식순이 인사말씀이면 그 안내 말을 쪽 끝에)
- type=discussion 식순: 「(토의주재) …」
"""
import copy
import math
import re

from lxml import etree

from generators.hwpx.brief import fit
from core.hwpx import (Doc, BuildError, N, Q, bp, cell, cell_ps, clone, expect_text, find_tbl, insert_after, josa,
                       owner_p, p_with, remove, renumber, set_only, set_runs, spaced, tr_cells)

T_COVER_WHEN = "2030456389"
T_TITLE = "1212474936"
T_DEPT = "2082232964"
T_OPENING = "1154476336"       # 사전안내·안내 쪽
T_PAGE = "1154476378"          # 식순 쪽 본(머리 + 2행)
T_MAYOR = "1154476376"         # 「(시  장  님)」 글줄 본
T_LIST = "1154476342"          # 참석자 소개 쪽(이름 목록 글줄 본)
P = dict(when=0, title=4, agenda=6, dept=10, opening=11, pages_from=12, pages_to=18)
TOPS = 27
BODY_H = 41994                 # 쪽 하나에 채우는 표 본문 높이(견본: 머리 3546 + 본문 → 45540)
PAGE_LINES = 21                # 쪽 하나에 들어가는 줄 수(견본 쪽 채움 기준)
LIST_LINES = 18                # 참석자 소개 쪽 하나에 넣는 이름 수
CHARS_PER_LINE = 28            # 시나리오 칸 한 줄 글자 수(16pt)
LABEL_WIDTH = 9                # 식순 칸 한 줄 글자 수

# 글자 모양(견본의 charPr): 같은 번호가 같은 글꼴·굵기·밑줄이다
C_TXT, C_BOLD, C_UNDER, C_NAME = "29", "14", "74", "54"
C_NOTE, C_HIGH, C_TOPIC = "7", "71", "59"


# ---------- 문단 만들기 ----------
def make(proto, parts):
    """proto 문단을 복제해 글을 parts([(글자 모양, 글)...])로 다시 채운다(글머리·정렬·들여쓰기는 proto 것)."""
    p = clone(proto)
    runs = p.findall("hp:run", N)
    base = next((r for r in runs if r.find("hp:t", N) is not None), runs[0])
    keep = copy.deepcopy(base)
    for t in keep.findall("hp:t", N):
        keep.remove(t)
    for r in runs:
        p.remove(r)
    parts = [x for x in parts if x[1]] or parts[:1] or [(base.get("charPrIDRef"), "")]
    for cp, text in parts:
        r = copy.deepcopy(keep)
        r.set("charPrIDRef", cp)
        if text:                                  # 빈 줄은 글 없는 run(견본과 같게)
            etree.SubElement(r, Q("t")).text = text
        p.append(r)
    bp.drop_lineseg(p)
    return p


class Protos:
    """견본 칸에서 떼어 둔 문단 본"""

    def __init__(self, sec):
        pg = find_tbl(sec, T_PAGE)
        row1 = cell_ps(cell(pg, 1, 1))
        self.label = copy.deepcopy(cell_ps(cell(pg, 1, 0))[0])
        self.lead = copy.deepcopy(cell_ps(cell(pg, 1, 0))[1])
        self.mayor = copy.deepcopy(cell_ps(cell(find_tbl(sec, T_MAYOR), 1, 0))[1])
        self.note = copy.deepcopy(row1[1])
        self.bullet = copy.deepcopy(row1[3])
        lst = cell_ps(cell(find_tbl(sec, T_LIST), 1, 1))
        self.name = copy.deepcopy(lst[5])
        self.small = copy.deepcopy(lst[2])
        op = cell_ps(cell(find_tbl(sec, T_OPENING), 2, 1))
        self.op_bullet, self.op_cont, self.op_inpl, self.op_text = (copy.deepcopy(op[0]), copy.deepcopy(op[1]),
                                                                    copy.deepcopy(op[3]), copy.deepcopy(op[5]))
        self.op_first = copy.deepcopy(cell_ps(cell(find_tbl(sec, T_OPENING), 1, 1))[0])
        self.row = copy.deepcopy(find_tbl(sec, T_PAGE).findall("hp:tr", N)[1])
        self.page = copy.deepcopy(owner_p(find_tbl(sec, T_PAGE)))

    def bul(self, parts):
        return make(self.bullet, [(C_TXT, " ◯ ")] + parts if isinstance(parts, list) else [(C_TXT, f" ◯ {parts}")])

    def cont(self, text):
        return make(self.bullet, [(C_TXT, "    " + text)])

    def blank(self):
        return make(self.bullet, [])

    def note_p(self, text):
        return make(self.note, [(C_NOTE, " " + text)])


def fill_cell(tc, paras):
    sub = tc.find("hp:subList", N)
    for p in cell_ps(tc):
        sub.remove(p)
    for p in paras:
        sub.append(p)


# ---------- 말 다듬기 ----------
def sentences(script):
    return [s for s in re.split(r"(?<=[.?!])\s+", (script or "").strip()) if s]


def mc_name(data, role):
    for s in data["org"].get("staff") or []:
        if s["role"] == role:
            return s["name"]
    return ""


def guests_word(data):
    """「12개 대학 총장님들」 — 참석자 무리가 하나일 때만. 여럿이면 「참석자 여러분」"""
    label = data["event"].get("attendee_label") or ""
    parts = [x.strip() for x in label.split(",") if x.strip() and "시장" not in x]
    return f"{parts[0].replace('관내 ', '')}님들" if len(parts) == 1 else "참석자 여러분"


def lead_main(lead):
    return str(lead or "").split(",")[0].strip() or "사회자"


def short_item(item):
    """[인사말씀 종료 후] 같은 괄호 말: 괄호 안·끝의 「등」은 뺀다"""
    s = re.sub(r"\([^)]*\)", "", item).strip()
    return re.sub(r"\s*등$", "", s).strip() or item


def label_lines(item):
    """식순 칸(한 줄 9자 안팎)에 맞춰 낱말 사이에서 줄바꿈: 「개회 및 / 참석자 소개」"""
    item = item.strip()
    if len(item) <= LABEL_WIDTH:
        return [item]
    if "(" in item:
        a, b = item.split("(", 1)
        if a.strip() and len(a.strip()) <= LABEL_WIDTH and len("(" + b) <= LABEL_WIDTH + 2:
            return [a.strip(), "(" + b]
    lines, cur = [], ""
    for w in item.split():
        if cur and len(cur) + 1 + len(w) > LABEL_WIDTH:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    return lines + [cur]


def lead_para(L, lead):
    if lead == "시장님":
        p = clone(L.mayor)
        runs = p.findall("hp:run", N)
        texts = ["(", "시  장  님", ")"]
        for r, tx in zip(runs, texts):
            for t in r.findall("hp:t", N):
                t.text = tx
        bp.drop_lineseg(p)
        return p
    return make(L.lead, [(L.lead.find("hp:run", N).get("charPrIDRef"), f"({lead})")])


def label_paras(L, item, lead):
    return [make(L.label, [(L.label.find("hp:run", N).get("charPrIDRef"), x)]) for x in label_lines(item)] + [lead_para(L, lead)]


# ---------- 표 쪽 ----------
def est_lines(paras):
    n = 0
    for p in paras:
        n += max(1, math.ceil(len(bp.p_text(p)) / CHARS_PER_LINE))
    return n


def build_page(L, rows):
    """rows: [(label 문단들, 내용 문단들)] → 식순 쪽(문단) 하나"""
    p = clone(L.page)
    p.set("pageBreak", "1")
    tbl = p.find(".//hp:tbl", N)
    trs = tbl.findall("hp:tr", N)
    for tr in trs[1:]:
        tbl.remove(tr)
    weights = [max(est_lines(c), len(lab) + 1) for lab, c in rows]
    for (lab, content), w in zip(rows, weights):
        tr = clone(L.row)
        c = tr_cells(tr)
        fill_cell(c[0], lab)
        fill_cell(c[1], content)
        h = max(8000, int(BODY_H * w / sum(weights)))
        for tc in tr.findall("hp:tc", N):
            tc.find("hp:cellSz", N).set("height", str(h))
        tbl.append(tr)
    renumber(tbl)
    return p


# ---------- 앞쪽(사전안내·안내) ----------
def fill_opening(doc, L, data):
    ev, prog = data["event"], data["program"]
    d = data["derived"]["program"]
    mc = d[0]["lead"]
    name = mc_name(data, mc)
    t = doc.tbl(T_OPENING)
    for r, lbl in ((1, "사전안내"), (2, "안   내")):
        fill_cell(cell(t, r, 0), [make(L.label, [(L.label.find("hp:run", N).get("charPrIDRef"), lbl)]), lead_para(L, mc)])
    title = ev["title"]
    fill_cell(cell(t, 1, 1), [make(L.op_first, [
        ("29", " ◯ "), ("65", "잠시 후, "), ("58", title), ("36", josa(title, "을/를") + " "),
        ("57", "시작할 예정이오니 자리에 착석하여 주시기 바라며, 원활한 진행을 위하여 핸드폰은 진동 또는 전원을 꺼주시면 감사하겠습니다.")])])
    names = []
    first = prog[0] if prog else {}
    if first.get("type") == "attendees":
        names.append("참석자 소개")
    for p in prog[1:-1] if len(prog) > 2 else prog:
        it = short_item(p["item"])
        names.append(f"시장님 {it}" if p.get("is_mayor") and it.endswith("말씀") and not it.startswith("시장") else it)
    order = ", ".join(names)
    who = f'{data["org"]["dept"]} {mc} {name}입니다.' if name else f'{data["org"]["dept"]} {mc}입니다.'
    fill_cell(cell(t, 2, 1), [
        make(L.op_bullet, [("29", " ◯ 안녕하십니까 ?  ")]),
        make(L.op_cont, [("29", "    " + who)]),
        make(L.op_cont, []),
        make(L.op_inpl, [("17", " (인     사) ")]),
        make(L.op_cont, []),
        make(L.op_text, [("29", f" ◯ 바쁘신 일정에도 불구하고 본 회의에 참석해 주신 {guests_word(data)}께 감사드리며, "
                                "오늘 회의 진행순서를 간략히 말씀드리겠습니다.")]),
        make(L.op_text, []),
        make(L.op_text, [("29", " ◯ 오늘 회의는 "), (C_UNDER, order), ("29", " 순으로 진행하겠습니다.")]),
    ])


# ---------- 개회·참석자 소개 쪽 ----------
def opening_page(L, data, st, nxt):
    """첫 식순(개회) 쪽: 말씀 첫 문장 / (국기에 대한 경례가 있으면 견본의 경례 순서) / 소개 안내 문장"""
    title = data["event"]["title"]
    lines = sentences(st.get("script")) or [f"그럼, 지금부터 {title}{josa(title, '을/를')} 시작하겠습니다."]
    paras = []
    for k, s in enumerate(lines):
        if k:
            paras.append(L.blank())
        if "국기에 대한 경례" in s:
            paras += [L.bul(s), L.cont("전면 국기를 향하여 바로 서 주시기 바랍니다."), L.blank(),
                      make(L.bullet, [(C_TXT, "     “ "), (C_HIGH, "국기에 대하여  경례"), (C_TXT, "”-----")]),
                      make(L.bullet, [(C_TXT, "     “ "), (C_HIGH, "바   로"), (C_TXT, "” 이하 의식은 생략하겠습니다.")]),
                      L.blank(), L.cont("모두 자리에 앉아 주시기 바랍니다.")]
        else:
            paras.append(L.bul(s))
    if st.get("type") == "attendees" and not any("소개" in s for s in lines):
        paras += [L.blank(), L.bul("다음은 참석자 소개가 있겠습니다.")]
    return build_page(L, [(label_paras(L, st["item"], st["lead"]), paras)])


def group_key(name):
    return re.sub(r"^[㈜()（）\s]+|\s*\(주\)\s*", "", name)


def intro_pages(L, data, st, next_line):
    """참석자 소개 쪽(주빈 → 참석자 가나다순) + 간부 소개 쪽. next_line: 간부 소개 쪽 끝에 붙일 다음 식순 안내 말"""
    host, people = data["host"], sorted(data["attendees"], key=lambda a: group_key(a["org"]))
    staff = data.get("staff_present") or []
    kind = "대학" if people and all(a["org"].rstrip().endswith("대학교") for a in people) else "기관"
    pages = []

    def line(name, who):
        return make(L.name, [(C_TXT, "    "), (C_NAME, name), (C_TXT, " "), ("22", who), (C_TXT, " 참석하셨습니다.")])

    def sb():                                   # 견본의 작은 빈 줄(5pt)
        return make(L.name, [("28", "")])
    head = [make(L.name, [(C_TXT, " ◯ 먼저, "), (C_NAME, host["name"]), (C_BOLD, f' {host["position"]}님'), (C_TXT, " 참석하셨습니다.")])]
    if people:
        head += [sb(), make(L.small, [(C_TXT, "   ※ "), ("60", f"{kind}별 참석자 소개는 {kind}명 가나다순으로 진행하도록 "),
                                      (C_TXT, "         하겠습니다.  ")]), sb(), sb()]
    first = LIST_LINES - 4
    chunks = [people[:first]] + [people[i:i + LIST_LINES] for i in range(first, len(people), LIST_LINES)]
    for k, ch in enumerate(chunks):
        body = (head if k == 0 else []) + [line(a["name"], f'{a["org"]} {a["position"]}님') for a in ch]
        if k == len(chunks) - 1 and not staff and next_line:
            body += [sb(), make(L.name, [(C_TXT, f" ◯ {next_line}")])]
        pages.append(build_page(L, [(label_paras(L, "참석자 소개", st["lead"]), body)]))
    if staff:
        city = data["org"]["city"]
        body = [make(L.name, [(C_TXT, f" ◯ 다음은, {city}청 간부님들을 소개해 드리겠습니다.")]), sb(), sb()]
        body += [line(s["name"], f'{s["position"]}님') for s in staff]
        if next_line:
            body += [sb(), make(L.name, [(C_TXT, f" ◯ {next_line}")])]
        pages.append(build_page(L, [(label_paras(L, "참석자 소개", st["lead"]), body)]))
    return pages


# ---------- 식순 쪽 ----------
def item_rows(L, data, rows, i):
    """식순 하나 → (label 문단들, 내용 문단들)"""
    st, host = rows[i], data["host"]
    paras = []
    if i:
        paras += [L.note_p(f"[{short_item(rows[i - 1]['item'])} 종료 후]"), L.blank()]
    lines = sentences(st.get("script"))
    if not lines:
        if "폐회" in st["item"]:
            kind = re.sub(r"^.*\s", "", data["event"]["title"]) or "행사"
            lines = [f"이상으로 {kind}를 모두 마치" + ("고, 기념촬영을 하도록 하겠습니다." if "촬영" in st["item"] else "겠습니다.")]
        else:
            who = lead_main(st["lead"])
            lines = [f'다음은 {who}의 「{st["item"]}」{josa(st["item"], "이/가")} 있겠습니다.']
    for k, s in enumerate(lines):
        if k:
            paras.append(L.blank())
        paras.append(L.bul(s))
    if st.get("type") == "discussion":
        paras += [L.blank(), make(L.note, [("61", "(토의주재)"), (C_TXT, " "), (C_TOPIC, st.get("desc") or st["item"])])]
    return label_paras(L, st["item"], st["lead"]), paras


def program_pages(L, data, rows):
    pages = []
    cur, cur_lines = [], 0
    attend = next((i for i, st in enumerate(rows) if st.get("type") == "attendees"), None)
    nxt = rows[attend + 1] if attend is not None and attend + 1 < len(rows) else None
    greet = nxt is not None and nxt.get("is_mayor") and "인사" in nxt["item"]
    skip = set()

    def flush():
        nonlocal cur, cur_lines
        if cur:
            pages.append(build_page(L, cur))
        cur, cur_lines = [], 0

    for i, st in enumerate(rows):
        if i in skip:
            continue
        if st.get("type") == "attendees":
            flush()
            pages.append(opening_page(L, data, st, nxt))
            nl = None
            if greet:
                nl = (sentences(nxt.get("script")) or [f"다음은 {data['host']['name']} {data['host']['position']}님의 인사말씀이 있겠습니다."])[0]
            pages += intro_pages(L, data, st, nl)
            continue
        if greet and st is nxt:                       # 인사말씀: 안내 말은 앞 쪽 끝에 있고 여기는 말씀 자료만
            flush()
            lab = label_paras(L, st["item"], st["lead"])
            pages.append(build_page(L, [(lab, [make(L.bullet, [(C_TXT, " ◯ "), (C_HIGH, "(별도 자료)"), (C_TXT, "  "), (C_BOLD, "말씀 참고 자료")])])]))
            continue
        row = item_rows(L, data, rows, i)
        n = est_lines(row[1])
        if cur and (len(cur) >= 2 or cur_lines + n > PAGE_LINES):
            flush()
        cur.append(row)
        cur_lines += n
    flush()
    return pages


def generate(data, out_path):
    d, ev = data["derived"], data["event"]
    doc = Doc("scenario.hwpx")
    tops = doc.orig
    if len(tops) != TOPS:
        raise BuildError(f"시나리오 원본 문단 수({len(tops)})가 예상({TOPS})과 다릅니다")
    expect_text(tops[P["title"]], "시나리", "시나리오 제목")
    L = Protos(doc.sec)

    # 표지
    when = p_with(doc.tbl(T_COVER_WHEN), "2026")
    set_runs(when, {0: f'{d["date_text"]} {ev.get("venue_short") or ev["venue"]} {ev["start"]}'})
    fit(when, bp.cell_avail(cell(doc.tbl(T_COVER_WHEN), 0, 0)), ratio=0.94, squeeze=12)
    tp = p_with(doc.tbl(T_TITLE), "시나리")
    set_only(tp, f'{ev["title"]} 회의 시나리오')
    tc = cell(doc.tbl(T_TITLE), 1, 0)
    bp.fit_line(tp, bp.cell_avail(tc), ratio=0.94, squeeze=12)
    ap = p_with(tops[P["agenda"]], "(안")
    set_runs(ap, {3: f' {ev.get("summary", "")}'}, expect={2: "(안"})
    rect = doc.sec.xpath(".//hp:rect[@id='2082232956']", namespaces=N)[0]
    fit(ap, int(rect.find("hp:sz", N).get("width")) - 566 - 600, ratio=0.94, squeeze=12)
    t = doc.tbl(T_DEPT)
    set_only(p_with(t, "천 안 시"), spaced(data["org"]["city"]))
    set_only(p_with(t, "("), f'({data["org"]["dept"]})')

    fill_opening(doc, L, data)
    old = tops[P["pages_from"]:P["pages_to"] + 1]
    insert_after(tops[P["opening"]], program_pages(L, data, d["program"]))
    for p in old:
        remove(p)
    return doc.save(out_path, f'{ev["title"]} 시나리오')
