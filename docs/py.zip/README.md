# 문서꾸러미

행사 기본자료 하나로 간담회 문서 6종을 기관 양식 그대로 만든다.

| 문서 | 형식 | 원본 양식 |
|---|---|---|
| ① 개최 계획 | HWPX | templates/plan.hwpx |
| ② 보고요지 | HWPX | templates/brief.hwpx |
| ③ 진행 시나리오 | HWPX | templates/scenario.hwpx |
| ④ 보도자료 | HWPX | templates/press.hwpx |
| ⑤ 진행 PPT | PPTX | templates/ppt.pptx |
| ⑥ 결과보고 | HWPX | templates/result.hwpx |

## 쓰는 법

```bash
pip install -r requirements.txt
python bundle.py examples/대학총장_간담회.json --out out/대학총장
```

- 행사 전: `--stage before` (①②③④⑤ — 보도자료는 미리 배포용 예고 기사)
- 행사 후: `--minutes 회의록.txt` → ⑥ 결과보고 자동(실제 종료 시각·붙임 회의록, AI가 있으면 건의사항·총평까지)
- 비워 둔 계획서 문구(취지·추진목적·안건·주요내용)와 보도자료는 만들 때 자동 작성(Claude API가 있으면 AI, 없으면 정해진 문형)
- 일부만: `--only plan,ppt` / PPT 추가 장표: `--extras`
- 한글·PowerPoint로 실제로 열어 보기(이 PC 전용, 문서당 수십 초): `--render`
- 결과: 문서 파일, `{행사명} 문서꾸러미.zip`, `검증보고.md`(검산·문서 간 일치·구조·원본 글 잔존)

## 웹 앱

가장 쉬운 방법: `문서꾸러미 실행.bat`을 두 번 누른다(필요한 프로그램 자동 설치 → 서버 켜기 → 브라우저 열기).
이 컴퓨터에서만 접속된다(127.0.0.1). 다른 사람에게 줄 설치본은 `python scripts/make_dist.py --app` →
`배포용/문서꾸러미_설치파일.zip`(받는 사람은 압축 풀고 같은 .bat 실행, 안내는 `배포용/설치 안내.txt`).

직접 켜기:

```bash
pip install -r requirements.txt
npm --prefix web install
npm --prefix web run build
python -m uvicorn server.app:app --port 8010
```

브라우저에서 http://localhost:8010 을 연다.

- 자료(메모·공문·지난 계획서)를 올리면 행사명·날짜·시간·장소·부서·식순을 읽어 채운다(AI 없이도 규칙으로 동작).
- 입력은 행사정보·부서·식순·참석자 정도. 계획서 문구와 보도자료는 자동, 예산·행정사항은 접어 둔 선택 칸.
- 행사 후에는 회의록 파일을 끌어다 놓으면 입력 칸 없이 ⑥ 결과보고가 만들어진다.
- 「새로 시작」은 확인 없이 모든 입력과 만든 문서 목록을 지운다.
- 오른쪽 「검사」 칸이 입력할 때마다 형식 오류·검산 결과를 보여 준다.
- 문서를 골라 만들면 미리보기·내려받기·전체 ZIP·검증보고를 받는다. 만든 파일은 1시간 뒤 서버에서 지워진다.
- 행사데이터는 서버에 저장하지 않고 이 브라우저(localStorage)에만 둔다. JSON 내보내기·불러오기로 옮긴다.
- Claude API 자격 증명이 있으면 자료 읽기·문구·보도자료·회의록 정리를 AI가 하고, 없으면 규칙으로 하되 지어낼 수 없는 부분은 「[확인 필요]」로 남긴다. `KKUREOMI_AI=off`로 AI를 끌 수 있다.
- 화면 개발: `npm --prefix web run dev`(5173, /api는 8010으로 넘김)

## 행사데이터

`schema/event.schema.json` 형식의 JSON 하나. 예시는 `examples/`.
식순 시각·예산 합계·한글 금액·참석 인원은 저장하지 않고 `core/calc.py`가 계산한다.
`result`(건의사항·회의록·실제 종료 시각 등)는 행사 후에 채운다.

## 시험

```bash
python -m pytest
```
